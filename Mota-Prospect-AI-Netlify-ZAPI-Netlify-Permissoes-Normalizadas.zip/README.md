# Mota Prospect AI — reconstrução local

Aplicação web em reconstrução independente, criada no Codex a partir do que estava visível no projeto Lovable “Remix of Mota Prospect AI”. Não é uma exportação integral do projeto Lovable.

## Requisitos e comandos

Use Node.js 22 ou superior e npm:

```sh
npm install --legacy-peer-deps
npm run dev
```

Por padrão, o Vite inicia em demonstração local. Para testar a autenticação no banco emulado, copie `.env.example` para `.env.local`, defina `VITE_MOTA_DEMO_MODE=false` e aplique as migrações locais. Depois, use a aba **Cadastro** para criar a primeira conta administradora; esse cadastro é permitido uma única vez por banco. Em hospedagem, o Netlify Database precisa estar habilitado e aplica as migrações no ciclo de deploy.

Com o servidor Vite rodando, aplique as migrações na base local (em outro terminal na raiz do projeto):

```sh
npx netlify-cli database migrations apply
```

Esse comando usa o banco local emulado pelo plugin. A migração hospedada é aplicada pelo ciclo de deploy do Netlify, não por esse comando local.

O plugin Vite oficial para TanStack Start emula localmente as primitivas Netlify durante `npm run dev`; a CLI Netlify não é necessária para desenvolvimento local. Os comandos de validação são:

```sh
npm run typecheck
npm run lint
npm test
npm run build
npm audit --offline
```

O modo DEMO mantém os registros apenas no `localStorage` e só está habilitado no servidor de desenvolvimento. Nunca use dados reais nesse modo.

## Arquitetura

- `src/domain`: regras, tipos e transições do funil.
- `src/application`: casos de uso e contratos.
- `src/infrastructure`: repositórios, autenticação, banco e adaptadores.
- `src/routes`: interface TanStack Start/React.
- `netlify/database/migrations`: migrações versionadas do Netlify Database.
- `docs`: estado de auditoria e instruções operacionais.

Usuários, hashes de senha e sessões opacas ficam no Netlify Database; cookies HttpOnly transportam tokens aleatórios cujo hash é persistido no banco. A primeira conta é criada uma única vez pela aba **Cadastro** e recebe acesso de administradora; a criação é disputada atomicamente no servidor e cadastros posteriores ficam fechados. Mantenha o site restrito durante a configuração inicial para evitar que outra pessoa reivindique a primeira conta. A administradora cria logins de equipe; consultas de negócio ficam no escopo do workspace, e funções administrativas verificam o papel no servidor.

## Configuração externa

Veja [.env.example](.env.example) e [docs/NETLIFY-OPERACAO.md](docs/NETLIFY-OPERACAO.md). Para produção, habilite Netlify Database e confirme as migrações automáticas no deploy. `MOTA_INTEGRATION_ENCRYPTION_KEY` é opcional: sem ela o servidor deriva a chave da conexão secreta do Netlify Database; defina-a se precisar manter credenciais cifradas através da rotação da connection string. Nenhuma conta, site, banco ou credencial foi conectado nesta execução.

Com banco e autenticação configurados, a aba **Integrações** salva credenciais cifradas AES-256-GCM por workspace. Durante expediente ativo, a função agendada tenta uma pesquisa SerpApi a cada 15 minutos em dias úteis e no horário definido; há limite de 6 buscas e 30 candidatos por dia, até 20 resultados por ciclo e até 4 consultas CNPJ por busca. Os candidatos deduplicados entram como leads pendentes de revisão, sem contato automático. O orçamento preenchido é apenas referência e não limita a cobrança do provedor.

Registre `https://<dominio-do-app>/integrations` como redirect URI no OAuth app do Calendly; Client ID não é URL e Client Secret é salvo no campo de credencial. A área Agendamentos mostra estado OAuth e link público de booking; eventos existentes ainda não são importados. O Calendly pode enviar notificações da conta.

A área **Equipe** permite que a administradora crie e bloqueie contas comerciais com senha inicial. Membros compartilham leads do workspace e não podem editar integrações, controles operacionais nem acessos. A área **Atendimento** guarda solicitações de handoff e pode exibir notificações do navegador enquanto a página está aberta; notificações Web Push em segundo plano não estão configuradas.

A página **Leads** inclui fila de revisão humana, com estado persistido separado do pipeline comercial, aprovação/rejeição auditadas e bloqueio de contato. Resultados públicos mostram a URL de pesquisa guardada nas observações. Aprovar um resultado ainda não sincroniza a MachtKin nem inicia contato.

A página **Inbox** persiste conversas, mensagens e notas. Há integração Z-API com envio manual, webhook de mensagens recebidas e atualização periódica da tela; o endpoint de webhook deve ser cadastrado na instância. Uma nova mensagem pausa a automação e o envio real pede confirmação humana. Gemini produz sugestões supervisionadas seguindo o processo interno, mas não responde automaticamente. A automação comercial completa, agendamento pela conversa e sincronização de escrita na MachtKin ainda não estão implementados. Veja [docs/MESSAGING_ARCHITECTURE.md](docs/MESSAGING_ARCHITECTURE.md) e [docs/WHATSAPP_INTEGRATION.md](docs/WHATSAPP_INTEGRATION.md).

A área **WhatsApp** ainda pode abrir WhatsApp Web manualmente; ela não sincroniza o histórico com o app. A integração Meta Cloud API anterior segue separada e apenas testa leitura. A YCloud é o backend do caminho novo de inbox. Consulte [docs/INTEGRACOES-EXTERNAS.md](docs/INTEGRACOES-EXTERNAS.md) para CRM e outros limites.

Não publique nem aplique migração em produção até revisar o site de destino, o schema e os controles de acesso. A migração não inclui seeds.

## Limitações funcionais conhecidas

Não há agente Dealism conectado: a URL MCP/OAuth da integração oficial do Codex não autentica automaticamente o backend Netlify, e o contrato de API servidor do Dealism ainda não foi verificado. A busca contínua usa função agendada a cada 15 minutos durante o expediente, dentro dos limites configurados; leads capturados aguardam revisão humana. Ainda não existe qualificação automática nem diálogo autônomo com Gemini, nem integração de escrita com a MachtKin, nem fluxo de agendamento que leve da conversa à criação de reunião e envio do Meet. Não há Web Push com app fechado, recuperação de senha ou sincronização do histórico WhatsApp Web.
