-- YCloud messaging is opt-in and starts in supervised (manual) mode.
alter table user_operating_settings
  add column if not exists ycloud_messaging_enabled boolean not null default false,
  add column if not exists ycloud_last_test_at timestamptz,
  add column if not exists ycloud_last_test_status text check (ycloud_last_test_status in ('connected','number_not_ready','number_not_found','error'));

alter table conversations
  add column if not exists last_inbound_at timestamptz,
  add column if not exists channel text not null default 'whatsapp',
  add column if not exists automation_mode text not null default 'assisted'
    check (automation_mode in ('assisted', 'automatic_supervised', 'human'));

alter table conversation_messages
  add column if not exists external_message_id text,
  add column if not exists correlation_id text,
  add column if not exists message_type text not null default 'text',
  add column if not exists failure_reason text;

alter table conversation_messages drop constraint if exists conversation_messages_delivery_status_check;
alter table conversation_messages add constraint conversation_messages_delivery_status_check
  check (delivery_status in ('simulated','received','queued','accepted','sent','delivered','read','failed','cancelled','unknown'));
create unique index if not exists conversation_messages_external_id_unique
  on conversation_messages(owner_id, external_message_id) where external_message_id is not null;
create index if not exists conversations_owner_last_inbound_idx
  on conversations(owner_id, last_inbound_at desc) where last_inbound_at is not null;

create table if not exists ycloud_webhook_events (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references app_users(id) on delete cascade,
  external_event_id text not null,
  event_type text not null,
  payload_sha256 text not null check (length(payload_sha256) = 64),
  payload jsonb,
  status text not null default 'received' check (status in ('received','processing','processed','unmatched','ignored','failed')),
  attempts integer not null default 0 check (attempts >= 0),
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  last_error_code text,
  unique(owner_id, external_event_id)
);
create index if not exists ycloud_webhook_events_owner_status_idx
  on ycloud_webhook_events(owner_id, status, received_at desc);
