-- Permit distinct bounded search cycles during one active workday.
alter table prospecting_runs add column if not exists cycle_key text not null default 'initial';
alter table prospecting_runs drop constraint if exists prospecting_runs_owner_id_shift_started_at_key;
create unique index if not exists prospecting_runs_owner_shift_cycle_unique
  on prospecting_runs(owner_id, shift_started_at, cycle_key);

create table if not exists prospecting_search_daily_usage (
  owner_id uuid not null references app_users(id) on delete cascade,
  usage_date date not null,
  request_count integer not null default 0 check (request_count between 0 and 6),
  updated_at timestamptz not null default now(),
  primary key(owner_id, usage_date)
);
