-- Workspace team members share the owner's leads and integrations, while every action keeps its own actor_id.
alter table app_users add column if not exists team_owner_id uuid references app_users(id) on delete cascade;
create index if not exists app_users_team_owner_idx on app_users(team_owner_id, created_at desc) where team_owner_id is not null;

-- Human handoff inbox for leads requesting a commercial representative.
create table if not exists human_handoff_requests (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references app_users(id) on delete cascade,
  lead_id uuid not null references leads(id) on delete cascade,
  requested_by uuid not null references app_users(id) on delete restrict,
  assigned_to uuid references app_users(id) on delete set null,
  status text not null default 'pending' check (status in ('pending','assigned','resolved','dismissed')),
  note text not null default '' check (length(note) <= 1000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists human_handoff_one_open_per_lead_idx on human_handoff_requests(owner_id, lead_id) where status in ('pending','assigned');
create index if not exists human_handoff_owner_status_idx on human_handoff_requests(owner_id, status, created_at desc);

-- Public-source enrichment and a durable per-shift idempotency record.
alter table leads add column if not exists cnpj text;
create unique index if not exists leads_owner_cnpj_unique on leads(owner_id, cnpj) where cnpj is not null and cnpj <> '';
create table if not exists prospecting_runs (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references app_users(id) on delete cascade,
  shift_started_at timestamptz not null,
  started_by uuid not null references app_users(id) on delete restrict,
  status text not null default 'running' check (status in ('running','completed','failed')),
  search_requests integer not null default 0 check (search_requests between 0 and 1),
  candidates_seen integer not null default 0 check (candidates_seen >= 0),
  leads_created integer not null default 0 check (leads_created >= 0),
  error_code text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(owner_id, shift_started_at)
);
