-- Atomic daily quota by workspace in Marechal Deodoro's operating timezone.
create table if not exists prospecting_daily_usage (
  owner_id uuid not null references app_users(id) on delete cascade,
  usage_date date not null,
  processed_count integer not null default 0 check (processed_count between 0 and 30),
  updated_at timestamptz not null default now(),
  primary key (owner_id, usage_date)
);
