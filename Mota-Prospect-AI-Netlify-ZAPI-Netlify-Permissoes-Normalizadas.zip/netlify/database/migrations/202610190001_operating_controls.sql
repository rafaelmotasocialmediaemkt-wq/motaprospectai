-- Editable per-user operating preferences and persisted runtime gates.
create table if not exists user_operating_settings (
  owner_id uuid primary key references app_users(id) on delete cascade,
  ai_enabled boolean not null default false,
  shift_status text not null default 'idle' check (shift_status in ('idle', 'active')),
  shift_started_at timestamptz,
  shift_ended_at timestamptz,
  business_segment text not null default '',
  target_locations text not null default '',
  search_terms text not null default '',
  max_candidates_per_shift integer not null default 20 check (max_candidates_per_shift between 1 and 100),
  daily_budget_cents integer not null default 0 check (daily_budget_cents between 0 and 10000000),
  workday_start time not null default '09:00',
  workday_end time not null default '18:00',
  timezone text not null default 'America/Sao_Paulo',
  require_human_review boolean not null default true,
  calendly_booking_url text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
