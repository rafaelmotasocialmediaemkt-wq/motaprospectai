-- Password authentication and opaque server-side sessions; no external auth provider.
alter table app_users add column if not exists password_hash text;
alter table app_users add column if not exists is_admin boolean not null default false;
alter table app_users add column if not exists disabled_at timestamptz;
create unique index if not exists app_users_email_unique on app_users(lower(email)) where email is not null;

create table if not exists auth_sessions (
  token_hash text primary key check (length(token_hash) = 64),
  user_id uuid not null references app_users(id) on delete cascade,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index if not exists auth_sessions_user_expiry_idx on auth_sessions(user_id, expires_at);

create table if not exists auth_login_attempts (
  identifier_hash text primary key check (length(identifier_hash) = 64),
  failures integer not null default 0 check (failures >= 0),
  locked_until timestamptz,
  updated_at timestamptz not null default now()
);

-- A singleton insert arbitrates concurrent initial-admin requests.
create table if not exists auth_bootstrap (
  singleton_id boolean primary key default true check (singleton_id = true),
  admin_user_id uuid not null unique,
  created_at timestamptz not null default now()
);
