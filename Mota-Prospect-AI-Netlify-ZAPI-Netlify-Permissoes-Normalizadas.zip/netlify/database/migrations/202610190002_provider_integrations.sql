-- Provider settings and encrypted OAuth/API credentials are isolated per user.
create table if not exists provider_connections (
  owner_id uuid not null references app_users(id) on delete cascade,
  provider text not null check (provider in ('dealism','serpapi','cnpj_biz','serpro','calendly','whatsapp_cloud')),
  config jsonb not null default '{}'::jsonb,
  encrypted_secret text,
  encrypted_token text,
  connected_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (owner_id, provider)
);
create table if not exists oauth_pending_states (
  state_hash text primary key check (length(state_hash) = 64),
  owner_id uuid not null references app_users(id) on delete cascade,
  provider text not null check (provider = 'calendly'),
  encrypted_verifier text not null,
  redirect_uri text not null,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index if not exists oauth_pending_states_expiry_idx on oauth_pending_states(expires_at);
