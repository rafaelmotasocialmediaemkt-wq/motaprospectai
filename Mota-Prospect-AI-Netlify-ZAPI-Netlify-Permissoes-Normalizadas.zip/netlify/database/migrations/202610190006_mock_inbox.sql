create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references app_users(id) on delete cascade,
  lead_id uuid not null references leads(id) on delete cascade,
  status text not null default 'open' check (status in ('open','waiting','closed')),
  assigned_to uuid references app_users(id) on delete set null,
  ai_paused boolean not null default true,
  last_message_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(owner_id, lead_id)
);
create index if not exists conversations_owner_status_idx on conversations(owner_id, status, last_message_at desc);

create table if not exists conversation_messages (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references app_users(id) on delete cascade,
  conversation_id uuid not null references conversations(id) on delete cascade,
  direction text not null check (direction in ('inbound','outbound','internal')),
  author_kind text not null check (author_kind in ('contact','seller','system')),
  body text not null check (length(body) between 1 and 4000),
  delivery_status text not null default 'simulated' check (delivery_status in ('simulated','received','queued','accepted','sent','delivered','read','failed','cancelled')),
  is_simulated boolean not null default true,
  idempotency_key text,
  created_by uuid references app_users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique(owner_id, idempotency_key)
);
create index if not exists conversation_messages_timeline_idx on conversation_messages(owner_id, conversation_id, created_at, id);

create table if not exists conversation_notes (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references app_users(id) on delete cascade,
  conversation_id uuid not null references conversations(id) on delete cascade,
  author_id uuid not null references app_users(id) on delete restrict,
  body text not null check (length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
