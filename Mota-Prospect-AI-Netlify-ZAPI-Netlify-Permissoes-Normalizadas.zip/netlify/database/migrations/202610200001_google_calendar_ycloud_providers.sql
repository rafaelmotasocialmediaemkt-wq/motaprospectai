-- Enable Google Calendar OAuth and YCloud receiver state in existing workspaces.
alter table provider_connections drop constraint if exists provider_connections_provider_check;
alter table provider_connections add constraint provider_connections_provider_check
  check (provider in ('dealism','serpapi','cnpj_biz','serpro','calendly','google_calendar','whatsapp_cloud'));

alter table oauth_pending_states drop constraint if exists oauth_pending_states_provider_check;
alter table oauth_pending_states add constraint oauth_pending_states_provider_check
  check (provider in ('calendly','google_calendar'));
