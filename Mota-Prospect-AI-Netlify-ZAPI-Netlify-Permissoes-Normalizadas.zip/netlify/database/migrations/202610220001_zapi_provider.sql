-- Add the Z-API WhatsApp provider while retaining existing provider records.
alter table provider_connections drop constraint if exists provider_connections_provider_check;
alter table provider_connections add constraint provider_connections_provider_check
  check (provider in ('dealism','serpapi','cnpj_biz','serpro','calendly','google_calendar','whatsapp_cloud','whatsapp_zapi'));
