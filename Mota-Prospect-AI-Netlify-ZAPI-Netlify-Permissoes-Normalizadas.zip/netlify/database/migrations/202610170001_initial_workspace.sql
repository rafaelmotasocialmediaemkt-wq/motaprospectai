-- Initial Netlify Database schema for a new, empty development database.
-- This migration is additive and intentionally contains no seed/demo records.

create table if not exists app_users (
  id uuid primary key,
  email text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists user_profiles (
  user_id uuid primary key references app_users(id) on delete cascade,
  display_name text,
  timezone text not null default 'America/Sao_Paulo',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references app_users(id) on delete cascade,
  company_name text not null check (length(trim(company_name)) between 2 and 160),
  contact_name text check (contact_name is null or length(contact_name) <= 160),
  email text,
  phone text,
  segment text,
  city text,
  state text check (state is null or length(state) = 2),
  source text not null default 'manual',
  stage text not null default 'new' check (stage in ('new','qualifying','qualified','contact_authorized','contacted','responded','meeting_scheduled','proposal','won','lost','archived')),
  qualification_score integer check (qualification_score is null or qualification_score between 0 and 100),
  notes text check (notes is null or length(notes) <= 3000),
  consent_basis text,
  consent_recorded_at timestamptz,
  opted_out_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists leads_owner_stage_created_idx on leads(owner_id, stage, created_at desc);
create index if not exists leads_owner_company_idx on leads(owner_id, lower(trim(company_name)));
create unique index if not exists leads_owner_company_unique on leads(owner_id, lower(trim(company_name)));
create unique index if not exists leads_owner_email_unique on leads(owner_id, lower(trim(email))) where email is not null and trim(email) <> '';
create unique index if not exists leads_owner_phone_unique on leads(owner_id, regexp_replace(phone, '[^0-9]', '', 'g')) where phone is not null and regexp_replace(phone, '[^0-9]', '', 'g') <> '';

create table if not exists lead_stage_history (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references leads(id) on delete cascade,
  owner_id uuid not null references app_users(id) on delete cascade,
  actor_id uuid not null references app_users(id) on delete restrict,
  from_stage text,
  to_stage text not null check (to_stage in ('new','qualifying','qualified','contact_authorized','contacted','responded','meeting_scheduled','proposal','won','lost','archived')),
  changed_at timestamptz not null default now()
);
create index if not exists lead_stage_history_owner_lead_idx on lead_stage_history(owner_id, lead_id, changed_at desc);

create table if not exists audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid not null references app_users(id) on delete restrict,
  action text not null check (length(action) <= 120),
  entity_type text not null check (length(entity_type) <= 80),
  entity_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists audit_logs_actor_created_idx on audit_logs(actor_id, created_at desc);

create table if not exists integration_connections (
  owner_id uuid not null references app_users(id) on delete cascade,
  provider text not null check (provider in ('prospectab','machtkin')),
  endpoint_url text not null check (length(endpoint_url) <= 2048),
  auth_header text not null check (length(auth_header) between 1 and 80),
  auth_prefix text not null check (length(auth_prefix) <= 40),
  encrypted_api_key text not null,
  last_test_at timestamptz,
  last_test_status text check (last_test_status is null or last_test_status in ('connected','http_error','network_error')),
  last_http_status integer check (last_http_status is null or last_http_status between 100 and 599),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (owner_id, provider)
);
