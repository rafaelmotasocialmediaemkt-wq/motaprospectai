-- Human review state is separate from the commercial pipeline stage.
alter table leads add column if not exists review_status text not null default 'pending'
  check (review_status in ('pending', 'approved', 'rejected', 'duplicate'));
alter table leads add column if not exists reviewed_by uuid references app_users(id) on delete set null;
alter table leads add column if not exists reviewed_at timestamptz;
alter table leads add column if not exists duplicate_of uuid references leads(id) on delete set null;
create index if not exists leads_owner_review_created_idx on leads(owner_id, review_status, created_at desc);
