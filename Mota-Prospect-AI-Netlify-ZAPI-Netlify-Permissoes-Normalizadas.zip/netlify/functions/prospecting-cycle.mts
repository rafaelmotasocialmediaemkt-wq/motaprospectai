import { getServerDatabase } from "../../src/infrastructure/netlify/database.server.ts";
import { runScheduledPublicProspecting } from "../../src/infrastructure/netlify/prospecting-workflow.ts";

// Runs one bounded public-search cycle per active workspace during its configured weekday shift.
export default async (): Promise<Response> => {
  const db = getServerDatabase();
  const owners = await db.sql<{ id: string }>`
    select s.owner_id as id
    from user_operating_settings s
    join app_users u on u.id = s.owner_id
    where s.shift_status = 'active'
      and u.is_admin = true and u.team_owner_id is null and u.disabled_at is null
      and extract(isodow from (now() at time zone s.timezone)) between 1 and 5
      and (now() at time zone s.timezone)::time >= s.workday_start
      and (now() at time zone s.timezone)::time < s.workday_end
    order by s.owner_id
  `;
  const cycleKey = String(Math.floor(Date.now() / (15 * 60 * 1000)));
  const outcomes = await Promise.all(owners.map(async (owner) => {
    try {
      const result = await runScheduledPublicProspecting(owner.id, cycleKey);
      return result.skipped ? "skipped" : "completed";
    } catch {
      await db.sql`
        insert into audit_logs(actor_id, action, entity_type, metadata)
        values (${owner.id}, 'prospecting.scheduled_cycle_failed', 'search', ${JSON.stringify({ cycleKey, errorCode: 'cycle_failed' })}::jsonb)
      `;
      return "skipped";
    }
  }));
  const completed = outcomes.filter((outcome) => outcome === "completed").length;
  const skipped = outcomes.length - completed;
  return Response.json({ completed, skipped });
};

export const config = { schedule: "*/15 * * * *" };
