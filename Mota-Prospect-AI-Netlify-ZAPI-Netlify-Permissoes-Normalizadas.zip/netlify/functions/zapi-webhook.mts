import { timingSafeEqual } from "node:crypto";
import { isClearOptOut } from "../../src/application/messaging/opt-out.ts";
import { decryptIntegrationSecret } from "../../src/infrastructure/netlify/integration-secrets.server.ts";
import { getServerDatabase } from "../../src/infrastructure/netlify/database.server.ts";

export const config = { path: "/webhooks/zapi/*", method: ["POST"] };

type ReceivedEvent = {
  instanceId?: string; type?: string; phone?: string; fromMe?: boolean; isGroup?: boolean; isNewsletter?: boolean;
  messageId?: string; momment?: number; text?: { message?: string };
};

export default async (request: Request): Promise<Response> => {
  if (request.method !== "POST") return json(405, { error: "method_not_allowed" });
  const pathKey = new URL(request.url).pathname.split("/").filter(Boolean).at(-1) ?? "";
  if (!/^[A-Za-z0-9_-]{32,}$/.test(pathKey)) return json(404, { error: "not_found" });
  const length = Number(request.headers.get("content-length") ?? 0);
  if (length > 256_000) return json(413, { error: "payload_too_large" });
  let event: ReceivedEvent;
  try { event = await request.json() as ReceivedEvent; } catch { return json(400, { error: "invalid_json" }); }
  if (!event.instanceId || typeof event.phone !== "string" || event.fromMe || event.isGroup || event.isNewsletter || event.type !== "ReceivedCallback") return json(200, { received: true, ignored: true });
  const body = event.text?.message?.trim();
  if (!body || !event.messageId) return json(200, { received: true, ignored: true });

  const db = getServerDatabase();
  const rows = await db.sql<{ owner_id: string; encrypted_secret: string | null; config: Record<string, string> }>`
    select p.owner_id, p.encrypted_secret, p.config from provider_connections p
    join app_users u on u.id = p.owner_id and u.is_admin = true and u.team_owner_id is null and u.disabled_at is null
    where p.provider = 'whatsapp_zapi' and p.config->>'instanceId' = ${event.instanceId} limit 2
  `;
  if (rows.length !== 1 || !rows[0]?.encrypted_secret) return json(404, { error: "instance_not_found" });
  let webhookKey = "";
  try { webhookKey = (JSON.parse(decryptIntegrationSecret(rows[0].encrypted_secret)) as { webhookKey?: string }).webhookKey ?? ""; } catch { return json(503, { error: "webhook_not_configured" }); }
  const actual = Buffer.from(pathKey); const expected = Buffer.from(webhookKey);
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) return json(401, { error: "invalid_webhook_key" });

  const ownerId = rows[0].owner_id;
  const phone = event.phone.replace(/\D/g, "");
  if (phone.length < 10 || phone.length > 15) return json(400, { error: "invalid_phone" });
  const leadRows = await db.sql<{ id: string; opted_out_at: string | Date | null }>`
    select id, opted_out_at from leads where owner_id = ${ownerId}
      and regexp_replace(coalesce(phone, ''), '[^0-9]', '', 'g') = ${phone} limit 2
  `;
  if (leadRows.length !== 1 || !leadRows[0]) return json(200, { received: true, matched: false });
  const lead = leadRows[0];
  const conversationRows = await db.sql<{ id: string }>`
    insert into conversations(owner_id, lead_id, ai_paused, status, last_inbound_at, last_message_at)
    values (${ownerId}, ${lead.id}, true, 'waiting', to_timestamp(${Number(event.momment ?? Date.now())} / 1000.0), to_timestamp(${Number(event.momment ?? Date.now())} / 1000.0))
    on conflict(owner_id, lead_id) do update set ai_paused = true, status = case when conversations.status = 'closed' then 'closed' else 'waiting' end,
      last_inbound_at = greatest(coalesce(conversations.last_inbound_at, '-infinity'::timestamptz), excluded.last_inbound_at),
      last_message_at = greatest(conversations.last_message_at, excluded.last_message_at), updated_at = now()
    returning id
  `;
  const conversation = conversationRows[0];
  if (!conversation) return json(503, { error: "conversation_unavailable" });
  const inserted = await db.sql<{ id: string }>`
    insert into conversation_messages(owner_id, conversation_id, direction, author_kind, body, delivery_status, is_simulated, idempotency_key, external_message_id)
    values (${ownerId}, ${conversation.id}, 'inbound', 'contact', ${body.slice(0, 4000)}, 'received', false, ${`zapi:${event.messageId}`}, ${event.messageId})
    on conflict(owner_id, idempotency_key) do nothing returning id
  `;
  if (!inserted[0]) return json(200, { received: true, duplicate: true });
  if (!lead.opted_out_at && isClearOptOut(body)) {
    await db.sql`update leads set opted_out_at = now(), updated_at = now() where id = ${lead.id} and owner_id = ${ownerId}`;
    await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${ownerId}, 'contact.opt_out_detected', 'lead', ${lead.id}, '{"source":"zapi_webhook","confidence":"explicit"}'::jsonb)`;
  }
  await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${ownerId}, 'zapi.inbound_received', 'conversation', ${conversation.id}, jsonb_build_object('messageId', ${event.messageId}))`;
  return json(200, { received: true, matched: true });
};

function json(status: number, body: Record<string, unknown>): Response {
  return new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });
}
