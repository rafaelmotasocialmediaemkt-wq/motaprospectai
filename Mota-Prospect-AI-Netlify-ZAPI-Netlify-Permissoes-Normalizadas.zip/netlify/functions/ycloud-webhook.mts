import { isClearOptOut } from "../../src/application/messaging/opt-out.ts";
import { hashYCloudPayload, inboundText, mapYCloudStatus, normalizedPhoneDigits, parseYCloudEvent, verifyYCloudSignature } from "../../src/application/messaging/ycloud-webhook.ts";
import { getServerDatabase } from "../../src/infrastructure/netlify/database.server.ts";
import { getYCloudConfiguration } from "../../src/infrastructure/netlify/ycloud-configuration.server.ts";

// The registered YCloud endpoint shown in the account may point to the site root.
// Accept only POSTs there, and keep the explicit path available as well.
export const config = { path: ["/webhooks/ycloud", "/"], method: ["POST"] };

export default async (request: Request): Promise<Response> => {
  if (request.method !== "POST") return json(405, { error: "method_not_allowed" });
  const declaredSize = Number(request.headers.get("content-length") ?? 0);
  if (declaredSize > 1_000_000) return json(413, { error: "payload_too_large" });
  const rawBody = await request.text();
  if (rawBody.length > 1_000_000) return json(413, { error: "payload_too_large" });

  const db = getServerDatabase();
  let ownerId = process.env.YCLOUD_WORKSPACE_ID?.trim() ?? "";
  if (ownerId) {
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(ownerId)) return json(503, { error: "workspace_not_configured" });
    const owner = await db.sql<{ id: string }>`select id from app_users where id = ${ownerId} and is_admin = true and team_owner_id is null and disabled_at is null limit 1`;
    if (!owner[0]) return json(503, { error: "workspace_not_configured" });
  } else {
    const owners = await db.sql<{ id: string }>`select id from app_users where is_admin = true and team_owner_id is null and disabled_at is null order by created_at limit 2`;
    if (owners.length !== 1) return json(503, { error: "workspace_not_configured" });
    ownerId = owners[0]!.id;
  }
  // Resolve the secret only from the server-selected workspace. The request's
  // endpoint ID/header never chooses a workspace or signing secret.
  const ycloud = await getYCloudConfiguration(db, ownerId);
  if (!ycloud.webhookSigningSecret) return json(503, { error: "webhook_not_configured" });
  if (!verifyYCloudSignature(rawBody, request.headers.get("YCloud-Signature"), ycloud.webhookSigningSecret)) return json(401, { error: "invalid_signature" });
  let event;
  try { event = parseYCloudEvent(JSON.parse(rawBody) as unknown); } catch { return json(400, { error: "invalid_event" }); }

  const minimizedPayload = minimizeEvent(event);
  await db.sql`
    insert into ycloud_webhook_events(owner_id, external_event_id, event_type, payload_sha256, payload)
    values (${ownerId}, ${event.id}, ${event.type}, ${hashYCloudPayload(rawBody)}, ${JSON.stringify(minimizedPayload)}::jsonb)
    on conflict(owner_id, external_event_id) do nothing
  `;
  const claim = await db.sql<{ status: string }>`
    update ycloud_webhook_events set status = 'processing', attempts = attempts + 1, last_error_code = null
    where owner_id = ${ownerId} and external_event_id = ${event.id}
      and (status in ('received','failed') or (status = 'processing' and received_at < now() - interval '2 minutes'))
    returning status
  `;
  if (!claim[0]) {
    const existing = await db.sql<{ status: string }>`select status from ycloud_webhook_events where owner_id = ${ownerId} and external_event_id = ${event.id} limit 1`;
    if (existing[0] && ["processed", "unmatched", "ignored"].includes(existing[0].status)) return json(200, { received: true, duplicate: true });
    return json(503, { error: "event_processing" });
  }

  try {
    const result = await processEvent(db, ownerId, event);
    await db.sql`update ycloud_webhook_events set status = ${result}, processed_at = now(), payload = null where owner_id = ${ownerId} and external_event_id = ${event.id}`;
    return json(200, { received: true, result });
  } catch {
    // Keep the minimized event for provider retries; never log message content or credentials.
    await db.sql`update ycloud_webhook_events set status = 'failed', last_error_code = 'processing_error', payload = case when attempts >= 8 then null else payload end where owner_id = ${ownerId} and external_event_id = ${event.id}`;
    return json(503, { error: "processing_error" });
  }
};

async function processEvent(db: ReturnType<typeof getServerDatabase>, ownerId: string, event: ReturnType<typeof parseYCloudEvent>): Promise<"processed" | "unmatched" | "ignored"> {
  if (event.type === "whatsapp.inbound_message.received" && event.whatsappInboundMessage) {
    const incoming = event.whatsappInboundMessage;
    const digits = normalizedPhoneDigits(incoming.from);
    if (!/^\d{8,15}$/.test(digits)) return "unmatched";
    const leads = await db.sql<{ id: string; phone: string | null }>`
      select id, phone from leads where owner_id = ${ownerId} and phone is not null
        and regexp_replace(phone, '[^0-9]', '', 'g') in (${digits}, ${digits.startsWith("55") ? digits.slice(2) : `55${digits}`})
      limit 2
    `;
    if (leads.length > 1) return "unmatched";
    let lead = leads[0];
    if (!lead) {
      const rawProfileName = incoming.customerProfile?.name?.trim() ?? "";
      const profileName = Array.from(rawProfileName).filter((character) => { const code = character.charCodeAt(0); return code >= 32 && code !== 127; }).join("").trim().slice(0, 160) || null;
      const normalizedPhone = `+${digits}`;
      const created = await db.sql<{ id: string; phone: string | null }>`
        insert into leads(owner_id, company_name, contact_name, phone, source, stage, notes, consent_basis, consent_recorded_at)
        values (${ownerId}, ${`Contato WhatsApp ${normalizedPhone}`}, ${profileName}, ${normalizedPhone}, 'ycloud_inbound', 'new', 'Contato criado a partir de mensagem iniciada pelo usuário no WhatsApp.', 'customer_initiated_whatsapp_service_conversation', ${incoming.sendTime && Number.isFinite(Date.parse(incoming.sendTime)) ? new Date(incoming.sendTime).toISOString() : new Date().toISOString()})
        on conflict do nothing returning id, phone
      `;
      if (created[0]) {
        lead = created[0];
        await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${ownerId}, 'lead.created_from_ycloud_inbound', 'lead', ${lead.id}, '{"source":"ycloud_inbound"}'::jsonb)`;
      } else {
        const existing = await db.sql<{ id: string; phone: string | null }>`select id, phone from leads where owner_id = ${ownerId} and phone is not null and regexp_replace(phone, '[^0-9]', '', 'g') in (${digits}, ${digits.startsWith("55") ? digits.slice(2) : `55${digits}`}) limit 2`;
        if (existing.length !== 1) return "unmatched";
        lead = existing[0];
      }
    }
    const body = inboundText(event) || `[Mensagem do tipo ${incoming.type}]`;
    const createdAt = incoming.sendTime && Number.isFinite(Date.parse(incoming.sendTime)) ? new Date(incoming.sendTime).toISOString() : new Date().toISOString();
    const conversations = await db.sql<{ id: string }>`
      insert into conversations(owner_id, lead_id, status, ai_paused, last_inbound_at, last_message_at, automation_mode)
      values (${ownerId}, ${lead.id}, 'waiting', true, ${createdAt}, ${createdAt}, 'assisted')
      on conflict(owner_id, lead_id) do update set status = 'waiting', ai_paused = true,
        last_inbound_at = greatest(coalesce(conversations.last_inbound_at, ${createdAt}), ${createdAt}),
        last_message_at = greatest(conversations.last_message_at, ${createdAt}), updated_at = now()
      returning id
    `;
    const conversationId = conversations[0]!.id;
    await db.sql`
      insert into conversation_messages(owner_id, conversation_id, direction, author_kind, body, delivery_status, is_simulated, external_message_id, message_type, created_at)
      values (${ownerId}, ${conversationId}, 'inbound', 'contact', ${body.slice(0, 4000)}, 'received', false, ${incoming.id}, ${incoming.type.slice(0, 40)}, ${createdAt})
      on conflict do nothing
    `;
    if (isClearOptOut(body)) {
      await db.sql`update leads set opted_out_at = coalesce(opted_out_at, now()), updated_at = now() where id = ${lead.id} and owner_id = ${ownerId}`;
      await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${ownerId}, 'contact.opt_out_detected', 'lead', ${lead.id}, '{"source":"ycloud_inbound","confidence":"explicit"}'::jsonb)`;
    }
    await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${ownerId}, 'ycloud.inbound_message_received', 'conversation', ${conversationId}, jsonb_build_object('providerMessageId', ${incoming.id}, 'messageType', ${incoming.type}))`;
    return "processed";
  }
  if (event.type === "whatsapp.message.updated" && event.whatsappMessage) {
    const update = event.whatsappMessage;
    const status = mapYCloudStatus(update.status);
    const externalCorrelationId = update.externalId ?? "";
    if (!status) return "ignored";
    const ranks = { queued: 0, accepted: 1, sent: 2, delivered: 3, read: 4, failed: 5, unknown: 0, cancelled: 5, received: 0, simulated: 0 };
    await db.sql`
      update conversation_messages set
        delivery_status = case when ${ranks[status]} >= case delivery_status
          when 'queued' then 0 when 'unknown' then 0 when 'accepted' then 1 when 'sent' then 2 when 'delivered' then 3 when 'read' then 4 when 'failed' then 5 when 'cancelled' then 5 else -1 end
          then ${status} else delivery_status end,
        external_message_id = coalesce(external_message_id, ${update.id}),
        failure_reason = case when ${status} = 'failed' then left(coalesce(${update.errorCode ?? ""}, 'provider_failure'), 160) else failure_reason end
      where owner_id = ${ownerId} and (external_message_id = ${update.id} or (${externalCorrelationId} <> '' and correlation_id = ${externalCorrelationId}))
    `;
    return "processed";
  }
  return "ignored";
}

function minimizeEvent(event: ReturnType<typeof parseYCloudEvent>): Record<string, unknown> {
  if (event.type === "whatsapp.inbound_message.received" && event.whatsappInboundMessage) {
    const message = event.whatsappInboundMessage;
    return { id: event.id, type: event.type, createTime: event.createTime, whatsappInboundMessage: { id: message.id, from: message.from, to: message.to, type: message.type, sendTime: message.sendTime, customerProfile: { name: message.customerProfile?.name?.slice(0, 160) }, text: { body: message.text?.body?.slice(0, 4000) }, button: message.button ? { text: message.button.text, payload: message.button.payload } : undefined, interactive: message.interactive } };
  }
  return { id: event.id, type: event.type, createTime: event.createTime, whatsappMessage: event.whatsappMessage ? { id: event.whatsappMessage.id, externalId: event.whatsappMessage.externalId, status: event.whatsappMessage.status, errorCode: event.whatsappMessage.errorCode } : undefined };
}

function json(status: number, body: unknown): Response { return new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } }); }
