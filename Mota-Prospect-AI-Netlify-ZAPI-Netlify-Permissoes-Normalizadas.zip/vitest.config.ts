import { defineConfig } from "vitest/config";

// Keep unit tests independent from the Start SSR/dev-server plugin.
export default defineConfig({ test: { environment: "node", include: ["src/**/*.test.ts"], fileParallelism: false } });
