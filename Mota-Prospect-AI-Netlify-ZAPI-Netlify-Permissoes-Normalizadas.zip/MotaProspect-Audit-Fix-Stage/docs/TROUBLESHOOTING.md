# Solução de problemas

## Inbox não carrega

- Confirme que entrou com uma conta do workspace.
- Confirme que Netlify Database está habilitado e as migrações foram aplicadas.
- O modo DEMO baseado em `localStorage` não se autentica no banco. Para validar persistência, use o modo autenticado (`VITE_MOTA_DEMO_MODE=false`) com a base local em execução.

## Conversa não pode ser respondida

- A inbox só registra respostas simuladas. Não abre chamada de envio à Meta.
- Contatos com `opted_out_at` não aceitam nem mesmo resposta de saída simulada.
- Conversas encerradas precisam ser reabertas antes de registrar mensagens.

## WhatsApp Cloud API

O botão existente testa leitura e não envia mensagens. Sem webhook oficial implementado, mensagens externas não aparecem na inbox. Verifique as instruções e pendências em [WHATSAPP_INTEGRATION.md](WHATSAPP_INTEGRATION.md).

## Testes locais

Em Windows restrito, direcione `TEMP`/`TMP` para uma pasta gravável do projeto antes de `npm test -- --maxWorkers=1`. Os testes usam mocks/banco efêmero e não enviam mensagens reais.
