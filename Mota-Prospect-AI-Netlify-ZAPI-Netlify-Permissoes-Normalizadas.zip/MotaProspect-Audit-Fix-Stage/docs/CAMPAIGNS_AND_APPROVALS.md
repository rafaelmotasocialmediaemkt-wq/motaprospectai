# Campanhas e aprovações

Campanhas de saída e automações ainda não estão implementadas. Não há destinatários importados para campanhas nem envio em lote.

A revisão de leads existente é uma decisão humana sobre o registro pesquisado. Aprovar uma empresa **não** aprova campanha, não sincroniza CRM e não concede autorização para contatá-la.

Antes de criar execução de campanha, implementar versões imutáveis de script/audiência, aprovação vinculada a essa versão, elegibilidade atualizada por contato, limite/frequência/janela por canal, idempotência, trilha de auditoria e kill switch global. O modo simulado deve continuar sendo o padrão.
