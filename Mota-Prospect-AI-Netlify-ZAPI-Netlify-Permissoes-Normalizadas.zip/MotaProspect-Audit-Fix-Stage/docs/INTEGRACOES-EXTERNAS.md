# Integrações externas — estado e configuração

## Implementações da revisão de 19/10/2026

- **Gemini:** usado para rascunhos de resposta supervisionados, com a metodologia de atendimento em oito etapas do manual interno incorporada à instrução do modelo. A chave deve estar em `GEMINI_API_KEY` no ambiente server-side. Não envia mensagens automaticamente, agenda reuniões nem escreve na MachtKin.
- **Pesquisa pública na web:** SerpApi documenta `https://serpapi.com/search?engine=google`. Configurada a chave, o botão de início faz uma consulta por expediente usando segmento, primeiro termo e região. A operação pode ser cobrada conforme o plano do provedor. O orçamento preenchido no Mota é apenas um gate de autorização maior que zero; não é um limite de cobrança nem consulta o saldo SerpApi.
- **Consulta pública de CNPJ:** consulta sem chave por `GET https://brasilapi.com.br/api/cnpj/v1/{cnpj}` (BrasilAPI / Minha Receita). Durante a execução do expediente, até 4 CNPJs que aparecem explicitamente nos resultados podem ser consultados; número, empresa, município/UF e CNAE alimentam o lead. Sem CNPJ explícito, o candidato permanece como resultado público não verificado. Não consulta CPF/QSA.
- **Serpro/Receita:** os campos de endpoint contratado e credencial ficam disponíveis, mas o app não chama a Receita sem o contrato específico do cliente e autenticação confirmada.
- **Calendly:** OAuth Authorization Code + PKCE implementado, com tokens cifrados no servidor. Registre `https://<dominio>/integrations` como redirect URI (local: `http://localhost:<porta>/integrations`). O fluxo solicita `users:read` e `scheduled_events:read` para exibir eventos. Uma função de agendamento também verifica disponibilidade e cria invitee, mas ainda não está conectada à conversa da Inbox nem à criação/envio automático do link do Meet.
- **WhatsApp Web:** o caminho `/whatsapp` redireciona para a Inbox YCloud. Não se usa automação de sessão não oficial.
- **WhatsApp Cloud API:** configuração manual da API oficial Meta e teste somente de leitura. Para sincronizar dentro do CRM, ainda são necessários app Meta aprovado, Embedded Signup quando elegível, webhook assinado e implantação dos fluxos de mensagem. Nenhum envio é habilitado.

Os segredos dessas integrações são cifrados AES-256-GCM e isolados por usuário. Esta revisão não executou chamadas externas nem publicou o app.

## Equipe e atendimento humano

A migração `202610190003_team_access.sql` adiciona vínculo de membro ao workspace, solicitações de atendimento humano, CNPJ opcional nos leads e idempotência de pesquisa por expediente. A conta administradora pode criar e bloquear logins comerciais. Membros veem e editam leads do workspace; funções server-side limitam preferências, integrações, expediente e gestão de equipe à conta administradora. Cada operação de negócio continua registrando o usuário que a executou.

A fila de atendimento salva solicitações no banco e atualiza a tela aberta a cada 30 segundos. Notificações do navegador exigem permissão concedida. Não há Web Push se a página/navegador estiver fechado. Como o Dealism não está ligado ao backend, solicitações de humanos ainda precisam ser abertas por um membro; não há detecção automática de intenção em mensagens.

## Prospecção iniciada pelo expediente

O botão inicia o expediente e, após confirmação na interface, faz uma solicitação externa de busca. O servidor exige autenticação de administradora, filtros preenchidos, chave SerpApi e orçamento de referência não zero. Uma linha `prospecting_runs` única por workspace/horário de início impede reexecução acidental. A única pesquisa retorna e pode registrar no máximo 20 candidatos; leads públicos são criados em etapa `new`, com fonte e URL, sem contato pessoal, e colisões por nome ou CNPJ são ignoradas.

O endpoint é síncrono e executa uma única busca; não fica ativo como worker. O Dealism não é chamado e os leads não são qualificados por IA. Nenhuma mensagem ou ligação é iniciada pelo fluxo. A pesquisa poderá gerar cobrança por conta do plano SerpApi; o app não lê nem aplica teto financeiro real.

## Credenciais

As chaves de API fornecidas na conversa não foram gravadas no projeto, no `.env.example` nem no ZIP. Como são chaves com prefixo `live` e foram compartilhadas em uma conversa, revogue-as e gere novas antes de configurar o sistema. Cadastre credenciais novas apenas no ambiente seguro do servidor, nunca no navegador ou em arquivos versionados.

## Prospectab

Endpoint informado pelo operador: `https://prospectab.lovable.app/api/public/v1/leads?limit=50`.

O endereço não pôde ser validado pelos meios de documentação/web disponíveis nesta execução. Não foi feita chamada autenticada. Permanecem desconhecidos o header/formato de autenticação, o esquema de retorno, a semântica de `limit`, paginação, filtros, rate limit, deduplicação, política de conflito e se a API é somente leitura. Portanto, nenhum adaptador afirma sincronizar ou importar leads ainda.

## MachtKin CRM

Endpoint informado pelo operador: `https://machtkin.lovable.app/api/public/v1/leads`.

O endereço não pôde ser validado pelos meios de documentação/web disponíveis nesta execução. Não foi feita chamada autenticada. Permanecem desconhecidos o header/formato de autenticação, o esquema de retorno, paginação, rate limit, operações permitidas e política de conflito. Nenhum endpoint de escrita foi presumido ou chamado.

Para finalizar os adaptadores, forneça a documentação OpenAPI ou documentação oficial dessas aplicações, incluindo exemplos sintéticos de resposta e o header esperado. Depois será possível implementar importação somente de leitura, mapeamento validado, idempotência, paginação e testes com resposta falsa. Escrita/atualização no CRM precisa ser especificada separadamente.

## Dealism

O portal público do Dealism descreve agentes de atendimento e conexões de canais, mas não foi possível confirmar um contrato público de API de desenvolvedor para controlar esse agente externamente. Sem documentação, client credentials ou sandbox, o Mota não simula chamadas. A integração fica bloqueada até o fornecedor confirmar API, OAuth, escopos, webhooks, limites e suporte à prospecção iniciada pelo agente.

## Pesquisa Google

O Custom Search JSON API usa API key e Programmable Search Engine, mas a Google documenta que não está disponível para novos clientes e será descontinuada em 1º de janeiro de 2027. Por isso, a busca não é habilitada como integração padrão nem implementada por scraping da página de resultados.

## Consulta de CNPJ

A API CNPJ do Conecta gov.br/SERPRO tem endpoints documentados para consultas Básica, QSA e Empresa, com autenticação e elegibilidade institucional. A Receita Federal publica arquivos de dados abertos para download, mas não um endpoint público gratuito e irrestrito para consulta online por empresas privadas. A tela do Mota usa a API pública de terceiros BrasilAPI/Minha Receita para consulta pontual; isso não substitui comprovante oficial nem garante disponibilidade ou atualização em tempo real. Para uso em escala com a fonte oficial, é necessário desenhar carga periódica dos arquivos abertos e dimensionar storage/worker; esse pipeline não está implementado.

O retorno enviado à interface inclui apenas campos empresariais permitidos e não inclui o quadro de sócios/CPF. As consultas são manuais e não são enviadas automaticamente ao agente de IA.

## Calendly

A API v2 oficial oferece OAuth e endpoints de agendamento. O app contém OAuth Authorization Code + PKCE e criação de convite sob confirmação; não importa a lista de eventos existentes nem implementa webhooks/cancelamento. A aba Agendamentos exibe o estado da conexão e o link público de booking configurado. O campo Client ID aceita identificador OAuth, não URL de servidor MCP.

## WhatsApp Business / Peach

Peach for WhatsApp Business é um conector de ChatGPT, não uma API/SDK que possa ser incorporada ao ZIP como serviço do app. A descoberta de plugins deste ambiente não retornou Peach nem ações WhatsApp que possam ser chamadas pelo aplicativo.

O WhatsApp Web é aberto em uma nova aba para login manual. O app não envia, recebe ou sincroniza mensagens por essa sessão e não inicia chamadas. Para uma integração executável no CRM, é necessário API oficial e webhook configurados. Nenhuma mensagem foi enviada nesta execução.

## O que o ZIP inclui

O app possui agora uma aba de configuração para endpoint, header de autenticação e API key de Prospectab/MachtKin. As credenciais ficam cifradas com AES-256-GCM no banco Netlify, isoladas pelo usuário autenticado. O teste manual faz apenas um GET controlado e descarta a resposta, sem importar nem alterar registros. A tela não exige chave extra: usa uma chave explícita opcional server-side ou deriva uma chave da conexão secreta Netlify Database. Confirme com os provedores o header/formato correto. Ainda não há sincronização/importação porque os schemas de resposta e paginação não foram verificados.

O pacote não contém credenciais nem um cliente incorporado do Peach. A aba informa que não há envio de mensagens no aplicativo.

Preferências operacionais e botões de IA/expediente salvam estado por usuário no Netlify Database. Esses botões são controles persistidos, não workers: buscas, consultas externas, IA Gemini, mensagens e agendamentos não executam automaticamente até existir infraestrutura e contratos configurados.
