# Origem e limites do levantamento

Data do levantamento: 2026-10-16.

## Evidências consultadas

- Projeto Lovable visível: “Remix of Mota Prospect AI”.
- Metadado do projeto: template `tanstack_start_ts_current`.
- `docs/STATUS.md` descreve mocks de Prospectab, MachtKin, Calendar e WhatsApp sandbox; tela `/simulator`; auditoria por `ai_actions`, `integration_events`, `conversation_states`; e núcleo `src/lib/engine/agent.ts`.
- O mesmo documento menciona caminhos HTTP de Prospectab e MachtKin e deixa pendentes autenticação, nomes de campos e valores de fase.
- A árvore visível inclui `drizzle/schema.ts`, mas o conteúdo que abriu estava vazio (“auto-generated and intentionally left blank”).
- O editor exibiu “Read only”; não havia sincronização Git conectada. O arquivo `.env` foi deliberadamente ignorado.

## Decisões desta reconstrução

- Iniciar um app local novo baseado em TanStack Start e TypeScript, sem editar o projeto de origem.
- Tratar todos os dados locais como demonstração fictícia.
- Não assumir que as integrações têm APIs disponíveis ou contratos validados. A documentação visível no projeto é uma pista a verificar com cada fornecedor.
- Deixar IA, WhatsApp, prospecção externa e calendários reais desligados.
- Criar uma migração SQL local para revisão, sem aplicar a qualquer banco.

## Pendências antes de produção

1. Obter exportação integral do código-fonte original e comparar módulos/funcionalidades.
2. Definir organização, identidade, autenticação, autorização, retenção e políticas RLS.
3. Validar documentação de APIs de Prospectab e MachtKin diretamente com os fornecedores.
4. Configurar ambiente de teste oficial da Meta/WhatsApp e validar assinatura e assinatura de webhook.
5. Escolher provedor de IA, orçamento, política de dados e fluxo de aprovação humana.
6. Implementar agenda real, filas persistidas e observabilidade com idempotência.
