# Estado de implementação

Atualizado em 21/10/2026. Esta cópia não é um repositório Git; não há histórico de commits. Nenhum site, banco hospedado, credencial ou serviço de terceiros foi conectado nesta execução.

## O que existe

| Requisito | Estado | Limite conhecido |
|---|---|---|
| Leads e funil | CRUD, busca, filtros, paginação, importação CSV com prévia, exportação e deduplicação básica | A etapa de contato autorizado exige captura de consentimento ainda não implementada. |
| Persistência e autenticação | Funções server-side, Netlify Database, senha scrypt, sessão opaca em cookie HttpOnly, logout, bloqueio por tentativas e cadastro único do primeiro administrador pela interface | Migrações e fluxo validados em banco efêmero local; site Netlify de desenvolvimento ainda não testado. Sem convite, recuperação de senha ou gestão de usuários adicionais. |
| Auditoria | Criação/edição/mudança de etapa e eventos básicos de autenticação são gravados server-side | Sem trilha de exportação, administração de usuários ou monitoramento. |
| Bloqueio de contato | Administrador e vendedor podem marcar um lead com opt-out; a marcação é persistida, aparece na lista e gera auditoria server-side | Nenhum canal de envio automático está ativo; futuras integrações devem consultar `opted_out_at` antes de qualquer contato. |
| Revisão de prospecção | Fila em Leads com filtros e decisões persistidas (pendente, aprovado, rejeitado, duplicado), autor, horário e auditoria | A aprovação não sincroniza com o CRM nem autoriza mensagens. Score configurável e evidências por campo ainda pendentes. |
| Limite de pesquisa | Reserva atômica no banco por workspace/dia, no máximo 30 candidatos e 6 consultas SerpApi/dia; agendador a cada 15 minutos durante expediente ativo em dias úteis | Sem sincronização CRM não confirmada; o sistema só cadastra candidatos para revisão. |
| Inbox/YCloud | Webhook HMAC, deduplicação, associação de inbound a lead único, opt-out central, status callback, envio manual supervisionado; credenciais podem ser salvas cifradas via painel e são lidas do banco em runtime | Requer migração, URL webhook cadastrada e teste de conexão da conta. Sem templates ou follow-up; nenhum envio automático. |
| Integrações de CRM | Aba salva endpoints e credenciais cifradas por proprietário; teste somente GET, timeout e redirect bloqueado | APIs e headers precisam ser confirmados com documentação do fornecedor; nenhum lead é sincronizado. |
| Dealism | Campos editáveis para endpoint, header/prefixo e API key cifrada | Não executar chamadas até Dealism fornecer contrato/API verificável. |
| Pesquisa Google e CNPJ | Pesquisa manual via SerpApi e consulta manual CNPJ.BIZ v2 implementadas no servidor | Chaves necessárias; cada pesquisa pode ter custo; resultados não criam leads automaticamente. Serpro permanece bloqueado até contrato e auth específicos. |
| Calendly | OAuth oficial Authorization Code + PKCE, armazenamento cifrado, refresh token, validação de disponibilidade e criação de evento após confirmação | Requer OAuth app/redirect URI, scopes e plano pago Calendly; nenhum evento criado nesta execução. |
| WhatsApp, webhooks, tarefas e workers | YCloud backend adicionado ao lado da configuração Meta legado; envio só é habilitado manualmente por admin; função `/webhooks/ycloud` valida assinatura e estados | Sem execução automática, campanhas, follow-up worker, templates aprovados, AI de conversas ou sincronização confirmada ao MachtKin. Webhook externo ainda não foi registrado nem testado. |
| Dashboard | Contagens derivadas de leads disponíveis | Não inclui dados de tarefas, reuniões ou conversas inexistentes. |
| Segurança | Validação server-side, isolamento por `owner_id`, hashes de senha, cookies seguros em produção, limites por conta e cifragem de credenciais externas | Sem rate limit por IP, organização/time, recuperação de conta ou revisão de produção. |

## Mudanças desta entrega

- Configuração YCloud do painel Integrations é armazenada cifrada no banco e consultada pelo backend por chamada; mudanças não exigem redeploy e invalidam o teste anterior.
- Novo cron de prospecção Netlify executa ciclos a cada 15 minutos enquanto o expediente estiver ativo, em dias úteis e dentro do horário/fuso configurados. Limite de seis buscas públicas e 30 candidatos/dia.
- Google Calendar mostra e copia o redirect URI exato do domínio atual, e a montagem do OAuth usa o Client ID efetivamente resolvido pelo backend.

- Removido o cliente e pacote de autenticação externo, as variáveis associadas e a pasta de migração legada.
- Criada migração adicional para hashes de senha, sessões, lockout e claim singleton do bootstrap.
- Login e logout trabalham por cookie HttpOnly; endpoints privados leem e validam a sessão diretamente no server handler. O token bruto não é enviado no body nem persistido no banco.
- Primeiro administrador pode ser criado uma vez pela aba Cadastro, somente se o banco não tiver usuários. O servidor recusa cadastros subsequentes.
- Preferências operacionais são criadas sob demanda pelo handler autenticado após migração de schema; o estado IA/expediente é isolado por conta e auditado.
- Adicionada migração de preferências para filtros, custos, horário, revisão humana, estado do agente e do expediente; Configurações expõe os campos e botões correspondentes.
- A chave AES das integrações agora deriva automaticamente da connection string secreta Netlify Database quando não há override explícito, removendo a configuração manual exibida na captura; override explícito permanece recomendado para rotação do DB.
- Demonstração usa `localStorage` somente no Vite local. Defina `VITE_MOTA_DEMO_MODE=false` para testar autenticação e banco localmente; em produção a demonstração está sempre desligada.
- Nenhuma mensagem real, sincronização de CRM, escrita externa, deploy ou migração remota foi executada.

## Verificação executada

Executados com sucesso `npm run typecheck`, `npm run lint`, `npm run build` e `npm test` (11 arquivos, 37 testes). A suíte de testes valida a criação das tabelas novas, mas o fluxo OAuth e chamadas de provedores ainda dependem de credenciais e validação integrada em deploy preview. A conexão com um site Netlify hospedado ainda requer configuração do operador.

## Dependências e riscos operacionais

- Netlify Database precisa estar habilitado no site correto e receber as migrações em ordem.
- Restrinja o site até criar a primeira conta, pois o cadastro inicial é aberto enquanto o banco está vazio.
- `MOTA_INTEGRATION_ENCRYPTION_KEY` é opcional. Sem ela, a chave é derivada da conexão secreta Netlify DB; rotação da connection string pode exigir reconfigurar as credenciais cifradas. Uma chave explícita estável evita esse risco.
- Ativar IA e iniciar expediente registram controles, mas não executam automações até que provedor verificado, APIs e worker persistente estejam implementados.
- Não existe recuperação de senha nesta fase; preservar credencial do primeiro administrador é importante até a implementação de um processo seguro de reset.
- Custos e limites de banco dependem da conta Netlify e não foram verificados.

## Atualização de equipe, pesquisa e canais (19/10/2026)

- Migração `202610190003_team_access.sql`: adiciona membros de workspace, CNPJ normalizado em leads, solicitações de handoff e registro idempotente de pesquisa por expediente.
- A conta administradora pode criar/bloquear logins comerciais. Membros compartilham o funil e têm acesso aos leads, mas mutações de integração e controles operacionais continuam limitadas no servidor à administradora. A auditoria registra o ator individual.
- **WhatsApp**: nova aba abre o site WhatsApp Web e links de conversa para ação manual. Mensagens, chamadas e histórico não sincronizam com o CRM; a Cloud API oficial ainda está em leitura somente.
- **Atendimento humano**: fila persistida, atribuição/conclusão e notificações do navegador com polling de 30 segundos enquanto a tela está aberta. Web Push com navegador fechado e detecção de pedido pela conversa aguardam infraestrutura e canal inbound.
- **Agendamentos**: a página agora mostra estado OAuth e link de booking HTTPS oficial Calendly configurado. Lista de eventos Calendly ainda não importada. URLs MCP não são aceitas como OAuth Client ID.
- **Expediente**: após confirmação, uma única busca SerpApi pode registrar até o limite configurado em leads novos; no máximo quatro CNPJs explícitos são enriquecidos via BrasilAPI/Minha Receita. Não há qualificação Dealism, mensagens ou ligações automáticas. Custo real SerpApi não é consultado nem limitado pelo campo de orçamento.
- Dealism permanece sem chamada porque as credenciais OAuth/MCP exibidas para integração do Codex não são documentação/API de servidor para este aplicativo. Não foram enviadas mensagens, feitas buscas externas, aplicadas migrações em produção ou publicadas alterações.

## Bloqueio de contato (19/10/2026)

- Leads agora exibem o estado de contato bloqueado e oferecem ação explícita com confirmação humana.
- A ação grava `leads.opted_out_at` no banco e registra `lead.contact_suppressed` na auditoria na mesma consulta. O modo local de demonstração persiste o estado apenas no `localStorage` e continua identificado como DEMO.
- Isso cria o controle persistente de opt-out; não significa que WhatsApp, voz ou follow-up estejam integrados. Qualquer canal futuro deve revalidar esse campo no servidor imediatamente antes do envio.
- Validação: typecheck, lint, 45 testes em 13 arquivos e build passaram. O primeiro teste tentou usar uma pasta temporária do sandbox sem acesso; repetido com `TEMP` apontando para `.test-tmp` dentro do projeto, sem alterar configuração do runner.

## Prompt 2 — revisão humana (19/10/2026)

- Migração `202610190004_lead_review.sql` adiciona estado de revisão separado do pipeline comercial, responsável, instante da decisão e referência opcional ao lead original em caso de duplicidade.
- A página Leads inicia no filtro de revisão pendente, mostra a origem e URL pública registrada para resultados de pesquisa, e permite aprovar/rejeitar com confirmação. O estado do CRM e a etapa comercial não são alterados por essas decisões.
- Aprovação/rejeição são validadas no servidor, escopadas ao workspace e gravadas junto com evento de auditoria. Opt-out permanece disponível na mesma fila.
- CRM continua sem adaptador de escrita: falta contrato verificável do MachtKin (autenticação, schemas, busca, idempotência e operações). Nenhum botão afirma que sincronizou.
- Migração `202610190005_daily_prospecting_limit.sql` adiciona contador atômico por data local operacional. A rotina reserva capacidade antes da chamada SerpApi e devolve vagas não utilizadas quando a busca retorna menos candidatos. Concorrência que não consegue reservar capacidade é recusada.
- Validação: typecheck, lint, 47 testes em 13 arquivos e build de produção passaram. Migrações não foram aplicadas em ambiente hospedado.

## Prompt 3 — inbox simulada (19/10/2026)

- Migração `202610190006_mock_inbox.sql` adiciona conversas únicas por lead/workspace, mensagens com chave idempotente e marcação explícita de simulação, e notas privadas.
- `/inbox` lista conversas persistidas, cronologia, contexto do lead, permite abrir conversa para lead, assumir atendimento, encerrar/reabrir, controlar a pausa de assistência, registrar mensagens de teste e notas internas.
- Mensagem simulada de saída é recusada quando há opt-out ou conversa encerrada. Mensagem simulada de entrada pausa assistência, coloca o estado em espera e, para expressões inequívocas, grava opt-out e auditoria. Conteúdo ambíguo não causa bloqueio automático.
- WhatsApp real: nenhuma mensagem é enviada/recebida; o caminho Cloud API existente segue apenas leitura. O toggle de assistência não chama IA. Webhook, campanhas e automação restrita não existem.
- Validação: typecheck, lint, 50 testes em 14 arquivos e build de produção passaram. A migração não foi aplicada em ambiente hospedado. Validação ponta a ponta do app ainda requer banco local/autenticado.

## YCloud WhatsApp (19/10/2026)

- Migração `202610190007_ycloud_whatsapp.sql`: opt-in de envio por workspace, modo assistido padrão, correlação/status externo de mensagens e tabela idempotente de eventos webhook.
- O adaptador usa `POST https://api.ycloud.com/v2/whatsapp/messages` com `X-API-Key`, envio enfileirado, `externalId`, `filterUnsubscribed` e `filterBlocked`. Requisições aceitas não são mostradas como entregues; status callbacks avançam aceito/enviado/entregue/lido/falha sem downgrade fora de ordem.
- O endpoint `/webhooks/ycloud` valida HMAC-SHA256 do corpo bruto, valida timestamp com janela de replay de 5 minutos, persiste/deduplica antes de processar e limita o payload. Inbound é associado somente se um único lead existente corresponder ao telefone; contatos não são criados automaticamente. Opt-out explícito bloqueia o lead.
- Inbox continua simulada por padrão. Admin precisa habilitar YCloud depois de preencher secrets no backend; cada envio real tem uma confirmação humana, é limitado a 24h de inbound real e muda a conversa para modo humano. 4xx grava falha; timeout, 5xx ou resposta inválida grava estado incerto e bloqueia repetição automática.
- Nenhuma credencial foi configurada e nenhum request real foi enviado. Testes cobrem contrato e assinatura com mocks sintéticos. A implementação ainda precisa de validação em ambiente de teste YCloud.
- Pendências: provedor de geração de sugestões de conversa (a interface foi criada, sem provedor conectado), templates aprovados e fluxo de primeiro contato, fila de follow-ups inexistente, UI para evento sem lead, contrato MachtKin e elegibilidade de Calling no Brasil/conta não confirmados. Nenhum desses itens é apresentado como concluído.

### Validação desta atualização

`npm run typecheck`, `npm run lint`, `npm test` (13 arquivos, 44 testes) e `npm run build` passaram em execução local. Os testes cobrem migração de schema, escopo de equipe, autorização admin, deduplicação e validação/sanitização de dados públicos. Execução do botão, APIs reais, OAuth Calendly, push remoto e uso da equipe precisam de configuração e validação após publicar em ambiente controlado.
