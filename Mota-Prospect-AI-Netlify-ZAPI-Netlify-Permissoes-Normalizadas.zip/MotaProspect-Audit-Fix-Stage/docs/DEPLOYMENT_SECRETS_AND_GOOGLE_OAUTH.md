# Segredos e Google Calendar

## Segredos do servidor

Não coloque credenciais reais no repositório, em `VITE_*`, nem no ZIP de distribuição. Integrações com tela própria podem ser salvas no painel autenticado e ficam cifradas no Netlify Database, reconhecidas pelo backend sem novo deploy. Para os fallbacks por ambiente, cadastre as variáveis em **Netlify → Site configuration → Environment variables**, com escopo Functions, e publique um novo deploy:

- `SERPAPI_API_KEY`: chave de pesquisa usada pelo expediente e pela busca manual. Também é possível salvar a chave na área Integrações, onde é cifrada no banco.
- `GOOGLE_OAUTH_CLIENT_ID` e `GOOGLE_OAUTH_CLIENT_SECRET`: credenciais OAuth Web; como alternativa, salve-as cifradas no cartão Google Calendar em Integrações.
- `YCLOUD_API_KEY`, `YCLOUD_PHONE_NUMBER` e `YCLOUD_WEBHOOK_SIGNING_SECRET`: podem ser salvos no cartão **Integrações → WhatsApp via YCloud**; o app cifra os segredos e lê a configuração diretamente do banco em cada chamada. As variáveis server-side são fallback.
- `YCLOUD_WORKSPACE_ID`: opcional se há um único workspace administrador ativo (o app o resolve pelo banco). Se houver mais de um, informe o UUID do administrador correto; IDs de telefone/WABA não servem aqui.
- `GEMINI_API_KEY` e opcionalmente `GEMINI_MODEL`: credenciais do assistente de resposta revisável da Inbox.
- `MOTA_INTEGRATION_ENCRYPTION_KEY`: opcional; chave hex de 32 bytes para cifrar credenciais guardadas no Netlify Database.

As chaves fornecidas no chat não são incluídas no código nem no ZIP. Variáveis do Netlify só chegam às Functions no próximo deploy; alterações feitas no cartão de integração entram em vigor sem redeploy.

## Google Calendar e Meet

1. No Google Cloud, habilite a Google Calendar API e configure uma credencial OAuth **Web application**. Na tela **Integrações → Google Calendar + Meet**, copie a URI de retorno exibida para o domínio aberto e cadastre-a como URI de redirecionamento autorizada. O formato é `https://<dominio-publicado>/integrations?oauth=google`. A URL deve corresponder exatamente ao parâmetro `redirect_uri` enviado pelo app, incluindo protocolo, domínio, caminho e query string; uma divergência causa `redirect_uri_mismatch`. Em desenvolvimento use a origem local e o caminho correspondente.
2. Em **Integrações → Google Calendar + Meet**, salve o Client ID e Client Secret OAuth. O segredo é cifrado no servidor e não retorna ao navegador.
3. Clique em **Conectar Google Calendar** e conclua o consentimento da conta. Depois, crie o evento e o link Meet pela própria tela. Um convidado só recebe convite se o e-mail for informado.

A autorização OAuth e a criação de eventos são ações feitas pela conta do usuário; não são executadas no build do ZIP.

## Webhook YCloud

Registre `https://<dominio-publicado>/webhooks/ycloud` como webhook e assine os eventos `whatsapp.inbound_message.received` e `whatsapp.message.updated`. O app também aceita POST assinado na raiz do domínio, para compatibilidade com endpoint já configurado assim. Na Inbox, o administrador pode testar a leitura do número; o envio supervisionado só é habilitado após a validação. O envio é manual, pede confirmação humana e respeita a janela de atendimento e os opt-outs. Mensagens inbound de números novos criam um lead de origem `ycloud_inbound` para que a conversa apareça na Inbox.

O kit oficial YCloud utilizado na implementação proíbe chamadas de API com credenciais reais neste fluxo de desenvolvimento. Portanto, a integração foi entregue no backend; teste a conexão com o botão da Inbox depois de salvar os dados. O envio segue desativado até um teste conectado e permanece humano e supervisionado.
