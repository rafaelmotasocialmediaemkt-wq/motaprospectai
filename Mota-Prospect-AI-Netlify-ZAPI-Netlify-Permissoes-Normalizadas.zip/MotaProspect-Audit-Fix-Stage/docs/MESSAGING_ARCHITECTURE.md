# Arquitetura de mensagens

## Estado atual

A rota `/inbox` usa tabelas próprias no Netlify Database para conversas, mensagens de teste e notas internas. O escopo de leitura e escrita é sempre filtrado pelo workspace autenticado. Uma conversa é única por lead/workspace. Mensagens de entrada simuladas exigem chave idempotente; mensagens de saída no mock só são gravadas se o lead não estiver bloqueado e a conversa estiver aberta.

`is_simulated=true` e `delivery_status=simulated` identificam mensagens de teste. Esses estados não são aceitação, envio, entrega nem leitura no WhatsApp. Real YCloud sends require admin enablement and a human action; free text is allowed only within 24 hours of a real inbound message. YCloud's queued response is `accepted`, not delivery. Status callbacks advance messages through documented states. `unknown` marks an ambiguous request and prevents blind retries. Notas ficam em `conversation_notes`, aparecem na cronologia como internas e nunca entram na operação de mensagem.

## Segurança e limites

- The default mode is simulated and YCloud sending is disabled in the database by default.
- Cada função server-side autentica o usuário e valida workspace/conversa/lead.
- Mensagens recebidas pelo simulador pausam assistência e colocam a conversa em espera.
- Uma lista conservadora reconhece frases inequívocas de opt-out em português. Casos ambíguos não bloqueiam automaticamente.
- Uma nova mensagem recebida pausa a assistência e muda novos envios reais para o modo humano. Gemini pode preparar rascunhos supervisionados que seguem as oito etapas do processo interno; não envia respostas, inicia contato, agenda reuniões nem altera o CRM automaticamente.
- Histórico limitado a 500 mensagens por consulta; sem política automática de expurgo configurada.

`/webhooks/ycloud` verifies `YCloud-Signature` using the provider's HMAC SHA-256 contract against the raw body, persists event IDs before processing, and deduplicates both events and provider message IDs. Its six-hour signature window covers the documented webhook retry horizon; persistent event IDs prevent replayed events from reapplying. Inbound matching requires exactly one existing workspace lead with the sender's normalized phone. Unmatched/ambiguous contacts are not auto-created. The app currently exposes event counts/status only through the database; it has no manual unmatched-event review UI.

## Próximo passo do adaptador real

Escolher um app/provedor oficial, validar documentação atual de envio, webhooks, templates, janela, assinatura, retries e status, e então implementar um `MessagingProvider` isolado com testes de contrato. Não reaproveitar o mock como resposta de API real.
