# Arquitetura

## Estilo

Monólito modular full-stack. TanStack Start executa UI e funções server-side no Netlify; Netlify Database é a persistência e também guarda usuários, hashes de senha e sessões. O navegador nunca recebe uma URL ou senha de banco.

## Camadas

- **Domínio** (`src/domain`): tipos, normalização e regras do funil.
- **Aplicação** (`src/application`): validação e casos de uso independentes de UI e do fornecedor.
- **Infraestrutura** (`src/infrastructure`): repositórios Netlify, autenticação por cookie, demo local e adaptadores.
- **Interface** (`src/routes`): páginas e formulários React/TanStack.
- **Dados** (`netlify/database/migrations`): schema versionado PostgreSQL.

## Autenticação e isolamento

Senhas são derivadas com scrypt e salt individual. O cookie de sessão é HttpOnly, Secure em produção e SameSite=Lax. Somente o hash SHA-256 do token opaco fica na tabela de sessões. Cada função de dados valida o cookie no servidor e escopa leituras/escritas por `owner_id`. A primeira conta administradora é criada na aba Cadastro somente enquanto o banco estiver vazio; o claim atômico impede cadastros seguintes e concorrentes. Não há cadastro público posterior ou recuperação de senha nesta fase. Restrinja o site até criar essa conta. Tentativas de login são limitadas por conta com bloqueio temporário persistido.

O runtime usa exclusivamente Netlify Database. A demonstração em `localStorage` existe somente no Vite local e não acessa dados hospedados.

## Controles e limites

- O app cria a linha `user_operating_settings` sob demanda, após autenticação; controles AI/expediente persistem e são auditados, mas não acionam worker externo.
- IA, prospecção externa e envio de mensagens permanecem bloqueados até integração documentada e worker persistente.
- Segredos de integrações são cifrados em server-side com AES-256-GCM; usa `MOTA_INTEGRATION_ENCRYPTION_KEY` quando definida ou deriva uma chave com HMAC da connection string secreta do Netlify Database.
- A migração SQL deve ser aplicada e testada em banco Netlify de desenvolvimento antes de qualquer uso real.
- Conversas, tarefas, workers e agendamentos ainda não são fluxos persistidos completos.
- Leads podem receber um bloqueio de contato persistido em `leads.opted_out_at`; a mutação server-side grava auditoria junto com a alteração. Canais futuros devem validar esse estado antes de enviar.
- A revisão de prospecção usa `leads.review_status`, `reviewed_by`, `reviewed_at` e `duplicate_of`, separados do estágio comercial. As decisões são auditadas em mutação server-side. Aprovação não envia contato nem sincroniza CRM.
- A pesquisa SerpApi reserva capacidade em `prospecting_daily_usage` por workspace e data de `America/Maceio`; a atualização condicional no banco impede que execuções concorrentes reservem mais de 30 candidatos no dia. O teto atual é fixo e cada busca continua limitada a 20.
- A inbox mock persiste `conversations`, `conversation_messages` e `conversation_notes`. Mensagens externas não são enviadas; a flag `is_simulated` e estado `simulated` são obrigatórios no registro. A entrada simulada exige chave de idempotência, pausa a assistência e pedidos explícitos atualizam o opt-out do lead.
