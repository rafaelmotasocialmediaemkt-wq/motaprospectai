# Operação no Netlify

## Estado e componentes

O projeto usa somente Netlify Database para persistência e autenticação própria. Nenhum site Netlify, banco hospedado ou credencial foi conectado nesta execução; o build local não prova funcionamento de um banco remoto.

## Configuração inicial segura

1. Selecione o site Netlify correto e habilite Netlify Database nele. Use primeiro um ambiente de desenvolvimento.
2. Restrinja o site enquanto configura a conta inicial. A aba **Cadastro** cria a primeira conta como administradora sem precisar inserir usuário diretamente no banco. O servidor aceita o cadastro somente enquanto `app_users` e a tabela de bootstrap estiverem vazias; requisições concorrentes são arbitradas pelo banco. Depois, a aba Cadastro fica desabilitada.
3. Opcional, mas recomendado para sobreviver à rotação da conexão do banco: configure `MOTA_INTEGRATION_ENCRYPTION_KEY` no escopo server-side com 64 caracteres hexadecimais, gerada com `node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"`. Sem essa variável, a aplicação deriva a chave de cifragem server-side da connection string secreta que o Netlify injeta para o Database; portanto, a tela de Integrações não exige configuração manual. Se a connection string ou a chave explícita mudar, credenciais cifradas previamente podem não ser lidas; faça rotação planejada.
4. Mantenha as migrações em `netlify/database/migrations/`. O Netlify detecta essa pasta e aplica os arquivos pendentes, em ordem lexicográfica, automaticamente no ciclo de deploy: no preview, antes de ficar disponível; em produção, imediatamente antes de publicar. Se a migração falhar, o deploy não é publicado.
5. Faça primeiro um deploy preview no site de desenvolvimento e crie a conta administradora pela aba **Cadastro**. Confirme também login, logout, expiração de sessão, bloqueio temporário por tentativas inválidas e CRUD de leads. Não use dados de produção para validação.
6. Somente após revisão explícita do destino, schema e recuperação de acesso, avalie publicar em produção. A migração continua automática no ciclo Netlify.

7. Preferências de prospecção e estado operacional são inicializados pelo próprio aplicativo no primeiro acesso autenticado a Configurações; não crie registros de usuário manualmente no banco.

O acesso inicial não cria uma sessão se não houver Netlify Database ou se a migração de autenticação não tiver sido aplicada. Nesse caso a tela informa que o banco está indisponível. O modo DEMO local usa somente `localStorage`; ele não é um substituto de autenticação ou banco compartilhado.

## Migrações e execução local

O schema atual está em `netlify/database/migrations/`. No deploy hospedado, a plataforma aplica as migrações nativamente; não adicione uma etapa de build que aplique SQL manualmente ao banco remoto. O plugin Vite para TanStack Start emula os recursos Netlify no desenvolvimento. Com o servidor local rodando, aplique manualmente apenas no banco local:

```sh
npm install --legacy-peer-deps
npm run dev
# segundo terminal, na raiz do projeto:
npx netlify-cli database migrations apply
```

Nenhuma migração remota ou deploy foi executado nesta execução porque não há site Netlify conectado ao projeto. A configuração do repositório já está no caminho nativo esperado pelo Netlify, portanto não é necessário segredo, token de banco ou job de CI para a aplicação automática. Veja o guia oficial de [Netlify Database](https://docs.netlify.com/build/data-and-storage/netlify-database/) e de [migrações](https://docs.netlify.com/build/data-and-storage/netlify-database/migrations/).

## Controles de segurança e limitações

- Senhas usam scrypt; sessão opaca em cookie HttpOnly é validada server-side e apenas seu hash é persistido.
- Tentativas inválidas são limitadas por conta no banco. Usuários bloqueados não recebem detalhes diferentes de usuário/senha inválidos.
- Todas as funções privadas validam sessão diretamente no handler e restringem consultas ao usuário autenticado.
- O bootstrap pela aba Cadastro aceita somente a primeira conta num banco sem usuários; não existe cadastro público posterior nem fluxo de recuperação/convite de usuário. Restrinja o site até criar a primeira conta para impedir que terceiros reivindiquem o bootstrap.
- Credenciais Prospectab/MachtKin são cifradas AES-256-GCM usando chave explícita server-side ou derivada da conexão secreta Netlify Database. Testes de conexão fazem somente GET com redirects bloqueados e timeout; nenhum lead é gravado nos serviços remotos.
- Não existe isolamento por organização, worker persistente, monitoramento operacional ou rotação/redefinição de senha nesta fase.
- IA, prospecção, mensagens WhatsApp e sincronização de CRM continuam desativadas. Nenhuma mensagem ou escrita externa é realizada.
- O Netlify Database é provisionado/gerenciado pelo Netlify; não exponha sua conexão ao cliente. Consulte os custos e limites vigentes diretamente no painel oficial.
