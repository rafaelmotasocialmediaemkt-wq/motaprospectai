# WhatsApp and YCloud

## Estado

YCloud is the configured WhatsApp provider for the new backend path. The inbox remains simulated by default. When the administrator explicitly enables it, a signed-in seller can manually send one text reply from a matched conversation; automatic AI replies and campaigns remain disabled. Gemini generates optional, human-reviewed reply suggestions only. No live account credentials or production calls were used during development.

Inbound messages are matched by normalized phone to exactly one lead in the configured workspace. A previously unknown phone creates a minimal lead from the customer-initiated message so its conversation appears in the inbox; ambiguous matches remain unmatched. Clear opt-out requests update the central `leads.opted_out_at` field. New inbound messages pause assistance. Delivery status callbacks update message state separately from webhook receipt.

## YCloud server configuration

Set these secrets in the Netlify site's server environment (Functions scope), or in a private local `.env.local` for an isolated test account:

- `YCLOUD_API_KEY`: optional server-side fallback; the administrator may instead save the YCloud API key in **Integrações → WhatsApp via YCloud**, where it is encrypted in `provider_connections` and sent only in the `X-API-Key` header.
- `YCLOUD_PHONE_NUMBER`: optional server-side fallback; the preferred number is saved with the YCloud integration in E.164 format.
- `YCLOUD_WEBHOOK_SIGNING_SECRET`: optional server-side fallback; the preferred endpoint signing secret is encrypted with the YCloud credentials in the integration panel.
- `YCLOUD_WORKSPACE_ID`: optional when exactly one active administrator workspace exists; otherwise set the UUID of the owning admin (`app_users.id`).

The Inbox administrator can run **Testar conexão YCloud (somente leitura)**. It calls the documented phone-number listing endpoint and requires the configured sender to be returned with `CONNECTED` before enabling real sends. This action does not send a WhatsApp message.

Apply the new database migration before opening the inbox. Configure the webhook as `https://motarafa.netlify.app/webhooks/ycloud`, subscribe to `whatsapp.inbound_message.received` and `whatsapp.message.updated`, and use the endpoint signing secret for signature verification. The root URL is also accepted for signed POSTs when the existing YCloud endpoint is configured at the site root. The endpoint checks the raw request body, accepts signature timestamps within the documented retry horizon (six hours including margin), persists the event before processing, deduplicates event IDs, and uses provider retries for transient failures. Successfully handled and ignored events discard their minimized payload; still-ambiguous matches keep no message body. Failed processing retains only a minimized payload for provider retry, clearing it after eight failed attempts.

The real send uses only the documented queued text endpoint, sets `filterUnsubscribed` and `filterBlocked`, and stores `accepted` as acceptance rather than delivery. Statuses `sent`, `delivered`, `read`, and `failed` are received from YCloud callbacks. An ambiguous network/5xx result is set to `unknown`, never retried automatically, and blocks another send until it is reconciled in YCloud.

Free-form text is server-restricted to 24 hours after an actual inbound message. Initial outreach and business-initiated follow-ups are blocked because approved WhatsApp template management is not implemented. Sending requires both administrator enablement and a separate human confirmation in the inbox. The sender is switched to human mode after a real send request; no AI-generated response is sent.

## Meta Cloud API legado

Antes de ativar envio, o operador precisa configurar um app Meta e uma conta WhatsApp Business elegível, associar o número comercial e identificar os IDs necessários, conceder as permissões exigidas pelo produto, definir token de servidor seguro, cadastrar e verificar uma URL HTTPS de webhook e selecionar/configurar templates aplicáveis. Escopos, permissões, formato de assinatura, payloads, versão da Graph API, janela de atendimento, limites e templates devem ser confirmados na documentação oficial vigente da Meta para o app e conta escolhidos.

Não coloque token em variável `VITE_*`, commit, navegador ou chat. Use o armazenamento cifrado de integração existente no servidor. Nunca reutilize o token mostrado pela interface: ele não é exibido após salvar.

## Limites ainda pendentes

The `/whatsapp` path redirects to the YCloud inbox at `/inbox`; navigation presents one WhatsApp entry. The inbox shows messages persisted from the signed YCloud webhook. Live mode does not offer simulated messages. YCloud settings saved through the authenticated admin panel are read from the database at runtime, so changing them does not require a redeploy. Saving credentials invalidates the previous connection test and disables sending until the administrator tests again. Separate Meta Cloud API settings remain legacy configuration and do not feed this inbox. YCloud Calling is not implemented. The app has no follow-up task service, WhatsApp template workflow, or verified MachtKin write contract; those remain pending.

## Gemini reply suggestions

Set `GEMINI_API_KEY` and optionally `GEMINI_MODEL` (defaults to `gemini-4-argon`) in the server environment. The Inbox's **Gerar sugestão** action sends recent message history and minimal lead context to Google's Interactions API with `store: false`; suggestions are validated against the expected JSON shape and recorded in the audit log without storing their text. The user must explicitly copy a suggestion into the composer, then review and confirm any real YCloud send. Conversation data is sent to Google when a suggestion is requested. See Google's [Interactions API](https://ai.google.dev/gemini-api/docs/interactions-overview) and [structured output](https://ai.google.dev/gemini-api/docs/structured-output) documentation.

## Testes de desenvolvimento

Unit tests inject a mocked `fetch` and use synthetic webhook bodies/signatures. They never call YCloud. Do not run connection tests or enable sending against a production key during local development. A successful local test proves only the adapter contract and signature logic; it does not validate the configured YCloud account or webhook subscription.
