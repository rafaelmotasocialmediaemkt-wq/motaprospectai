# Opt-out e privacidade

## Bloqueio atual

Leads têm `opted_out_at`. Usuários autenticados podem bloquear contato pela lista de Leads; a alteração e auditoria são gravadas no servidor. Um pedido inequívoco detectado em mensagem de entrada simulada também bloqueia o lead, grava auditoria e pausa a assistência da conversa. A reimportação/edição comum não limpa esse campo.

A detecção é conservadora e cobre frases claras. Não é classificador geral de intenção. Revisar pedidos ambíguos manualmente e manter contato suspenso quando houver dúvida. No momento não há canal inbound real para executar esta detecção em mensagens recebidas do WhatsApp.

## Retenção

O histórico de conversas de teste é persistido para o workspace e não tem expurgo automático implementado. Armazene somente dados necessários, restrinja acesso, defina prazo de retenção aprovado antes do uso real e implemente exclusão/anonymização antes de ampliar operação.
