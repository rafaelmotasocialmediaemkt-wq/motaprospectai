import { describe, expect, it } from "vitest";
import { canMoveLead, normalizeCompany, normalizePhone } from "./lead";

describe("lead domain rules", () => {
  it("normalizes Brazilian phone punctuation", () => {
    expect(normalizePhone("+55 (82) 99999-0000")).toBe("5582999990000");
  });

  it("normalizes company names for duplicate checks", () => {
    expect(normalizeCompany("  Mota   Lab ")).toBe("mota lab");
  });

  it("keeps terminal leads out of active stages", () => {
    expect(canMoveLead("won", "contacted")).toBe(false);
    expect(canMoveLead("won", "archived")).toBe(true);
  });

  it("does not allow contact authorization until evidence capture exists", () => {
    expect(canMoveLead("qualified", "contact_authorized")).toBe(false);
  });

  it("does not return archived leads to the active funnel", () => {
    expect(canMoveLead("archived", "new")).toBe(false);
  });
});
