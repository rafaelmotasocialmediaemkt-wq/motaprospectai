export const LEAD_STAGES = [
  "new",
  "qualifying",
  "qualified",
  "contact_authorized",
  "contacted",
  "responded",
  "meeting_scheduled",
  "proposal",
  "won",
  "lost",
  "archived",
] as const;

export type LeadStage = (typeof LEAD_STAGES)[number];
export const LEAD_REVIEW_STATUSES = ["pending", "approved", "rejected", "duplicate"] as const;
export type LeadReviewStatus = (typeof LEAD_REVIEW_STATUSES)[number];

export type Lead = {
  id: string;
  companyName: string;
  contactName: string | null;
  email: string | null;
  phone: string | null;
  segment: string | null;
  city: string | null;
  state: string | null;
  source: string;
  stage: LeadStage;
  qualificationScore: number | null;
  notes: string | null;
  optedOutAt: string | null;
  reviewStatus: LeadReviewStatus;
  reviewedAt: string | null;
  duplicateOf: string | null;
  isDemo: boolean;
  createdAt: string;
  updatedAt: string;
};

export function normalizePhone(value: string): string {
  return value.replace(/\D/g, "");
}

export function normalizeCompany(value: string): string {
  return value.trim().normalize("NFKC").replace(/\s+/g, " ").toLocaleLowerCase("pt-BR");
}

export function canMoveLead(from: LeadStage, to: LeadStage): boolean {
  if (from === to) return true;
  if (from === "archived") return false;
  if (from === "won" || from === "lost") return to === "archived";
  // Consent evidence is not yet captured by the product, so this state must
  // remain unreachable until a reviewed consent workflow exists.
  if (to === "contact_authorized") return false;
  if (to === "new") return false;
  return true;
}
