import { LeadService } from "../../application/leads/lead-service";
import { LocalDemoLeadRepository } from "../demo/local-lead-repository";
import { NetlifyLeadRepository } from "../netlify/lead-repository";
import { isDemoMode } from "../netlify/mode";
import { writeDemoAudit } from "../audit/local-audit";

export const leadService = new LeadService(
  isDemoMode ? new LocalDemoLeadRepository() : new NetlifyLeadRepository(),
  isDemoMode ? writeDemoAudit : () => undefined,
);
