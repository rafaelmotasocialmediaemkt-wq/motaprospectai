import { createCipheriv, createDecipheriv, createHmac, randomBytes } from "node:crypto";
import { getServerDatabase } from "./database.server";

const VERSION = "v1";

function getEncryptionKey(): Buffer {
  const value = process.env.MOTA_INTEGRATION_ENCRYPTION_KEY?.trim();
  if (value) {
    if (!/^[a-f\d]{64}$/i.test(value)) throw new Error("Configure MOTA_INTEGRATION_ENCRYPTION_KEY com 64 caracteres hexadecimais no servidor.");
    return Buffer.from(value, "hex");
  }
  // Netlify injects this server-only connection string at runtime. Deriving a
  // domain-separated key from it removes a manual setup step without storing
  // the encryption key alongside encrypted integration credentials.
  try {
    const connectionString = getServerDatabase().connectionString;
    return createHmac("sha256", connectionString).update("mota-prospect-ai:integration-secrets:v1").digest();
  } catch {
    throw new Error("Configure MOTA_INTEGRATION_ENCRYPTION_KEY com 64 caracteres hexadecimais ou conecte o Netlify Database.");
  }
}

export function encryptIntegrationSecret(plaintext: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", getEncryptionKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [VERSION, iv.toString("base64url"), tag.toString("base64url"), ciphertext.toString("base64url")].join(":");
}

export function decryptIntegrationSecret(value: string): string {
  try {
    const [version, ivText, tagText, ciphertextText, extra] = value.split(":");
    if (version !== VERSION || !ivText || !tagText || ciphertextText === undefined || extra !== undefined) throw new Error("invalid");
    const decipher = createDecipheriv("aes-256-gcm", getEncryptionKey(), Buffer.from(ivText, "base64url"));
    decipher.setAuthTag(Buffer.from(tagText, "base64url"));
    return Buffer.concat([decipher.update(Buffer.from(ciphertextText, "base64url")), decipher.final()]).toString("utf8");
  } catch (cause) {
    if (cause instanceof Error && cause.message.startsWith("Configure MOTA_")) throw cause;
    throw new Error("Não foi possível descriptografar a credencial da integração. Verifique a chave de cifragem do servidor.");
  }
}
