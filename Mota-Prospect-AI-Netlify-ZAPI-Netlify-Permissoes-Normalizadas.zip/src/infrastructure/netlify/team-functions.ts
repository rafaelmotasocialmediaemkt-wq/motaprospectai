import { randomUUID } from "node:crypto";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getServerDatabase } from "./database.server";
import { hashPassword, requireAuthenticatedPrincipal, requireWorkspaceAdmin } from "./server-auth";

const empty = z.object({});
const createInput = z.object({ email: z.string().trim().email().max(254), password: z.string().min(12).max(128) });
const memberInput = z.object({ id: z.uuid(), disabled: z.boolean() });

export const listTeamMembers = createServerFn({ method: "POST" }).validator((v: unknown) => empty.parse(v)).handler(async () => {
  const principal = await requireAuthenticatedPrincipal(); requireWorkspaceAdmin(principal);
  const db = getServerDatabase();
  const rows = await db.sql<{ id: string; email: string; disabled_at: string | Date | null; created_at: string | Date }>`
    select id, email, disabled_at, created_at from app_users where team_owner_id = ${principal.id} order by created_at desc
  `;
  return rows.map((row) => ({ id: row.id, email: row.email, disabled: Boolean(row.disabled_at), createdAt: new Date(row.created_at).toISOString() }));
});

export const createTeamMember = createServerFn({ method: "POST" }).validator((v: unknown) => createInput.parse(v)).handler(async ({ data }) => {
  const principal = await requireAuthenticatedPrincipal(); requireWorkspaceAdmin(principal);
  const db = getServerDatabase(); const email = data.email.toLowerCase();
  const id = randomUUID(); const passwordHash = await hashPassword(data.password);
  const rows = await db.sql<{ id: string; email: string }>`
    with created as (
      insert into app_users(id, email, password_hash, is_admin, team_owner_id)
      values (${id}, ${email}, ${passwordHash}, false, ${principal.id}) returning id, email
    ), profile as (
      insert into user_profiles(user_id) select id from created returning user_id
    ), logged as (
      insert into audit_logs(actor_id, action, entity_type, entity_id)
      select ${principal.id}, 'team.member_created', 'user', id from created returning id
    ) select id, email from created
  `;
  if (!rows[0]) throw new Error("Não foi possível criar o acesso da equipe.");
  return { id: rows[0].id, email: rows[0].email, disabled: false, createdAt: new Date().toISOString() };
});

export const setTeamMemberDisabled = createServerFn({ method: "POST" }).validator((v: unknown) => memberInput.parse(v)).handler(async ({ data }) => {
  const principal = await requireAuthenticatedPrincipal(); requireWorkspaceAdmin(principal);
  const db = getServerDatabase();
  const rows = await db.sql<{ id: string }>`
    update app_users set disabled_at = case when ${data.disabled} then now() else null end, updated_at = now()
    where id = ${data.id} and team_owner_id = ${principal.id} and is_admin = false returning id
  `;
  if (!rows[0]) throw new Error("Acesso de equipe não encontrado.");
  await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id) values (${principal.id}, ${data.disabled ? "team.member_disabled" : "team.member_enabled"}, 'user', ${data.id})`;
  return { id: data.id, disabled: data.disabled };
});
