import { createServerFn } from "@tanstack/react-start";
import { getRequestUrl } from "@tanstack/react-start/server";
import { z } from "zod";
import { getServerDatabase } from "./database.server";
import { requireAuthenticatedPrincipal, requireWorkspaceAdmin } from "./server-auth";

const empty = z.object({});
const sendInput = z.object({ conversationId: z.uuid(), body: z.string().trim().min(1).max(4000), idempotencyKey: z.uuid() });

export const getZapiWebhookUrl = createServerFn({ method: "POST" }).validator((data: unknown) => empty.parse(data)).handler(async () => {
  const user = await requireAuthenticatedPrincipal(); requireWorkspaceAdmin(user);
  const { getZapiCredentials } = await import("./zapi-client.server");
  const credentials = await getZapiCredentials(user.workspaceId);
  if (!credentials.webhookKey) throw new Error("Salve a integração Z-API para gerar a URL do webhook.");
  return { url: new URL(`/webhooks/zapi/${credentials.webhookKey}`, getRequestUrl()).toString() };
});

export const testZapiConnection = createServerFn({ method: "POST" }).validator((data: unknown) => empty.parse(data)).handler(async () => {
  const user = await requireAuthenticatedPrincipal(); requireWorkspaceAdmin(user);
  const { getZapiCredentials, zapiApiUrl } = await import("./zapi-client.server");
  const credentials = await getZapiCredentials(user.workspaceId);
  const headers = new Headers({ Accept: "application/json" });
  if (credentials.clientToken) headers.set("Client-Token", credentials.clientToken);
  const response = await fetch(zapiApiUrl(credentials, "status"), { headers, redirect: "error", signal: AbortSignal.timeout(12000) });
  if (!response.ok) {
    const detail = await zapiErrorDetail(response);
    const missingClientToken = /client[- ]token.*(not configured|not set|missing)|(?:not configured|not set|missing).*client[- ]token/i.test(detail);
    if (missingClientToken) throw new Error(`Z-API recusou o teste (HTTP ${response.status}): ${detail} Cadastre o Token de Segurança da Conta (Client-Token) no campo correspondente de Integrações → WhatsApp via Z-API e teste novamente. Ele é diferente do token da instância.`);
    throw new Error(`Z-API recusou o teste (HTTP ${response.status}): ${detail} Confira o ID e o token da instância; se a segurança da conta estiver ativa, informe também o Client-Token.`);
  }
  const status = await response.json() as { connected?: boolean; smartphoneConnected?: boolean; error?: string };
  await getServerDatabase().sql`update provider_connections set connected_at = case when ${Boolean(status.connected)} then now() else null end, updated_at = now() where owner_id = ${user.workspaceId} and provider = 'whatsapp_zapi'`;
  // Serialize metadata so PostgreSQL receives one explicitly typed JSON value.
  const auditMetadata = JSON.stringify({ connected: Boolean(status.connected), smartphoneConnected: Boolean(status.smartphoneConnected) });
  await getServerDatabase().sql`insert into audit_logs(actor_id, action, entity_type, metadata) values (${user.id}, 'zapi.connection_tested', 'integration', ${auditMetadata}::jsonb)`;
  return { connected: Boolean(status.connected), smartphoneConnected: Boolean(status.smartphoneConnected), error: status.error ?? null };
});

async function zapiErrorDetail(response: Response): Promise<string> {
  const raw = await response.text().catch(() => "");
  if (!raw) return "a API não retornou detalhes. ";
  let detail = raw;
  try {
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    const errors = parsed.errors;
    const first = Array.isArray(errors) ? errors[0] : undefined;
    const item = first && typeof first === "object" ? first as Record<string, unknown> : {};
    detail = String(parsed.message ?? parsed.error ?? parsed.description ?? item.message ?? raw);
  } catch { /* A Z-API também pode retornar texto puro. */ }
  return `${detail.replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").slice(0, 180)}. `;
}

export const sendZapiTextMessage = createServerFn({ method: "POST" }).validator((data: unknown) => sendInput.parse(data)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal(); const db = getServerDatabase();
  const { getZapiCredentials, sendZapiText } = await import("./zapi-client.server");
  const credentials = await getZapiCredentials(user.workspaceId);
  const providers = await db.sql<{ connected_at: string | Date | null }>`select connected_at from provider_connections where owner_id = ${user.workspaceId} and provider = 'whatsapp_zapi' limit 1`;
  if (!providers[0]?.connected_at) throw new Error("Teste e confirme a conexão Z-API antes de enviar mensagens.");
  const rows = await db.sql<{ lead_id: string; phone: string | null; opted_out_at: string | Date | null; status: string }>`select c.lead_id, l.phone, l.opted_out_at, c.status from conversations c join leads l on l.id = c.lead_id and l.owner_id = c.owner_id where c.id = ${data.conversationId} and c.owner_id = ${user.workspaceId} limit 1`;
  const conversation = rows[0];
  if (!conversation) throw new Error("Conversa não encontrada neste workspace.");
  if (conversation.status === "closed") throw new Error("A conversa está encerrada.");
  if (conversation.opted_out_at) throw new Error("Contato com opt-out ativo. Envio bloqueado.");
  if (!conversation.phone) throw new Error("Lead sem telefone comercial.");
  const phone = conversation.phone.replace(/\D/g, "");
  const international = phone.startsWith("55") ? phone : `55${phone}`;
  if (international.length < 12 || international.length > 13) throw new Error("Telefone não está em formato brasileiro válido.");
  const pending = await db.sql<{ id: string }>`select id from conversation_messages where owner_id = ${user.workspaceId} and conversation_id = ${data.conversationId} and direction = 'outbound' and delivery_status in ('queued','unknown') limit 1`;
  if (pending[0]) throw new Error("Há um envio pendente ou incerto nesta conversa. Confira o WhatsApp antes de tentar de novo.");
  const inserted = await db.sql<{ id: string }>`insert into conversation_messages(owner_id, conversation_id, direction, author_kind, body, delivery_status, is_simulated, idempotency_key, created_by) values (${user.workspaceId}, ${data.conversationId}, 'outbound', 'seller', ${data.body}, 'queued', false, ${data.idempotencyKey}, ${user.id}) on conflict(owner_id, idempotency_key) do nothing returning id`;
  if (!inserted[0]) throw new Error("Esta solicitação já foi processada. Atualize a conversa.");
  await db.sql`update conversations set ai_paused = true, automation_mode = 'human', assigned_to = coalesce(assigned_to, ${user.id}), updated_at = now() where id = ${data.conversationId} and owner_id = ${user.workspaceId}`;
  await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${user.id}, 'zapi.message_send_requested', 'conversation', ${data.conversationId}, jsonb_build_object('messageId', ${inserted[0].id}::text))`;
  try {
    const accepted = await sendZapiText(credentials, international, data.body);
    const providerId = accepted.zaapId ?? accepted.messageId ?? accepted.id ?? accepted.zapiMessageId ?? "";
    await db.sql`update conversation_messages set external_message_id = ${providerId}, delivery_status = 'sent', failure_reason = null where id = ${inserted[0].id} and owner_id = ${user.workspaceId}`;
    await db.sql`update conversations set last_message_at = now(), updated_at = now() where id = ${data.conversationId} and owner_id = ${user.workspaceId}`;
    await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${user.id}, 'zapi.message_accepted', 'conversation', ${data.conversationId}, jsonb_build_object('providerMessageId', ${providerId}))`;
    return { accepted: true, status: "sent", messageId: providerId };
  } catch (cause) {
    const httpStatus = cause && typeof cause === "object" && "httpStatus" in cause ? Number((cause as { httpStatus: unknown }).httpStatus) : null;
    const uncertain = httpStatus === null || httpStatus >= 500;
    await db.sql`update conversation_messages set delivery_status = ${uncertain ? "unknown" : "failed"}, failure_reason = ${uncertain ? "Resultado incerto; confira o WhatsApp antes de reenviar." : `HTTP ${httpStatus}`} where id = ${inserted[0].id} and owner_id = ${user.workspaceId}`;
    await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${user.id}, ${uncertain ? "zapi.message_send_uncertain" : "zapi.message_send_failed"}, 'conversation', ${data.conversationId}, jsonb_build_object('httpStatus', ${httpStatus}))`;
    throw new Error(uncertain ? "Resultado incerto. Confira o WhatsApp antes de tentar novamente." : `Z-API recusou o envio (HTTP ${httpStatus}).`);
  }
});
