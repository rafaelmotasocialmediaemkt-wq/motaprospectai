import { afterEach, describe, expect, it, vi } from "vitest";
vi.mock("./database.server", () => ({ getServerDatabase: () => { throw new Error("Netlify Database não está configurado neste ambiente."); } }));
import { decryptIntegrationSecret, encryptIntegrationSecret } from "./integration-secrets.server";

describe("integration API credential encryption", () => {
  afterEach(() => vi.unstubAllEnvs());

  it("encrypts credentials so they can be decrypted only server-side", () => {
    vi.stubEnv("MOTA_INTEGRATION_ENCRYPTION_KEY", "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef");
    const secret = "test-api-key-not-real";
    const encrypted = encryptIntegrationSecret(secret);
    expect(encrypted).not.toContain(secret);
    expect(encrypted.split(":")).toHaveLength(4);
    expect(decryptIntegrationSecret(encrypted)).toBe(secret);
  });

  it("uses a fresh nonce for each encryption", () => {
    vi.stubEnv("MOTA_INTEGRATION_ENCRYPTION_KEY", "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef");
    expect(encryptIntegrationSecret("same-value")).not.toBe(encryptIntegrationSecret("same-value"));
  });

  it("fails closed when the server encryption key is missing or malformed", () => {
    vi.stubEnv("MOTA_INTEGRATION_ENCRYPTION_KEY", "");
    expect(() => encryptIntegrationSecret("test")).toThrow("MOTA_INTEGRATION_ENCRYPTION_KEY");
    vi.stubEnv("MOTA_INTEGRATION_ENCRYPTION_KEY", "not-hex");
    expect(() => encryptIntegrationSecret("test")).toThrow("MOTA_INTEGRATION_ENCRYPTION_KEY");
  });

  it("detects tampered encrypted credentials", () => {
    vi.stubEnv("MOTA_INTEGRATION_ENCRYPTION_KEY", "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef");
    const encrypted = encryptIntegrationSecret("test-api-key");
    const parts = encrypted.split(":");
    parts[3] = `${parts[3]?.startsWith("A") ? "B" : "A"}${parts[3]?.slice(1)}`;
    expect(() => decryptIntegrationSecret(parts.join(":"))).toThrow("Não foi possível descriptografar");
  });
});
