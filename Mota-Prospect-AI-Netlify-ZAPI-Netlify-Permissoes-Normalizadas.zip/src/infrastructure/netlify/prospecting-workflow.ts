import { createServerFn, createServerOnlyFn } from "@tanstack/react-start";
import { z } from "zod";
import { publicCompanyFields } from "../../application/prospecting/cnpj";
import { cleanPublicText, extractValidCnpj, safePublicUrl } from "../../application/prospecting/public-results";
import { getServerDatabase } from "./database.server";
import { decryptIntegrationSecret } from "./integration-secrets.server";
import { requireAuthenticatedPrincipal, requireWorkspaceAdmin } from "./server-auth";
import { publicSearchProviderError } from "../../application/prospecting/search-provider-error";

const empty = z.object({});
type Settings = { shift_status: string; shift_started_at: string | Date | null; business_segment: string; target_locations: string; search_terms: string; max_candidates_per_shift: number; daily_budget_cents: number; require_human_review: boolean };
type OrganicResult = { title?: string; link?: string; snippet?: string };
type SearchBody = { error?: string; organic_results?: OrganicResult[] };

export const runPublicProspectingShift = createServerFn({ method: "POST" }).validator((v: unknown) => empty.parse(v)).handler(async () => {
  const actor = await requireAuthenticatedPrincipal(); requireWorkspaceAdmin(actor);
  return runPublicProspectingForWorkspace(actor.workspaceId, actor.id, "initial", false);
});

/** Internal scheduled entry point. Only active root administrators are selected by the scheduled function. */
export const runScheduledPublicProspecting = createServerOnlyFn(async (ownerId: string, cycleKey: string): Promise<{ skipped: boolean; candidatesSeen?: number; leadsCreated?: number }> => {
  const db = getServerDatabase();
  const owners = await db.sql<{ id: string }>`select id from app_users where id = ${ownerId} and is_admin = true and team_owner_id is null and disabled_at is null limit 1`;
  if (!owners[0]) return { skipped: true };
  return runPublicProspectingForWorkspace(ownerId, ownerId, cycleKey, true);
});

async function runPublicProspectingForWorkspace(ownerId: string, actorId: string, cycleKey: string, scheduled: boolean): Promise<{ skipped: boolean; candidatesSeen?: number; leadsCreated?: number; searchRequests?: number; agentConnected?: boolean }> {
  const db = getServerDatabase();
  const [settingsRows, providerRows] = await Promise.all([
    db.sql<Settings>`select shift_status, shift_started_at, business_segment, target_locations, search_terms, max_candidates_per_shift, daily_budget_cents, require_human_review from user_operating_settings where owner_id = ${ownerId} limit 1`,
    db.sql<{ encrypted_secret: string | null }>`select encrypted_secret from provider_connections where owner_id = ${ownerId} and provider = 'serpapi' limit 1`,
  ]);
  const settings = settingsRows[0];
  if (!settings || settings.shift_status !== "active" || !settings.shift_started_at) return { skipped: true };
  if (!settings.business_segment.trim() || !settings.target_locations.trim() || !settings.search_terms.trim()) throw new Error("Preencha segmento, regiões e termos de pesquisa nas configurações.");
  if (settings.daily_budget_cents < 1) throw new Error("Defina um orçamento diário maior que zero antes de permitir pesquisa externa.");
  const serpApiKey = process.env.SERPAPI_API_KEY?.trim() || (providerRows[0]?.encrypted_secret ? decryptIntegrationSecret(providerRows[0].encrypted_secret) : "");
  if (!serpApiKey) throw new Error("Configure SERPAPI_API_KEY nas variáveis secretas do servidor ou salve a chave em Integrações.");

  const start = new Date(settings.shift_started_at).toISOString();
  const runRows = await db.sql<{ id: string; status: string; leads_created: number; candidates_seen: number }>`
    insert into prospecting_runs(owner_id, shift_started_at, started_by, status, cycle_key)
    values (${ownerId}, ${start}, ${actorId}, 'running', ${cycleKey}) on conflict(owner_id, shift_started_at, cycle_key) do nothing
    returning id, status, leads_created, candidates_seen
  `;
  if (!runRows[0]) {
    if (scheduled) return { skipped: true };
    throw new Error("A pesquisa inicial deste expediente já foi iniciada. O restante seguirá no agendamento automático.");
  }
  const runId = runRows[0].id;
  const searchReservation = await db.sql<{ request_count: number }>`
    insert into prospecting_search_daily_usage(owner_id, usage_date, request_count)
    values (${ownerId}, (now() at time zone 'America/Maceio')::date, 1)
    on conflict(owner_id, usage_date) do update
      set request_count = prospecting_search_daily_usage.request_count + 1, updated_at = now()
      where prospecting_search_daily_usage.request_count < 6
    returning request_count
  `;
  if (!searchReservation[0]) {
    await db.sql`update prospecting_runs set status = 'completed', error_code = 'daily_search_limit', updated_at = now() where id = ${runId}`;
    if (scheduled) return { skipped: true };
    throw new Error("Limite diário de 6 pesquisas públicas atingido.");
  }
  let reservedCandidates = 0;
  let processedCandidates = 0;
  try {
    const usage = await db.sql<{ processed_count: number }>`select processed_count from prospecting_daily_usage where owner_id = ${ownerId} and usage_date = (now() at time zone 'America/Maceio')::date limit 1`;
    const alreadyProcessed = usage[0]?.processed_count ?? 0;
    const candidateLimit = Math.min(20, settings.max_candidates_per_shift, 30 - alreadyProcessed);
    if (candidateLimit < 1) throw new Error("Limite diário de 30 empresas já atingido. Tente novamente amanhã no fuso America/Maceio.");
    const reservation = await db.sql<{ processed_count: number }>`
      insert into prospecting_daily_usage(owner_id, usage_date, processed_count)
      values (${ownerId}, (now() at time zone 'America/Maceio')::date, ${candidateLimit})
      on conflict(owner_id, usage_date) do update
        set processed_count = prospecting_daily_usage.processed_count + excluded.processed_count, updated_at = now()
        where prospecting_daily_usage.processed_count + excluded.processed_count <= 30
      returning processed_count
    `;
    if (!reservation[0]) throw new Error("Limite diário de 30 empresas já atingido. Tente novamente amanhã no fuso America/Maceio.");
    reservedCandidates = candidateLimit;
    const term = settings.search_terms.split(/[\n,;]+/).map((v) => v.trim()).filter(Boolean)[0];
    const query = [settings.business_segment, term, settings.target_locations.split(/[\n,;]+/)[0]?.trim(), "empresa CNPJ"].filter(Boolean).join(" ").slice(0, 500);
    const searchUrl = new URL("https://serpapi.com/search");
    searchUrl.search = new URLSearchParams({ engine: "google", q: query, api_key: serpApiKey, gl: "br", hl: "pt", num: String(candidateLimit) }).toString();
    const response = await fetch(searchUrl, { headers: { Accept: "application/json" }, redirect: "error", cache: "no-store", signal: AbortSignal.timeout(15000) });
    if (!response.ok) { await response.body?.cancel(); throw new Error(publicSearchProviderError(response.status)); }
    const search = await response.json() as SearchBody;
    if (search.error) throw new Error("O provedor recusou a pesquisa; verifique a credencial e o plano SerpApi.");
    const candidates = (search.organic_results ?? []).slice(0, candidateLimit);
    processedCandidates = candidates.length;
    if (candidates.length < candidateLimit) {
      await db.sql`update prospecting_daily_usage set processed_count = greatest(0, processed_count - ${candidateLimit - candidates.length}), updated_at = now() where owner_id = ${ownerId} and usage_date = (now() at time zone 'America/Maceio')::date`;
    }
    let created = 0; let cnpjLookups = 0;
    for (const candidate of candidates) {
      const title = cleanPublicText(candidate.title, 160); const link = safePublicUrl(candidate.link);
      if (title.length < 2 || !link) continue;
      const cnpj = extractValidCnpj(`${candidate.title ?? ""} ${candidate.snippet ?? ""} ${candidate.link ?? ""}`);
      let companyName = title; let city: string | null = null; let state: string | null = null; let cnae: string | null = null;
      if (cnpj && cnpjLookups < 4) {
        cnpjLookups += 1;
        try {
          const lookup = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${encodeURIComponent(cnpj)}`, { headers: { Accept: "application/json" }, redirect: "error", cache: "no-store", signal: AbortSignal.timeout(8000) });
          if (lookup.ok) {
            const company = publicCompanyFields(await lookup.json());
            companyName = cleanPublicText(String(company.nome_fantasia || company.razao_social || title), 160) || title;
            city = stringOrNull(company.municipio); state = stringOrNull(company.uf); cnae = stringOrNull(company.cnae_fiscal_descricao);
          } else await lookup.body?.cancel();
        } catch { /* Preserve the Google result as an unverified public candidate. */ }
      }
      const notes = [`Fonte pública: pesquisa Google via SerpApi`, `URL pública: ${link}`, cnpj ? `CNPJ citado no resultado: ${cnpj}` : "CNPJ não identificado no trecho público."].join("\n");
      const inserted = await db.sql<{ id: string }>`
        with created as (
          insert into leads(owner_id, company_name, segment, city, state, source, stage, notes, cnpj)
          values (${ownerId}, ${companyName}, ${cnae ?? settings.business_segment}, ${city}, ${state}, 'public_search', 'new', ${notes}, ${cnpj})
          on conflict do nothing returning id
        ), logged as (
          insert into audit_logs(actor_id, action, entity_type, entity_id, metadata)
          select ${actorId}, 'lead.public_prospect_created', 'lead', id, ${JSON.stringify({ source: "serpapi_public_search", hasCnpj: Boolean(cnpj) })}::jsonb from created returning id
        ) select id from created
      `;
      if (inserted[0]) {
        created += 1;
      }
    }
    await db.sql`update prospecting_runs set status = 'completed', search_requests = 1, candidates_seen = ${candidates.length}, leads_created = ${created}, updated_at = now() where id = ${runId}`;
    await db.sql`insert into audit_logs(actor_id, action, entity_type, metadata) values (${actorId}, 'prospecting.shift_completed', 'search', ${JSON.stringify({ candidates: candidates.length, leadsCreated: created, humanReviewRequired: settings.require_human_review, cycleKey, scheduled })}::jsonb)`;
    return { skipped: false, candidatesSeen: candidates.length, leadsCreated: created, searchRequests: 1, agentConnected: false };
  } catch (cause) {
    await db.sql`update prospecting_runs set status = 'failed', search_requests = 1, error_code = 'provider_or_persistence_error', updated_at = now() where id = ${runId}`;
    if (reservedCandidates > processedCandidates) {
      await db.sql`update prospecting_daily_usage set processed_count = greatest(0, processed_count - ${reservedCandidates - processedCandidates}), updated_at = now() where owner_id = ${ownerId} and usage_date = (now() at time zone 'America/Maceio')::date`;
    }
    throw cause instanceof Error ? cause : new Error("Falha na pesquisa pública do expediente.");
  }
}

function stringOrNull(value: unknown): string | null { return typeof value === "string" && value.trim() ? value.trim().slice(0, 160) : null; }
