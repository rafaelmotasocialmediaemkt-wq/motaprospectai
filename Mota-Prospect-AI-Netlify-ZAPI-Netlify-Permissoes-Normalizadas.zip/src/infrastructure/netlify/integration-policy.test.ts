import { describe, expect, it } from "vitest";
import { validateIntegrationEndpoint } from "./integration-policy";

describe("CRM endpoint allowlist", () => {
  it("accepts the specified HTTPS endpoints", () => {
    expect(validateIntegrationEndpoint("prospectab", "https://prospectab.lovable.app/api/public/v1/leads?limit=50"))
      .toBe("https://prospectab.lovable.app/api/public/v1/leads?limit=50");
    expect(validateIntegrationEndpoint("machtkin", "https://machtkin.lovable.app/api/public/v1/leads"))
      .toBe("https://machtkin.lovable.app/api/public/v1/leads");
  });

  it.each([
    "http://prospectab.lovable.app/api/public/v1/leads",
    "https://127.0.0.1/api/public/v1/leads",
    "https://prospectab.lovable.app:444/api/public/v1/leads",
    "https://attacker.example/api/public/v1/leads",
    "https://prospectab.lovable.app/api/admin",
    "https://prospectab.lovable.app/api/public/v1/leads?limit=10000",
    "https://prospectab.lovable.app/api/public/v1/leads?next=https://attacker.example",
  ])("rejects unsafe or undocumented Prospectab endpoint %s", (url) => {
    expect(() => validateIntegrationEndpoint("prospectab", url)).toThrow();
  });

  it("rejects undocumented query parameters for MachtKin", () => {
    expect(() => validateIntegrationEndpoint("machtkin", "https://machtkin.lovable.app/api/public/v1/leads?page=3")).toThrow("não foram documentados");
  });
});
