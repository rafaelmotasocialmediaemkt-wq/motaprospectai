import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getServerDatabase } from "./database.server";
import { decryptIntegrationSecret, encryptIntegrationSecret } from "./integration-secrets.server";
import { validateIntegrationEndpoint, type CRMProvider } from "./integration-policy";
import { requireAuthenticatedPrincipal, requireWorkspaceAdmin } from "./server-auth";

const providers = ["prospectab", "machtkin"] as const;
const emptyInput = z.object({});
const providerInput = z.object({ provider: z.enum(providers) });
const saveInput = z.object({
  provider: z.enum(providers),
  endpointUrl: z.string().url().max(2048),
  apiKey: z.string().max(4096),
  authHeader: z.string().trim().min(1).max(80).regex(/^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/),
  authPrefix: z.string().max(40).regex(/^[\w .-]*$/),
});

type Provider = CRMProvider;
type IntegrationRow = {
  provider: Provider;
  endpoint_url: string;
  auth_header: string;
  auth_prefix: string;
  encrypted_api_key: string;
  last_test_at: string | Date | null;
  last_test_status: string | null;
  last_http_status: number | null;
};

export const listIntegrationSettings = createServerFn({ method: "POST" })
  .validator((data: unknown) => emptyInput.parse(data))
  .handler(async ({ data }) => {
    void data;
    const user = await requireAuthenticatedPrincipal();
    const db = getServerDatabase();
    await ensureUser(db, user);
    const rows = await db.sql<IntegrationRow>`
      select provider, endpoint_url, auth_header, auth_prefix, encrypted_api_key, last_test_at, last_test_status, last_http_status
      from integration_connections where owner_id = ${user.workspaceId}
    `;
    return providers.map((provider) => {
      const row = rows.find((item) => item.provider === provider);
      return row ? toPublicSettings(row) : emptySettings(provider);
    });
  });

export const saveIntegrationSettings = createServerFn({ method: "POST" })
  .validator((data: unknown) => saveInput.parse(data))
  .handler(async ({ data }) => {
    const user = await requireAuthenticatedPrincipal();
    requireWorkspaceAdmin(user);
    const endpointUrl = validateIntegrationEndpoint(data.provider, data.endpointUrl);
    const db = getServerDatabase();
    await ensureUser(db, user);
    const existing = await db.sql<Pick<IntegrationRow, "encrypted_api_key">>`
      select encrypted_api_key from integration_connections where owner_id = ${user.workspaceId} and provider = ${data.provider} limit 1
    `;
    const encryptedKey = data.apiKey ? encryptIntegrationSecret(data.apiKey) : existing[0]?.encrypted_api_key;
    if (!encryptedKey) throw new Error("Informe a API key para salvar esta integração.");
    await db.sql`
      insert into integration_connections(owner_id, provider, endpoint_url, auth_header, auth_prefix, encrypted_api_key)
      values (${user.workspaceId}, ${data.provider}, ${endpointUrl}, ${data.authHeader}, ${data.authPrefix}, ${encryptedKey})
      on conflict (owner_id, provider) do update set endpoint_url = excluded.endpoint_url,
        auth_header = excluded.auth_header, auth_prefix = excluded.auth_prefix,
        encrypted_api_key = excluded.encrypted_api_key, last_test_at = null, last_test_status = null, last_http_status = null,
        updated_at = now()
    `;
    const auditMetadata = JSON.stringify({ provider: data.provider });
    await db.sql`
      insert into audit_logs(actor_id, action, entity_type, metadata)
      values (${user.id}, 'integration.configured', 'integration', ${auditMetadata}::jsonb)
    `;
    return { provider: data.provider, endpointUrl, authHeader: data.authHeader, authPrefix: data.authPrefix, hasApiKey: true, lastTestAt: null, lastTestStatus: null, lastHttpStatus: null };
  });

export const testIntegrationConnection = createServerFn({ method: "POST" })
  .validator((data: unknown) => providerInput.parse(data))
  .handler(async ({ data }) => {
    const user = await requireAuthenticatedPrincipal();
    requireWorkspaceAdmin(user);
    const db = getServerDatabase();
    await ensureUser(db, user);
    const rows = await db.sql<IntegrationRow>`
      select provider, endpoint_url, auth_header, auth_prefix, encrypted_api_key, last_test_at, last_test_status, last_http_status
      from integration_connections where owner_id = ${user.workspaceId} and provider = ${data.provider} limit 1
    `;
    const row = rows[0];
    if (!row) throw new Error("Salve a URL e a credencial antes de testar.");
    validateIntegrationEndpoint(row.provider, row.endpoint_url);
    if (row.last_test_at && Date.now() - new Date(row.last_test_at).getTime() < 15_000) {
      throw new Error("Aguarde 15 segundos antes de testar esta integração novamente.");
    }
    const apiKey = decryptIntegrationSecret(row.encrypted_api_key);
    const headerValue = `${row.auth_prefix}${row.auth_prefix ? " " : ""}${apiKey}`;
    let status: number | null = null;
    let testStatus = "error";
    try {
      const headers = new Headers({ Accept: "application/json" });
      headers.set(row.auth_header, headerValue);
      const endpoint = new URL(row.endpoint_url);
      if (row.provider === "prospectab") endpoint.searchParams.set("limit", "1");
      const response = await fetch(endpoint, {
        method: "GET", headers, redirect: "error", cache: "no-store", signal: AbortSignal.timeout(10_000),
      });
      status = response.status;
      await response.body?.cancel();
      testStatus = response.ok ? "connected" : "http_error";
    } catch {
      testStatus = "network_error";
    }
    await db.sql`
      update integration_connections set last_test_at = now(), last_test_status = ${testStatus},
        last_http_status = ${status}, updated_at = now()
      where owner_id = ${user.workspaceId} and provider = ${data.provider}
    `;
    await db.sql`
      insert into audit_logs(actor_id, action, entity_type, metadata)
      values (${user.id}, 'integration.connection_tested', 'integration', jsonb_build_object('provider', ${data.provider}::text, 'result', ${testStatus}::text, 'status', ${status}::integer))
    `;
    return { provider: data.provider, status: testStatus, httpStatus: status, checkedAt: new Date().toISOString() };
  });

export const deleteIntegrationSettings = createServerFn({ method: "POST" })
  .validator((data: unknown) => providerInput.parse(data))
  .handler(async ({ data }) => {
    const user = await requireAuthenticatedPrincipal();
    requireWorkspaceAdmin(user);
    const db = getServerDatabase();
    await ensureUser(db, user);
    await db.sql`delete from integration_connections where owner_id = ${user.workspaceId} and provider = ${data.provider}`;
    await db.sql`
      insert into audit_logs(actor_id, action, entity_type, metadata)
      values (${user.id}, 'integration.removed', 'integration', jsonb_build_object('provider', ${data.provider}::text))
    `;
    return emptySettings(data.provider);
  });

function toPublicSettings(row: IntegrationRow) {
  return {
    provider: row.provider, endpointUrl: row.endpoint_url, authHeader: row.auth_header, authPrefix: row.auth_prefix,
    hasApiKey: Boolean(row.encrypted_api_key), lastTestAt: row.last_test_at ? isoDate(row.last_test_at) : null,
    lastTestStatus: row.last_test_status, lastHttpStatus: row.last_http_status,
  };
}
function emptySettings(provider: Provider) {
  return { provider, endpointUrl: defaultEndpoint(provider), authHeader: "Authorization", authPrefix: "Bearer", hasApiKey: false, lastTestAt: null, lastTestStatus: null, lastHttpStatus: null };
}
function defaultEndpoint(provider: Provider): string {
  return provider === "prospectab"
    ? "https://prospectab.lovable.app/api/public/v1/leads?limit=50"
    : "https://machtkin.lovable.app/api/public/v1/leads";
}
function isoDate(value: string | Date): string { return value instanceof Date ? value.toISOString() : new Date(value).toISOString(); }
async function ensureUser(db: ReturnType<typeof getServerDatabase>, user: { id: string; email: string | null }): Promise<void> {
  await db.sql`insert into app_users(id, email) values (${user.id}, ${user.email}) on conflict (id) do update set email = excluded.email, updated_at = now()`;
  await db.sql`insert into user_profiles(user_id) values (${user.id}) on conflict (user_id) do nothing`;
}
