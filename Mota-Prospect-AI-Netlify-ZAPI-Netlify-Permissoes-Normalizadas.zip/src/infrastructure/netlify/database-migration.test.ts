import { NetlifyDB } from "@netlify/database-dev";
import { resolve } from "node:path";
import { afterAll, beforeAll, describe, expect, it } from "vitest";

describe("Netlify Database initial migration", () => {
  const db = new NetlifyDB({ logger: () => undefined });
  beforeAll(async () => {
    await db.start();
    await db.applyMigrations(resolve(process.cwd(), "netlify/database/migrations"));
  });
  afterAll(async () => { await db.stop(); });

  it("creates the lead schema and isolates leads by owner", async () => {
    const firstOwner = "00000000-0000-4000-8000-000000000001";
    const secondOwner = "00000000-0000-4000-8000-000000000002";
    await db.query("insert into app_users(id, email) values ($1, $2), ($3, $4)", [firstOwner, "first@example.test", secondOwner, "second@example.test"]);
    await db.query("insert into user_profiles(user_id) values ($1), ($2)", [firstOwner, secondOwner]);
    await db.query("insert into leads(owner_id, company_name) values ($1, $2), ($3, $4)", [firstOwner, "Empresa A", secondOwner, "Empresa B"]);

    const visible = await db.query<{ company_name: string }>("select company_name from leads where owner_id = $1", [firstOwner]);
    const index = await db.query<{ indexname: string }>("select indexname from pg_indexes where tablename = 'leads'");
    const integrations = await db.query<{ exists: string | null }>("select to_regclass('public.integration_connections')::text as exists");
    const providerTables = await db.query<{ providers: string | null; states: string | null }>("select to_regclass('public.provider_connections')::text as providers, to_regclass('public.oauth_pending_states')::text as states");
    const authTables = await db.query<{ sessions: string | null; attempts: string | null; bootstrap: string | null }>("select to_regclass('public.auth_sessions')::text as sessions, to_regclass('public.auth_login_attempts')::text as attempts, to_regclass('public.auth_bootstrap')::text as bootstrap");
    const authColumns = await db.query<{ column_name: string }>("select column_name from information_schema.columns where table_name = 'app_users' and column_name in ('password_hash', 'is_admin', 'disabled_at', 'team_owner_id')");
    expect(visible.rows.map((row) => row.company_name)).toEqual(["Empresa A"]);
    expect(index.rows.map((row) => row.indexname)).toContain("leads_owner_company_unique");
    expect(integrations.rows[0]?.exists).toBe("integration_connections");
    expect(providerTables.rows[0]).toEqual({ providers: "provider_connections", states: "oauth_pending_states" });
    await db.query("insert into audit_logs(actor_id, action, entity_type, metadata) values ($1, 'provider.configured', 'integration', $2::jsonb)", [firstOwner, JSON.stringify({ provider: "cnpj_biz" })]);
    await db.query("insert into audit_logs(actor_id, action, entity_type, metadata) values ($1, 'integration.configured', 'integration', $2::jsonb)", [firstOwner, JSON.stringify({ provider: "machtkin" })]);
    const audits = await db.query<{ action: string; metadata: { provider: string } }>("select action, metadata from audit_logs where actor_id = $1 and action in ('provider.configured', 'integration.configured') order by action", [firstOwner]);
    expect(audits.rows).toEqual([
      { action: "integration.configured", metadata: { provider: "machtkin" } },
      { action: "provider.configured", metadata: { provider: "cnpj_biz" } },
    ]);
    expect(authTables.rows[0]).toEqual({ sessions: "auth_sessions", attempts: "auth_login_attempts", bootstrap: "auth_bootstrap" });
    expect(authColumns.rows.map((row) => row.column_name).sort()).toEqual(["disabled_at", "is_admin", "password_hash", "team_owner_id"]);
    const memberId = "00000000-0000-4000-8000-000000000004";
    await db.query("insert into app_users(id, email, password_hash, is_admin, team_owner_id) values ($1, $2, $3, false, $4)", [memberId, "sales@example.test", "test-hash", firstOwner]);
    const member = await db.query<{ workspace_id: string; is_admin: boolean }>("select coalesce(team_owner_id, id) as workspace_id, is_admin from app_users where id = $1", [memberId]);
    expect(member.rows[0]).toEqual({ workspace_id: firstOwner, is_admin: false });
    const handoffs = await db.query<{ table_name: string | null }>("select to_regclass('public.human_handoff_requests')::text as table_name");
    const runs = await db.query<{ table_name: string | null }>("select to_regclass('public.prospecting_runs')::text as table_name");
    expect(handoffs.rows[0]?.table_name).toBe("human_handoff_requests");
    expect(runs.rows[0]?.table_name).toBe("prospecting_runs");
    const cycles = await db.query<{ table_name: string | null; cycle_key: string | null }>("select to_regclass('public.prospecting_search_daily_usage')::text as table_name, (select column_name from information_schema.columns where table_name = 'prospecting_runs' and column_name = 'cycle_key') as cycle_key");
    expect(cycles.rows[0]).toEqual({ table_name: "prospecting_search_daily_usage", cycle_key: "cycle_key" });
    const shiftStart = "2026-10-19T12:00:00.000Z";
    await db.query("insert into prospecting_runs(owner_id, shift_started_at, started_by, status, cycle_key) values ($1, $2, $1, 'completed', 'initial'), ($1, $2, $1, 'completed', 'slot-1')", [firstOwner, shiftStart]);
    const searchLimit = () => db.query("insert into prospecting_search_daily_usage(owner_id, usage_date, request_count) values ($1, '2026-10-19', 1) on conflict(owner_id, usage_date) do update set request_count = prospecting_search_daily_usage.request_count + 1 where prospecting_search_daily_usage.request_count < 6 returning request_count", [firstOwner]);
    await db.query("insert into prospecting_search_daily_usage(owner_id, usage_date, request_count) values ($1, '2026-10-19', 5)", [firstOwner]);
    const searchResults = await Promise.all([searchLimit(), searchLimit()]);
    expect(searchResults.filter((result) => result.rows.length === 1)).toHaveLength(1);
  });

  it("rejects duplicate companies for the same owner", async () => {
    const owner = "00000000-0000-4000-8000-000000000003";
    await db.query("insert into app_users(id, email) values ($1, $2)", [owner, "third@example.test"]);
    await db.query("insert into leads(owner_id, company_name) values ($1, $2)", [owner, "Duplicada"]);
    await expect(db.query("insert into leads(owner_id, company_name) values ($1, $2)", [owner, "duplicada"])).rejects.toThrow();
  });

  it("creates review metadata and enforces the daily prospecting cap atomically", async () => {
    const owner = "00000000-0000-4000-8000-000000000005";
    await db.query("insert into app_users(id, email) values ($1, $2)", [owner, "review@example.test"]);
    const lead = await db.query<{ id: string }>("insert into leads(owner_id, company_name) values ($1, $2) returning id", [owner, "Lead para revisão"]);
    const approved = await db.query<{ id: string; review_status: string; duplicate_of: string | null }>(`
      with updated as (
        update leads set review_status = $1, reviewed_by = $2, reviewed_at = now(), duplicate_of = $3::uuid, updated_at = now()
        where id = $4 and owner_id = $5 returning *
      ), logged as (
        insert into audit_logs(actor_id, action, entity_type, entity_id, metadata)
        select $6, 'lead.review_decided', 'lead', id, jsonb_build_object('status', $7::text, 'duplicateOf', $8::text) from updated returning id
      ) select * from updated
    `, ["approved", owner, null, lead.rows[0]?.id, owner, owner, "approved", null]);
    expect(approved.rows[0]).toMatchObject({ id: lead.rows[0]?.id, review_status: "approved", duplicate_of: null });
    const columns = await db.query<{ column_name: string }>("select column_name from information_schema.columns where table_name = 'leads' and column_name in ('review_status', 'reviewed_by', 'reviewed_at', 'duplicate_of') order by column_name");
    expect(columns.rows.map((row) => row.column_name)).toEqual(["duplicate_of", "review_status", "reviewed_at", "reviewed_by"]);
    await db.query("insert into prospecting_daily_usage(owner_id, usage_date, processed_count) values ($1, '2026-10-19', 20)", [owner]);
    const reserve = () => db.query("insert into prospecting_daily_usage(owner_id, usage_date, processed_count) values ($1, '2026-10-19', 10) on conflict(owner_id, usage_date) do update set processed_count = prospecting_daily_usage.processed_count + excluded.processed_count where prospecting_daily_usage.processed_count + excluded.processed_count <= 30 returning processed_count", [owner]);
    const results = await Promise.all([reserve(), reserve()]);
    expect(results.filter((result) => result.rows.length === 1)).toHaveLength(1);
    const usage = await db.query<{ processed_count: number }>("select processed_count from prospecting_daily_usage where owner_id = $1 and usage_date = '2026-10-19'", [owner]);
    expect(usage.rows[0]?.processed_count).toBe(30);
  });

  it("creates an isolated simulated inbox with idempotent message storage", async () => {
    const owner = "00000000-0000-4000-8000-000000000006";
    await db.query("insert into app_users(id, email) values ($1, $2)", [owner, "inbox@example.test"]);
    await db.query("insert into leads(owner_id, company_name) values ($1, $2)", [owner, "Inbox Local"]);
    const tables = await db.query<{ conversations: string | null; messages: string | null; notes: string | null }>("select to_regclass('public.conversations')::text as conversations, to_regclass('public.conversation_messages')::text as messages, to_regclass('public.conversation_notes')::text as notes");
    expect(tables.rows[0]).toEqual({ conversations: "conversations", messages: "conversation_messages", notes: "conversation_notes" });
    const conversation = await db.query<{ id: string }>("insert into conversations(owner_id, lead_id) select $1, id from leads where owner_id = $1 returning id", [owner]);
    const id = conversation.rows[0]?.id;
    const key = "00000000-0000-4000-8000-000000000007";
    const insert = () => db.query("insert into conversation_messages(owner_id, conversation_id, direction, author_kind, body, idempotency_key) values ($1,$2,'inbound','contact','Mensagem de teste',$3) on conflict(owner_id,idempotency_key) do nothing returning id", [owner, id, key]);
    const first = await insert(); const retry = await insert();
    expect(first.rows).toHaveLength(1);
    expect(retry.rows).toHaveLength(0);
    const message = await db.query<{ is_simulated: boolean; delivery_status: string }>("select is_simulated, delivery_status from conversation_messages where owner_id = $1 and idempotency_key = $2", [owner, key]);
    expect(message.rows[0]).toEqual({ is_simulated: true, delivery_status: "simulated" });
    const conversationState = await db.query<{ automation_mode: string; last_inbound_at: string | null }>("select automation_mode, last_inbound_at from conversations where id = $1", [id]);
    expect(conversationState.rows[0]).toEqual({ automation_mode: "assisted", last_inbound_at: null });
    await db.query("insert into conversation_messages(owner_id, conversation_id, direction, author_kind, body, delivery_status, is_simulated, idempotency_key) values ($1,$2,'outbound','seller','estado incerto','unknown',false,$3)", [owner, id, "00000000-0000-4000-8000-000000000008"]);
    const messaging = await db.query<{ enabled: boolean | null; events: string | null }>("select (select ycloud_messaging_enabled from user_operating_settings where owner_id = $1) as enabled, to_regclass('public.ycloud_webhook_events')::text as events", [owner]);
    expect(messaging.rows[0]).toEqual({ enabled: null, events: "ycloud_webhook_events" });
    await db.query("insert into ycloud_webhook_events(owner_id, external_event_id, event_type, payload_sha256) values ($1, 'evt_synthetic_test', 'synthetic.event', repeat('a',64))", [owner]);
    await db.query("insert into ycloud_webhook_events(owner_id, external_event_id, event_type, payload_sha256) values ($1, 'evt_synthetic_test', 'synthetic.event', repeat('a',64)) on conflict(owner_id, external_event_id) do nothing", [owner]);
    const event = await db.query<{ status: string; attempts: number }>("select status, attempts from ycloud_webhook_events where owner_id = $1 and external_event_id = 'evt_synthetic_test'", [owner]);
    expect(event.rows[0]).toEqual({ status: "received", attempts: 0 });
    const eventCount = await db.query<{ count: number }>("select count(*)::int as count from ycloud_webhook_events where owner_id = $1 and external_event_id = 'evt_synthetic_test'", [owner]);
    expect(eventCount.rows[0]?.count).toBe(1);
  });
});
