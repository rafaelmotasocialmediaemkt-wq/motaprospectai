// The browser-only demo is available exclusively in local Vite development.
export const isDemoMode = import.meta.env.DEV && import.meta.env.VITE_MOTA_DEMO_MODE !== "false";
