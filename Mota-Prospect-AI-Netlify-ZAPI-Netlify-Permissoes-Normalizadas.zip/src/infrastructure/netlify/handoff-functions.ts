import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getServerDatabase } from "./database.server";
import { requireAuthenticatedPrincipal } from "./server-auth";

const empty = z.object({}); const requestSchema = z.object({ leadId: z.uuid(), note: z.string().trim().max(1000).default("") });
const actionSchema = z.object({ id: z.uuid(), action: z.enum(["assign", "resolve", "dismiss"]) });
type HandoffRow = { id: string; lead_id: string; company_name: string; status: string; note: string; requested_by: string; assigned_to: string | null; created_at: string | Date };

export const listHumanHandoffs = createServerFn({ method: "POST" }).validator((v: unknown) => empty.parse(v)).handler(async () => {
  const actor = await requireAuthenticatedPrincipal(); const db = getServerDatabase();
  const rows = await db.sql<HandoffRow>`
    select h.id, h.lead_id, l.company_name, h.status, h.note, h.requested_by, h.assigned_to, h.created_at
    from human_handoff_requests h join leads l on l.id = h.lead_id and l.owner_id = h.owner_id
    where h.owner_id = ${actor.workspaceId} and h.status in ('pending','assigned') order by h.created_at desc limit 100
  `;
  return rows.map((r) => ({ id: r.id, leadId: r.lead_id, companyName: r.company_name, status: r.status, note: r.note, requestedBy: r.requested_by, assignedTo: r.assigned_to, canResolve: actor.isAdmin || r.assigned_to === actor.id, createdAt: new Date(r.created_at).toISOString() }));
});

export const requestHumanHandoff = createServerFn({ method: "POST" }).validator((v: unknown) => requestSchema.parse(v)).handler(async ({ data }) => {
  const actor = await requireAuthenticatedPrincipal(); const db = getServerDatabase();
  const rows = await db.sql<{ id: string }>`
    with valid_lead as (select id from leads where id = ${data.leadId} and owner_id = ${actor.workspaceId}), created as (
      insert into human_handoff_requests(owner_id, lead_id, requested_by, note)
      select ${actor.workspaceId}, id, ${actor.id}, ${data.note} from valid_lead
      on conflict(owner_id, lead_id) where status in ('pending','assigned') do nothing returning id, lead_id
    ), logged as (
      insert into audit_logs(actor_id, action, entity_type, entity_id)
      select ${actor.id}, 'lead.human_handoff_requested', 'lead', lead_id from created returning id
    ) select id from created union all
      select h.id from human_handoff_requests h join valid_lead l on l.id = h.lead_id
      where h.owner_id = ${actor.workspaceId} and h.status in ('pending','assigned') limit 1
  `;
  if (!rows[0]) throw new Error("Lead não encontrado neste workspace.");
  return { id: rows[0].id };
});

export const updateHumanHandoff = createServerFn({ method: "POST" }).validator((v: unknown) => actionSchema.parse(v)).handler(async ({ data }) => {
  const actor = await requireAuthenticatedPrincipal(); const db = getServerDatabase();
  const status = data.action === "assign" ? "assigned" : data.action === "resolve" ? "resolved" : "dismissed";
  const rows = await db.sql<{ id: string; lead_id: string }>`
    update human_handoff_requests set status = ${status}, assigned_to = case when ${status} = 'assigned' then ${actor.id}::uuid else assigned_to end, updated_at = now()
    where id = ${data.id} and owner_id = ${actor.workspaceId} and status in ('pending','assigned')
      and (status = 'pending' or assigned_to = ${actor.id} or ${actor.isAdmin})
    returning id, lead_id
  `;
  if (!rows[0]) throw new Error("Solicitação não encontrada ou não atribuída a você.");
  await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id) values (${actor.id}, ${`lead.human_handoff_${status}`}, 'lead', ${rows[0].lead_id})`;
  return { id: rows[0].id, status };
});
