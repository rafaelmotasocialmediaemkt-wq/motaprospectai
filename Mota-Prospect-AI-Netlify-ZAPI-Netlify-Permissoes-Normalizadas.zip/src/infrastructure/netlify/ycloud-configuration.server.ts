import { decryptIntegrationSecret } from "./integration-secrets.server";
import type { getServerDatabase } from "./database.server";
import { isE164 } from "../ycloud/client";

type Database = ReturnType<typeof getServerDatabase>;
type YCloudSecretBundle = { apiKey: string; webhookSigningSecret: string };
export type YCloudConfiguration = YCloudSecretBundle & { phoneNumber: string; missing: string[] };

/** Secrets saved from the admin UI are encrypted in provider_connections and never returned to the browser. */
export function parseYCloudSecretBundle(encryptedSecret: string | null | undefined): YCloudSecretBundle {
  if (!encryptedSecret) return { apiKey: "", webhookSigningSecret: "" };
  const decrypted = decryptIntegrationSecret(encryptedSecret);
  try {
    const parsed: unknown = JSON.parse(decrypted);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      const record = parsed as Record<string, unknown>;
      return {
        apiKey: typeof record.apiKey === "string" ? record.apiKey.trim() : "",
        webhookSigningSecret: typeof record.webhookSigningSecret === "string" ? record.webhookSigningSecret.trim() : "",
      };
    }
  } catch {
    // Prior UI versions stored a single encrypted API key string.
  }
  return { apiKey: decrypted.trim(), webhookSigningSecret: "" };
}

export async function getYCloudConfiguration(db: Database, workspaceId: string): Promise<YCloudConfiguration> {
  const rows = await db.sql<{ config: Record<string, string>; encrypted_secret: string | null }>`
    select config, encrypted_secret from provider_connections
    where owner_id = ${workspaceId} and provider = 'whatsapp_cloud' limit 1
  `;
  const row = rows[0];
  const saved = parseYCloudSecretBundle(row?.encrypted_secret);
  const apiKey = saved.apiKey || process.env.YCLOUD_API_KEY?.trim() || "";
  const webhookSigningSecret = saved.webhookSigningSecret || process.env.YCLOUD_WEBHOOK_SIGNING_SECRET?.trim() || "";
  const phoneNumber = row?.config.phoneNumber?.trim() || process.env.YCLOUD_PHONE_NUMBER?.trim() || "";
  const missing: string[] = [];
  if (!apiKey) missing.push("YCLOUD_API_KEY");
  if (!webhookSigningSecret) missing.push("YCLOUD_WEBHOOK_SIGNING_SECRET");
  if (!isE164(phoneNumber)) missing.push("YCLOUD_PHONE_NUMBER (formato +55…)");
  const configuredWorkspace = process.env.YCLOUD_WORKSPACE_ID?.trim();
  if (configuredWorkspace && configuredWorkspace !== workspaceId) missing.push("YCLOUD_WORKSPACE_ID (não corresponde ao administrador conectado)");
  return { apiKey, webhookSigningSecret, phoneNumber, missing };
}
