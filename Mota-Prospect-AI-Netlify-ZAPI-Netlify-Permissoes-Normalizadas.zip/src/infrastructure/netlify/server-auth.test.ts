import { beforeEach, describe, expect, it, vi } from "vitest";

const { getCookie, sql } = vi.hoisted(() => ({ getCookie: vi.fn(), sql: vi.fn() }));
vi.mock("@tanstack/react-start/server", () => ({ getCookie }));
vi.mock("./database.server", () => ({ getServerDatabase: () => ({ sql }) }));

import { hashToken, requireAuthenticatedPrincipal, requireWorkspaceAdmin } from "./server-auth";

describe("Netlify Database session validation", () => {
  beforeEach(() => { getCookie.mockReset(); sql.mockReset(); });

  it("fails closed when there is no HttpOnly session cookie", async () => {
    getCookie.mockReturnValue(undefined);
    await expect(requireAuthenticatedPrincipal()).rejects.toThrow("Sessão ausente ou expirada");
    expect(sql).not.toHaveBeenCalled();
  });

  it("returns the principal linked to a live server-side session", async () => {
    const token = "a".repeat(43);
    getCookie.mockReturnValue(token);
    sql.mockResolvedValue([{ id: "123e4567-e89b-12d3-a456-426614174000", email: "person@example.test", workspace_id: "123e4567-e89b-12d3-a456-426614174000", is_admin: true }]);
    await expect(requireAuthenticatedPrincipal()).resolves.toEqual({ id: "123e4567-e89b-12d3-a456-426614174000", email: "person@example.test", workspaceId: "123e4567-e89b-12d3-a456-426614174000", isAdmin: true });
    expect(sql.mock.calls[0]?.[1]).toContain(hashToken(token));
  });

  it("rejects revoked or expired sessions without revealing details", async () => {
    getCookie.mockReturnValue("b".repeat(43));
    sql.mockResolvedValue([]);
    await expect(requireAuthenticatedPrincipal()).rejects.toThrow("Sessão ausente ou expirada");
  });

  it("rejects malformed cookies before querying the database", async () => {
    getCookie.mockReturnValue("invalid token");
    await expect(requireAuthenticatedPrincipal()).rejects.toThrow("Sessão ausente ou expirada");
    expect(sql).not.toHaveBeenCalled();
  });

  it("denies workspace administration to a sales member", () => {
    expect(() => requireWorkspaceAdmin({ id: "sales", email: "seller@example.test", workspaceId: "owner", isAdmin: false })).toThrow("Apenas a administradora");
  });
});
