import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { ReplyAssistanceService } from "../../application/messaging/reply-assistance";
import { GeminiConversationAiProvider } from "../gemini/client";
import { getServerDatabase } from "./database.server";
import { requireAuthenticatedPrincipal } from "./server-auth";

const empty = z.object({});
const conversationInput = z.object({ conversationId: z.uuid() });

export const getGeminiReplyStatus = createServerFn({ method: "POST" }).validator((data: unknown) => empty.parse(data)).handler(async () => {
  await requireAuthenticatedPrincipal();
  return { configured: Boolean(process.env.GEMINI_API_KEY?.trim()), model: process.env.GEMINI_MODEL?.trim() || "gemini-4-argon" };
});

export const suggestGeminiReply = createServerFn({ method: "POST" }).validator((data: unknown) => conversationInput.parse(data)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal();
  const db = getServerDatabase();
  const settings = await db.sql<{ ai_enabled: boolean }>`select ai_enabled from user_operating_settings where owner_id = ${user.workspaceId} limit 1`;
  if (!settings[0]?.ai_enabled) throw new Error("Ative o motor Gemini em Configurações antes de pedir uma sugestão.");
  const conversations = await db.sql<{ company_name: string; stage: string; opted_out_at: string | Date | null; status: string; ai_paused: boolean; automation_mode: string }>`
    select l.company_name, l.stage, l.opted_out_at, c.status, c.ai_paused, c.automation_mode
    from conversations c join leads l on l.id = c.lead_id and l.owner_id = c.owner_id
    where c.id = ${data.conversationId} and c.owner_id = ${user.workspaceId} limit 1
  `;
  const conversation = conversations[0];
  if (!conversation) throw new Error("Conversa não encontrada neste workspace.");
  if (conversation.opted_out_at) throw new Error("Contato com opt-out ativo. Sugestão bloqueada.");
  if (conversation.status === "closed" || conversation.ai_paused || conversation.automation_mode === "human") throw new Error("Ative a assistência e deixe a conversa aberta para solicitar uma sugestão.");
  const apiKey = process.env.GEMINI_API_KEY?.trim() ?? "";
  if (!apiKey) throw new Error("GEMINI_API_KEY não configurada no servidor.");
  const messages = await db.sql<{ direction: "inbound" | "outbound"; body: string }>`
    select direction, body from conversation_messages
    where owner_id = ${user.workspaceId} and conversation_id = ${data.conversationId} and direction in ('inbound','outbound')
    order by created_at desc limit 20
  `;
  const suggestion = await new ReplyAssistanceService(new GeminiConversationAiProvider(apiKey, process.env.GEMINI_MODEL?.trim() || "gemini-4-argon")).suggest({
    companyName: conversation.company_name,
    leadFacts: [`Etapa atual do funil: ${conversation.stage}`],
    recentMessages: messages.reverse().map((message) => ({ direction: message.direction, body: message.body })),
    optedOut: false,
    humanOwnsConversation: false,
  });
  await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${user.id}, 'gemini.reply_suggested', 'conversation', ${data.conversationId}, jsonb_build_object('model', ${process.env.GEMINI_MODEL?.trim() || "gemini-4-argon"}, 'requiresHuman', ${suggestion.requiresHuman}, 'intent', ${suggestion.intent}))`;
  return suggestion;
});
