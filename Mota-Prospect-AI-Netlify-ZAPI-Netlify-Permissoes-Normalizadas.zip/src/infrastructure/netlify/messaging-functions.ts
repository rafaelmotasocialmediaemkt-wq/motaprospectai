import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { isClearOptOut } from "../../application/messaging/opt-out";
import { getServerDatabase } from "./database.server";
import { requireAuthenticatedPrincipal } from "./server-auth";

const empty = z.object({});
const leadRequest = z.object({ leadId: z.uuid() });
const conversationRequest = z.object({ conversationId: z.uuid() });
const messageRequest = z.object({ conversationId: z.uuid(), body: z.string().trim().min(1).max(4000), direction: z.enum(["inbound", "outbound"]), idempotencyKey: z.uuid().optional() }).refine((data) => data.direction !== "inbound" || Boolean(data.idempotencyKey), "Mensagens simuladas recebidas exigem chave de idempotência.");
const statusRequest = z.object({ conversationId: z.uuid(), status: z.enum(["open", "waiting", "closed", "take", "pause", "resume"]) });
const noteRequest = z.object({ conversationId: z.uuid(), body: z.string().trim().min(1).max(2000) });

export const listInbox = createServerFn({ method: "POST" }).validator((data: unknown) => empty.parse(data)).handler(async () => {
  const user = await requireAuthenticatedPrincipal();
  const db = getServerDatabase();
  const rows = await db.sql<{ id: string; lead_id: string; company_name: string; phone: string | null; email: string | null; stage: string; opted_out_at: string | Date | null; status: string; assigned_to: string | null; ai_paused: boolean; last_message_at: string | Date; last_body: string | null; last_direction: string | null; unread_count: number }>`
    select c.id, c.lead_id, l.company_name, l.phone, l.email, l.stage, l.opted_out_at,
      c.status, c.assigned_to, c.ai_paused, c.last_message_at,
      latest.body as last_body, latest.direction as last_direction,
      (select count(*)::int from conversation_messages unread where unread.conversation_id = c.id and unread.direction = 'inbound' and unread.created_at > coalesce((select max(outbound.created_at) from conversation_messages outbound where outbound.conversation_id = c.id and outbound.direction = 'outbound'), '-infinity'::timestamptz)) as unread_count
    from conversations c join leads l on l.id = c.lead_id and l.owner_id = c.owner_id
    left join lateral (select body, direction from conversation_messages m where m.conversation_id = c.id order by created_at desc limit 1) latest on true
    where c.owner_id = ${user.workspaceId} order by c.last_message_at desc limit 300
  `;
  return rows.map((row) => ({ id: row.id, leadId: row.lead_id, companyName: row.company_name, phone: row.phone, email: row.email, stage: row.stage, optedOut: Boolean(row.opted_out_at), status: row.status, assignedTo: row.assigned_to, aiPaused: row.ai_paused, lastMessageAt: iso(row.last_message_at), lastBody: row.last_body, lastDirection: row.last_direction, unreadCount: Number(row.unread_count) }));
});

export const openInboxConversation = createServerFn({ method: "POST" }).validator((data: unknown) => leadRequest.parse(data)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal();
  const db = getServerDatabase();
  const rows = await db.sql<{ id: string }>`
    insert into conversations(owner_id, lead_id, assigned_to, ai_paused)
    select ${user.workspaceId}, l.id, ${user.id}, true from leads l where l.id = ${data.leadId} and l.owner_id = ${user.workspaceId}
    on conflict(owner_id, lead_id) do update set updated_at = now()
    returning id
  `;
  if (!rows[0]) throw new Error("Lead não encontrado neste workspace.");
  await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${user.id}, 'conversation.opened', 'conversation', ${rows[0].id}, '{"mode":"simulated"}'::jsonb)`;
  return { id: rows[0].id };
});

export const listConversationMessages = createServerFn({ method: "POST" }).validator((data: unknown) => conversationRequest.parse(data)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal();
  const db = getServerDatabase();
  const rows = await db.sql<{ id: string; direction: string; author_kind: string; body: string; delivery_status: string; is_simulated: boolean; created_at: string | Date; created_by: string | null }>`
    select * from (
    select m.id, m.direction, m.author_kind, m.body, m.delivery_status, m.is_simulated, m.created_at, m.created_by
    from conversation_messages m join conversations c on c.id = m.conversation_id and c.owner_id = m.owner_id
    where m.owner_id = ${user.workspaceId} and c.id = ${data.conversationId}
    union all
    select n.id, 'internal'::text, 'system'::text, n.body, 'internal'::text, false, n.created_at, n.author_id
    from conversation_notes n join conversations c on c.id = n.conversation_id and c.owner_id = n.owner_id
    where n.owner_id = ${user.workspaceId} and c.id = ${data.conversationId}
    ) timeline order by created_at, id limit 500
  `;
  return rows.map((row) => ({ id: row.id, direction: row.direction, author: row.author_kind, body: row.body, status: row.delivery_status, simulated: row.is_simulated, createdAt: iso(row.created_at), createdBy: row.created_by }));
});

export const simulateInboxMessage = createServerFn({ method: "POST" }).validator((data: unknown) => messageRequest.parse(data)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal();
  const db = getServerDatabase();
  const inbound = data.direction === "inbound";
  const direction = inbound ? "inbound" : "outbound";
  const author = inbound ? "contact" : "seller";
  const rows = await db.sql<{ id: string; lead_id: string }>`
    with inserted as (
      insert into conversation_messages(owner_id, conversation_id, direction, author_kind, body, delivery_status, is_simulated, idempotency_key, created_by)
      select ${user.workspaceId}, c.id, ${direction}, ${author}, ${data.body}, 'simulated', true, ${data.idempotencyKey ?? null}, ${user.id}
      from conversations c join leads l on l.id = c.lead_id and l.owner_id = c.owner_id
      where c.id = ${data.conversationId} and c.owner_id = ${user.workspaceId}
        and c.status <> 'closed' and ((${inbound}) or (not ${inbound} and l.opted_out_at is null))
      on conflict(owner_id, idempotency_key) do nothing
      returning id, conversation_id
    ), touched as (
      update conversations c set last_message_at = now(), updated_at = now(), status = case when ${inbound} then 'waiting' else c.status end,
        ai_paused = case when ${inbound} then true else c.ai_paused end
      from inserted i where c.id = i.conversation_id and c.owner_id = ${user.workspaceId}
      returning c.id, c.lead_id
    ), logged as (
      insert into audit_logs(actor_id, action, entity_type, entity_id, metadata)
      select ${user.id}, ${inbound ? "conversation.inbound_simulated" : "conversation.outbound_simulated"}, 'conversation', id,
        jsonb_build_object('simulated', true, 'messageId', (select id from inserted)) from touched returning id
    ) select touched.id, touched.lead_id from touched
  `;
  if (!rows[0]) {
    if (inbound) return { accepted: false, reason: "A mensagem já foi processada ou a conversa não está disponível.", simulated: true };
    throw new Error("Não foi possível simular o envio: conversa encerrada, opt-out ativo ou sem permissão.");
  }
  if (inbound && isClearOptOut(data.body)) {
    await db.sql`update leads set opted_out_at = coalesce(opted_out_at, now()), updated_at = now() where id = ${rows[0].lead_id} and owner_id = ${user.workspaceId}`;
    await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${user.id}, 'contact.opt_out_detected', 'lead', ${rows[0].lead_id}, '{"source":"simulated_inbound","confidence":"explicit"}'::jsonb)`;
  }
  return { accepted: true, messageId: rows[0].id, simulated: true, deliveryStatus: "simulated" };
});

export const updateInboxConversation = createServerFn({ method: "POST" }).validator((data: unknown) => statusRequest.parse(data)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal();
  const db = getServerDatabase();
  const rows = await db.sql<{ id: string }>`
    update conversations set
      status = case when ${data.status} = 'take' then 'open' when ${data.status} in ('open','waiting','closed') then ${data.status} else status end,
      assigned_to = case when ${data.status} = 'take' then ${user.id}::uuid else assigned_to end,
      ai_paused = case when ${data.status} in ('take','pause') then true when ${data.status} = 'resume' then false else ai_paused end,
      updated_at = now()
    where id = ${data.conversationId} and owner_id = ${user.workspaceId} returning id
  `;
  if (!rows[0]) throw new Error("Conversa não encontrada neste workspace.");
  await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${user.id}, ${`conversation.${data.status}`}, 'conversation', ${data.conversationId}, '{"mode":"simulated"}'::jsonb)`;
  return { ok: true };
});

export const addInboxNote = createServerFn({ method: "POST" }).validator((data: unknown) => noteRequest.parse(data)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal();
  const db = getServerDatabase();
  const rows = await db.sql<{ id: string }>`
    insert into conversation_notes(owner_id, conversation_id, author_id, body)
    select ${user.workspaceId}, c.id, ${user.id}, ${data.body} from conversations c where c.id = ${data.conversationId} and c.owner_id = ${user.workspaceId}
    returning id
  `;
  if (!rows[0]) throw new Error("Conversa não encontrada neste workspace.");
  await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id) values (${user.id}, 'conversation.internal_note_added', 'conversation', ${data.conversationId})`;
  return { ok: true };
});

function iso(value: string | Date): string { return value instanceof Date ? value.toISOString() : new Date(value).toISOString(); }
