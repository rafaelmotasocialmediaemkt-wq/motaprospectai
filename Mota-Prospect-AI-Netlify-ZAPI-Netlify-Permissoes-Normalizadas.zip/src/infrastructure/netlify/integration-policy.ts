export type CRMProvider = "prospectab" | "machtkin";

const hosts: Record<CRMProvider, string> = {
  prospectab: "prospectab.lovable.app",
  machtkin: "machtkin.lovable.app",
};

export function validateIntegrationEndpoint(provider: CRMProvider, value: string): string {
  let url: URL;
  try { url = new URL(value); } catch { throw new Error("Informe uma URL válida para o endpoint."); }
  if (url.protocol !== "https:" || url.hostname !== hosts[provider] || url.port || url.username || url.password || url.hash) {
    throw new Error("Use HTTPS e o domínio oficial informado para esta integração.");
  }
  if (url.pathname !== "/api/public/v1/leads") throw new Error("O caminho deve ser /api/public/v1/leads.");
  if (provider === "machtkin" && url.search) throw new Error("Parâmetros de URL do MachtKin ainda não foram documentados.");
  if (provider === "prospectab") {
    const keys = [...url.searchParams.keys()];
    const limit = Number(url.searchParams.get("limit") ?? "50");
    if (keys.some((key) => key !== "limit") || !Number.isInteger(limit) || limit < 1 || limit > 100) {
      throw new Error("No Prospectab, somente o parâmetro limit de 1 a 100 é aceito.");
    }
  }
  return url.toString();
}
