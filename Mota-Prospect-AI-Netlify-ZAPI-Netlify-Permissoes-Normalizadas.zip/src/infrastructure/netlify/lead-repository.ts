import type { CreateLeadInput, LeadRepository } from "../../application/leads/lead-service";
import type { Lead, LeadStage } from "../../domain/leads/lead";
import { approveAllPendingNetlifyLeads, createNetlifyLead, listNetlifyLeads, moveNetlifyLead, reviewNetlifyLead, suppressNetlifyLead, updateNetlifyLead } from "./lead-functions";

export class NetlifyLeadRepository implements LeadRepository {
  async list(): Promise<Lead[]> { return listNetlifyLeads({ data: {} }); }
  async create(input: CreateLeadInput): Promise<Lead> { return createNetlifyLead({ data: { input } }); }
  async update(id: string, input: CreateLeadInput): Promise<Lead> { return updateNetlifyLead({ data: { id, input } }); }
  async move(id: string, stage: LeadStage): Promise<Lead> { return moveNetlifyLead({ data: { id, stage } }); }
  async suppressContact(id: string): Promise<Lead> { return suppressNetlifyLead({ data: { id } }); }
  async review(id: string, status: Lead["reviewStatus"], duplicateOf?: string): Promise<Lead> { return reviewNetlifyLead({ data: { id, status, duplicateOf } }); }
  async approvePending(): Promise<Lead[]> { return approveAllPendingNetlifyLeads({ data: {} }); }
}
