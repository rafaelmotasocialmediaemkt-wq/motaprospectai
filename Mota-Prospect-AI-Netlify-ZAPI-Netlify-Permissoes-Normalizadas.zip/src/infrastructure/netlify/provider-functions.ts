import { createHash, randomBytes } from "node:crypto";
import { createServerFn } from "@tanstack/react-start";
import { getRequestUrl } from "@tanstack/react-start/server";
import { z } from "zod";
import { getServerDatabase } from "./database.server";
import { decryptIntegrationSecret, encryptIntegrationSecret } from "./integration-secrets.server";
import { requireAuthenticatedPrincipal, requireWorkspaceAdmin } from "./server-auth";
import { isValidCnpj, normalizeCnpj, publicCompanyFields } from "../../application/prospecting/cnpj";
import { isE164 } from "../ycloud/client";
import { parseYCloudSecretBundle } from "./ycloud-configuration.server";

const providerSchema = z.enum(["serpapi", "cnpj_biz", "serpro", "calendly", "google_calendar", "whatsapp_cloud", "whatsapp_zapi"]);
const providers = providerSchema.options;
const saveSchema = z.object({ provider: providerSchema, config: z.record(z.string(), z.string().max(2048)), secret: z.string().max(10000) });
const stateSchema = z.object({});
const bookingSchema = z.object({ eventTypeUri: z.string().url().max(2048), startTime: z.string().datetime({ offset: true }), name: z.string().trim().min(2).max(160), email: z.string().email().max(254), timezone: z.string().trim().min(1).max(64) });
const googleEventSchema = z.object({ summary: z.string().trim().min(2).max(200), startTime: z.string().datetime({ offset: true }), endTime: z.string().datetime({ offset: true }), attendeeEmail: z.string().email().max(254).optional().or(z.literal("")) }).refine((v) => new Date(v.endTime).getTime() > new Date(v.startTime).getTime(), "O fim deve ser depois do início.");
const calendarWindowSchema = z.object({ timeMin: z.string().datetime({ offset: true }), timeMax: z.string().datetime({ offset: true }) }).refine((v) => { const span = new Date(v.timeMax).getTime() - new Date(v.timeMin).getTime(); return span > 0 && span <= 35 * 24 * 60 * 60 * 1000; }, "Selecione um período de até 35 dias.");
const searchSchema = z.object({ query: z.string().trim().min(2).max(600) });
const cnpjSchema = z.object({ cnpj: z.string().trim().min(14).max(18).refine(isValidCnpj, "Informe um CNPJ válido, numérico ou alfanumérico.").transform(normalizeCnpj) });
type Provider = z.infer<typeof providerSchema>;
type Row = { provider: Provider; config: Record<string, string>; encrypted_secret: string | null; encrypted_token?: string | null; connected_at: string | Date | null };

export const listProviderSettings = createServerFn({ method: "POST" }).validator((v: unknown) => z.object({}).parse(v)).handler(async () => {
  const user = await requireAuthenticatedPrincipal(); const db = getServerDatabase(); await ensureUser(db, user);
  const rows = await db.sql<Row>`select provider, config, encrypted_secret, connected_at from provider_connections where owner_id = ${user.workspaceId}`;
  return providers.map((provider) => {
    const row = rows.find((r) => r.provider === provider);
    const config = { ...(row?.config ?? {}) };
    if (provider === "google_calendar" && !config.clientId && process.env.GOOGLE_OAUTH_CLIENT_ID?.trim()) config.clientId = process.env.GOOGLE_OAUTH_CLIENT_ID.trim();
    const envSecret = provider === "serpapi" ? Boolean(process.env.SERPAPI_API_KEY?.trim())
      : provider === "google_calendar" ? Boolean(process.env.GOOGLE_OAUTH_CLIENT_SECRET?.trim())
        : provider === "whatsapp_cloud" ? Boolean(process.env.YCLOUD_API_KEY?.trim() && process.env.YCLOUD_WEBHOOK_SIGNING_SECRET?.trim())
          : provider === "whatsapp_zapi" ? Boolean(process.env.ZAPI_INSTANCE_ID?.trim() && process.env.ZAPI_INSTANCE_TOKEN?.trim()) : false;
    const hasSecret = Boolean(row?.encrypted_secret) || envSecret;
    return { provider, config, hasSecret, connected: Boolean(row?.connected_at) || (provider === "serpapi" && Boolean(process.env.SERPAPI_API_KEY?.trim())), connectedAt: row?.connected_at ? iso(row.connected_at) : null };
  });
});

export const saveProviderSettings = createServerFn({ method: "POST" }).validator((v: unknown) => saveSchema.parse(v)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal(); requireWorkspaceAdmin(user); const db = getServerDatabase(); await ensureUser(db, user);
  const config = Object.fromEntries(Object.entries(data.config).map(([k, v]) => [k, v.trim()]));
  if (data.provider === "calendly" && (!config.clientId || config.clientId.length > 255 || /^https?:\/\//i.test(config.clientId))) throw new Error("Informe o Client ID OAuth do aplicativo Calendly; uma URL como https://mcp.calendly.com não é Client ID. Configure também o Client Secret no campo de credencial.");
  if (data.provider === "google_calendar" && (!config.clientId || config.clientId.length > 255 || !config.clientId.endsWith(".apps.googleusercontent.com"))) throw new Error("Informe o Client ID OAuth Web do Google (termina em .apps.googleusercontent.com) e o Client Secret no campo de credencial.");
  for (const key of ["endpointUrl"]) if (config[key]) { let u: URL; try { u = new URL(config[key]); } catch { throw new Error("Informe uma URL válida."); } if (u.protocol !== "https:" || u.username || u.password || u.hash) throw new Error("Use uma URL HTTPS sem credenciais embutidas."); }
  const existing = await db.sql<Pick<Row, "encrypted_secret">>`select encrypted_secret from provider_connections where owner_id = ${user.workspaceId} and provider = ${data.provider} limit 1`;
  let encrypted = data.secret ? encryptIntegrationSecret(data.secret) : existing[0]?.encrypted_secret ?? null;
  if (data.provider === "whatsapp_cloud") {
    if (!isE164(config.phoneNumber ?? "")) throw new Error("Informe o número empresarial conectado à YCloud em formato E.164, por exemplo +55….");
    let submitted: { apiKey?: string; webhookSigningSecret?: string } = {};
    if (data.secret) {
      try {
        const parsed: unknown = JSON.parse(data.secret);
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("invalid");
        const record = parsed as Record<string, unknown>;
        submitted = { apiKey: typeof record.apiKey === "string" ? record.apiKey.trim() : "", webhookSigningSecret: typeof record.webhookSigningSecret === "string" ? record.webhookSigningSecret.trim() : "" };
      } catch { throw new Error("As credenciais YCloud não puderam ser processadas. Preencha os dois campos secretos."); }
    }
    const previous = parseYCloudSecretBundle(existing[0]?.encrypted_secret);
    const apiKey = submitted.apiKey || previous.apiKey;
    const webhookSigningSecret = submitted.webhookSigningSecret || previous.webhookSigningSecret;
    if (!apiKey && !process.env.YCLOUD_API_KEY?.trim()) throw new Error("Informe a chave da API YCloud.");
    if (!webhookSigningSecret && !process.env.YCLOUD_WEBHOOK_SIGNING_SECRET?.trim()) throw new Error("Informe o secret de assinatura do endpoint webhook YCloud.");
    encrypted = apiKey || webhookSigningSecret ? encryptIntegrationSecret(JSON.stringify({ apiKey, webhookSigningSecret })) : null;
  } else if (data.provider === "whatsapp_zapi") {
    if (!/^[A-Fa-f0-9]{16,64}$/.test(config.instanceId ?? "")) throw new Error("Informe o ID da instância Z-API.");
    let submitted: { instanceToken?: string; clientToken?: string } = {};
    if (data.secret) {
      try {
        const parsed: unknown = JSON.parse(data.secret);
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("invalid");
        const record = parsed as Record<string, unknown>;
        submitted = { instanceToken: typeof record.instanceToken === "string" ? record.instanceToken.trim() : "", clientToken: typeof record.clientToken === "string" ? record.clientToken.trim() : "" };
      } catch { throw new Error("As credenciais Z-API não puderam ser processadas."); }
    }
    let previous: { instanceToken?: string; clientToken?: string } = {};
    if (existing[0]?.encrypted_secret) { try { previous = JSON.parse(decryptIntegrationSecret(existing[0].encrypted_secret)) as typeof previous; } catch { previous = {}; } }
    const instanceToken = submitted.instanceToken || previous.instanceToken || "";
    const clientToken = submitted.clientToken || previous.clientToken || "";
    if (!instanceToken && !process.env.ZAPI_INSTANCE_TOKEN?.trim()) throw new Error("Informe o token da instância Z-API.");
    let webhookKey = "";
    if (existing[0]?.encrypted_secret) { try { webhookKey = (JSON.parse(decryptIntegrationSecret(existing[0].encrypted_secret)) as { webhookKey?: string }).webhookKey ?? ""; } catch { webhookKey = ""; } }
    if (!webhookKey) webhookKey = randomBytes(32).toString("base64url");
    encrypted = encryptIntegrationSecret(JSON.stringify({ instanceToken, clientToken, webhookKey }));
  } else if (["serpapi", "serpro", "calendly", "google_calendar"].includes(data.provider) && !encrypted && !(data.provider === "serpapi" && process.env.SERPAPI_API_KEY?.trim()) && !(data.provider === "google_calendar" && process.env.GOOGLE_OAUTH_CLIENT_SECRET?.trim())) {
    throw new Error("Informe a credencial para salvar esta integração.");
  }
  await db.sql`insert into provider_connections(owner_id, provider, config, encrypted_secret) values (${user.workspaceId}, ${data.provider}, ${JSON.stringify(config)}::jsonb, ${encrypted}) on conflict(owner_id, provider) do update set config = excluded.config, encrypted_secret = excluded.encrypted_secret, encrypted_token = case when ${data.provider} in ('calendly','google_calendar') then null else provider_connections.encrypted_token end, connected_at = case when ${data.provider} in ('calendly','google_calendar','whatsapp_cloud','whatsapp_zapi') then null else provider_connections.connected_at end, updated_at = now()`;
  const auditMetadata = JSON.stringify({ provider: data.provider });
  await db.sql`insert into audit_logs(actor_id, action, entity_type, metadata) values (${user.id}, 'provider.configured', 'integration', ${auditMetadata}::jsonb)`;
  if (data.provider === "whatsapp_cloud") {
    await db.sql`update user_operating_settings set ycloud_messaging_enabled = false, ycloud_last_test_status = null, updated_at = now() where owner_id = ${user.workspaceId}`;
  }
  return { provider: data.provider, hasSecret: Boolean(encrypted) || (data.provider === "serpapi" && Boolean(process.env.SERPAPI_API_KEY?.trim())) || (data.provider === "google_calendar" && Boolean(process.env.GOOGLE_OAUTH_CLIENT_SECRET?.trim())) || (data.provider === "whatsapp_cloud" && Boolean(process.env.YCLOUD_API_KEY?.trim() && process.env.YCLOUD_WEBHOOK_SIGNING_SECRET?.trim())) || (data.provider === "whatsapp_zapi" && Boolean(process.env.ZAPI_INSTANCE_TOKEN?.trim())) };
});

export const beginGoogleCalendarOAuth = createServerFn({ method: "POST" }).validator((v: unknown) => stateSchema.parse(v)).handler(async ({ data }) => {
  void data;
  const user = await requireAuthenticatedPrincipal(); requireWorkspaceAdmin(user); const db = getServerDatabase(); await ensureUser(db, user);
  const rows = await db.sql<Row>`select provider, config, encrypted_secret, connected_at from provider_connections where owner_id = ${user.workspaceId} and provider = 'google_calendar' limit 1`;
  const row = rows[0]; const clientId = row?.config.clientId?.trim() || process.env.GOOGLE_OAUTH_CLIENT_ID?.trim() || ""; const clientSecret = row?.encrypted_secret ? decryptIntegrationSecret(row.encrypted_secret) : process.env.GOOGLE_OAUTH_CLIENT_SECRET?.trim() || "";
  if (!clientId || !clientSecret) throw new Error("Configure GOOGLE_OAUTH_CLIENT_ID e GOOGLE_OAUTH_CLIENT_SECRET no Netlify ou salve o Client ID e o Client Secret no painel Integrações.");
  const base = getRequestUrl();
  const redirectUri = new URL("/integrations?oauth=google", base).toString();
  if (base.protocol !== "https:" && base.hostname !== "localhost" && base.hostname !== "127.0.0.1") throw new Error("O retorno OAuth exige HTTPS.");
  const state = randomBytes(32).toString("base64url"); const verifier = randomBytes(32).toString("base64url");
  const challenge = createHash("sha256").update(verifier).digest("base64url");
  await db.sql`delete from oauth_pending_states where expires_at < now()`;
  await db.sql`insert into provider_connections(owner_id, provider, config) values (${user.workspaceId}, 'google_calendar', ${JSON.stringify({ clientId })}::jsonb) on conflict(owner_id, provider) do update set config = provider_connections.config || excluded.config, updated_at = now()`;
  await db.sql`insert into oauth_pending_states(state_hash, owner_id, provider, encrypted_verifier, redirect_uri, expires_at) values (${createHash("sha256").update(state).digest("hex")}, ${user.workspaceId}, 'google_calendar', ${encryptIntegrationSecret(verifier)}, ${redirectUri}, now() + interval '10 minutes')`;
  const auth = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  auth.search = new URLSearchParams({ client_id: clientId, response_type: "code", redirect_uri: redirectUri, code_challenge_method: "S256", code_challenge: challenge, scope: "https://www.googleapis.com/auth/calendar.events", access_type: "offline", prompt: "consent", include_granted_scopes: "true", state }).toString();
  return { authorizeUrl: auth.toString(), redirectUri };
});

export const finishGoogleCalendarOAuth = createServerFn({ method: "POST" }).validator((v: unknown) => z.object({ state: z.string().min(32).max(128), code: z.string().min(1).max(2048) }).parse(v)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal(); requireWorkspaceAdmin(user); const db = getServerDatabase(); await ensureUser(db, user);
  const stateHash = createHash("sha256").update(data.state).digest("hex");
  const pending = await db.sql<{ encrypted_verifier: string; redirect_uri: string }>`delete from oauth_pending_states where state_hash = ${stateHash} and owner_id = ${user.workspaceId} and provider = 'google_calendar' and expires_at > now() returning encrypted_verifier, redirect_uri`;
  if (!pending[0]) throw new Error("Estado OAuth inválido ou expirado. Inicie a conexão novamente.");
  const rows = await db.sql<Row>`select provider, config, encrypted_secret, connected_at from provider_connections where owner_id = ${user.workspaceId} and provider = 'google_calendar' limit 1`;
  const row = rows[0]; const clientId = row?.config.clientId?.trim() || process.env.GOOGLE_OAUTH_CLIENT_ID?.trim() || ""; const clientSecret = row?.encrypted_secret ? decryptIntegrationSecret(row.encrypted_secret) : process.env.GOOGLE_OAUTH_CLIENT_SECRET?.trim() || "";
  if (!clientId || !clientSecret) throw new Error("Credenciais Google OAuth não encontradas no servidor.");
  const response = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" }, body: new URLSearchParams({ grant_type: "authorization_code", client_id: clientId, client_secret: clientSecret, code: data.code, redirect_uri: pending[0].redirect_uri, code_verifier: decryptIntegrationSecret(pending[0].encrypted_verifier) }), redirect: "error", signal: AbortSignal.timeout(15000) });
  if (!response.ok) { await response.body?.cancel(); throw new Error(`Google recusou a autorização (HTTP ${response.status}). Confira a URL de retorno OAuth cadastrada.`); }
  const token = await response.json() as { access_token?: string; refresh_token?: string; expires_in?: number; scope?: string };
  if (!token.access_token) throw new Error("A resposta OAuth do Google não trouxe access token.");
  const existing = await db.sql<{ encrypted_token: string | null }>`select encrypted_token from provider_connections where owner_id = ${user.workspaceId} and provider = 'google_calendar' limit 1`;
  const prior = existing[0]?.encrypted_token ? JSON.parse(decryptIntegrationSecret(existing[0].encrypted_token)) as { refreshToken?: string } : {};
  await db.sql`update provider_connections set encrypted_token = ${encryptIntegrationSecret(JSON.stringify({ accessToken: token.access_token, refreshToken: token.refresh_token ?? prior.refreshToken ?? "", expiresAt: Date.now() + (token.expires_in ?? 3600) * 1000, scopes: token.scope ?? "" }))}, connected_at = now(), updated_at = now() where owner_id = ${user.workspaceId} and provider = 'google_calendar'`;
  await db.sql`insert into audit_logs(actor_id, action, entity_type, metadata) values (${user.id}, 'google_calendar.oauth_connected', 'integration', '{}'::jsonb)`;
  return { connected: true };
});

export const createGoogleMeetEvent = createServerFn({ method: "POST" }).validator((v: unknown) => googleEventSchema.parse(v)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal(); const db = getServerDatabase();
  const rows = await db.sql<Row>`select provider, config, encrypted_secret, encrypted_token, connected_at from provider_connections where owner_id = ${user.workspaceId} and provider = 'google_calendar' limit 1`;
  const row = rows[0]; if (!row?.connected_at || !row.encrypted_token) throw new Error("Conecte o Google Calendar via OAuth antes de agendar.");
  const clientSecret = row.encrypted_secret ? decryptIntegrationSecret(row.encrypted_secret) : process.env.GOOGLE_OAUTH_CLIENT_SECRET?.trim() || "";
  if (!clientSecret) throw new Error("Client Secret OAuth do Google não está configurado.");
  let tokens = JSON.parse(decryptIntegrationSecret(row.encrypted_token)) as { accessToken: string; refreshToken: string; expiresAt: number };
  if (tokens.expiresAt < Date.now() + 30_000) {
    if (!tokens.refreshToken) throw new Error("A sessão Google expirou. Reconecte a conta para conceder acesso offline.");
    const refresh = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" }, body: new URLSearchParams({ grant_type: "refresh_token", client_id: row.config.clientId || process.env.GOOGLE_OAUTH_CLIENT_ID?.trim() || "", client_secret: clientSecret, refresh_token: tokens.refreshToken }), redirect: "error", signal: AbortSignal.timeout(15000) });
    if (!refresh.ok) { await refresh.body?.cancel(); throw new Error("Não foi possível renovar a sessão Google. Reconecte via OAuth."); }
    const next = await refresh.json() as { access_token?: string; expires_in?: number };
    if (!next.access_token) throw new Error("Resposta de renovação Google inválida.");
    tokens = { ...tokens, accessToken: next.access_token, expiresAt: Date.now() + (next.expires_in ?? 3600) * 1000 };
    await db.sql`update provider_connections set encrypted_token = ${encryptIntegrationSecret(JSON.stringify(tokens))}, updated_at = now() where owner_id = ${user.workspaceId} and provider = 'google_calendar'`;
  }
  const start = new Date(data.startTime); const end = new Date(data.endTime);
  if (start.getTime() <= Date.now()) throw new Error("Escolha uma data futura.");
  if (start.getTime() > Date.now() + 180 * 24 * 60 * 60 * 1000) throw new Error("Escolha uma data nos próximos 180 dias.");
  const event = { summary: data.summary, start: { dateTime: start.toISOString() }, end: { dateTime: end.toISOString() }, attendees: data.attendeeEmail ? [{ email: data.attendeeEmail }] : [], conferenceData: { createRequest: { requestId: randomBytes(18).toString("hex"), conferenceSolutionKey: { type: "hangoutsMeet" } } } };
  const response = await fetch("https://www.googleapis.com/calendar/v3/calendars/primary/events?conferenceDataVersion=1&sendUpdates=all", { method: "POST", headers: { Authorization: `Bearer ${tokens.accessToken}`, "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify(event), redirect: "error", signal: AbortSignal.timeout(15000) });
  if (!response.ok) { await response.body?.cancel(); throw new Error(`Google Calendar não criou o evento (HTTP ${response.status}). Confira o escopo Calendar e a API habilitada.`); }
  const created = await response.json() as { id?: string; htmlLink?: string; hangoutLink?: string; conferenceData?: { entryPoints?: { entryPointType?: string; uri?: string }[] } };
  const meetUrl = created.hangoutLink ?? created.conferenceData?.entryPoints?.find((entry) => entry.entryPointType === "video")?.uri ?? null;
  await db.sql`insert into audit_logs(actor_id, action, entity_type, metadata) values (${user.id}, 'google_calendar.meet_created', 'appointment', ${JSON.stringify({ eventId: created.id ?? "", hasMeetLink: Boolean(meetUrl) })}::jsonb)`;
  return { eventUrl: created.htmlLink ?? null, meetUrl };
});

export const listGoogleCalendarEvents = createServerFn({ method: "POST" }).validator((v: unknown) => calendarWindowSchema.parse(v)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal(); const db = getServerDatabase();
  const rows = await db.sql<Row>`select provider, config, encrypted_secret, encrypted_token, connected_at from provider_connections where owner_id = ${user.workspaceId} and provider = 'google_calendar' limit 1`;
  const row = rows[0]; if (!row?.connected_at || !row.encrypted_token) throw new Error("Conecte o Google Calendar via OAuth para carregar seus eventos.");
  let tokens = JSON.parse(decryptIntegrationSecret(row.encrypted_token)) as { accessToken: string; refreshToken: string; expiresAt: number };
  if (tokens.expiresAt < Date.now() + 30_000) {
    const clientId = row.config.clientId?.trim() || process.env.GOOGLE_OAUTH_CLIENT_ID?.trim() || "";
    const clientSecret = row.encrypted_secret ? decryptIntegrationSecret(row.encrypted_secret) : process.env.GOOGLE_OAUTH_CLIENT_SECRET?.trim() || "";
    if (!tokens.refreshToken || !clientId || !clientSecret) throw new Error("A sessão Google expirou. Reconecte a conta para renovar o acesso ao calendário.");
    const refresh = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" }, body: new URLSearchParams({ grant_type: "refresh_token", client_id: clientId, client_secret: clientSecret, refresh_token: tokens.refreshToken }), redirect: "error", signal: AbortSignal.timeout(15000) });
    if (!refresh.ok) { await refresh.body?.cancel(); throw new Error("Google não renovou a sessão do calendário. Reconecte a conta Google."); }
    const next = await refresh.json() as { access_token?: string; expires_in?: number };
    if (!next.access_token) throw new Error("Resposta de renovação Google inválida.");
    tokens = { ...tokens, accessToken: next.access_token, expiresAt: Date.now() + (next.expires_in ?? 3600) * 1000 };
    await db.sql`update provider_connections set encrypted_token = ${encryptIntegrationSecret(JSON.stringify(tokens))}, updated_at = now() where owner_id = ${user.workspaceId} and provider = 'google_calendar'`;
  }
  const url = new URL("https://www.googleapis.com/calendar/v3/calendars/primary/events");
  url.search = new URLSearchParams({ timeMin: data.timeMin, timeMax: data.timeMax, singleEvents: "true", orderBy: "startTime", maxResults: "250", timeZone: "America/Sao_Paulo" }).toString();
  const response = await fetch(url, { headers: { Authorization: `Bearer ${tokens.accessToken}`, Accept: "application/json" }, redirect: "error", signal: AbortSignal.timeout(15000) });
  if (!response.ok) { await response.body?.cancel(); throw new Error(`Google Calendar não carregou os eventos (HTTP ${response.status}). Reconecte a conta se a autorização tiver expirado.`); }
  const result = await response.json() as { items?: { id?: string; summary?: string; status?: string; start?: { dateTime?: string; date?: string }; end?: { dateTime?: string; date?: string }; htmlLink?: string; hangoutLink?: string; conferenceData?: { entryPoints?: { entryPointType?: string; uri?: string }[] } }[] };
  return (result.items ?? []).filter((event) => event.status !== "cancelled").map((event) => ({ id: event.id ?? "", summary: event.summary ?? "Sem título", start: event.start?.dateTime ?? event.start?.date ?? "", end: event.end?.dateTime ?? event.end?.date ?? "", eventUrl: event.htmlLink ?? null, meetUrl: event.hangoutLink ?? event.conferenceData?.entryPoints?.find((entry) => entry.entryPointType === "video")?.uri ?? null }));
});

export const beginCalendlyOAuth = createServerFn({ method: "POST" }).validator((v: unknown) => stateSchema.parse(v)).handler(async ({ data }) => {
  void data;
  const user = await requireAuthenticatedPrincipal(); requireWorkspaceAdmin(user); const db = getServerDatabase(); await ensureUser(db, user);
  const rows = await db.sql<Row>`select provider, config, encrypted_secret, connected_at from provider_connections where owner_id = ${user.workspaceId} and provider = 'calendly' limit 1`;
  const row = rows[0]; if (!row?.encrypted_secret) throw new Error("Salve primeiro o Client ID e o Client Secret do Calendly.");
  const clientId = row.config.clientId?.trim(); if (!clientId) throw new Error("Informe o Client ID OAuth do Calendly.");
  const base = getRequestUrl();
  const configuredOrigins = [process.env.URL, process.env.DEPLOY_PRIME_URL].filter((value): value is string => Boolean(value)).map((value) => new URL(value).origin);
  if (configuredOrigins.length && !configuredOrigins.includes(base.origin)) throw new Error("A URL atual não corresponde ao domínio OAuth configurado no Netlify.");
  if (base.protocol !== "https:" && base.hostname !== "localhost" && base.hostname !== "127.0.0.1") throw new Error("O retorno OAuth exige HTTPS.");
  const redirectUri = new URL("/integrations", base).toString();
  const state = randomBytes(32).toString("base64url"); const verifier = randomBytes(32).toString("base64url");
  const challenge = createHash("sha256").update(verifier).digest("base64url");
  await db.sql`delete from oauth_pending_states where expires_at < now()`;
  await db.sql`insert into oauth_pending_states(state_hash, owner_id, provider, encrypted_verifier, redirect_uri, expires_at) values (${createHash("sha256").update(state).digest("hex")}, ${user.workspaceId}, 'calendly', ${encryptIntegrationSecret(verifier)}, ${redirectUri}, now() + interval '10 minutes')`;
  const auth = new URL("https://auth.calendly.com/oauth/authorize");
  const scopes = new Set((row.config.scopes || "users:read scheduled_events:read scheduled_events:write event_types:read availability:read").split(/\s+/).filter(Boolean));
  scopes.add("users:read"); scopes.add("scheduled_events:read");
  auth.search = new URLSearchParams({ client_id: clientId, response_type: "code", redirect_uri: redirectUri, code_challenge_method: "S256", code_challenge: challenge, scope: [...scopes].join(" "), state }).toString();
  return { authorizeUrl: auth.toString(), redirectUri };
});

export const finishCalendlyOAuth = createServerFn({ method: "POST" }).validator((v: unknown) => z.object({ state: z.string().min(32).max(128), code: z.string().min(1).max(2048) }).parse(v)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal(); requireWorkspaceAdmin(user); const db = getServerDatabase(); await ensureUser(db, user);
  const stateHash = createHash("sha256").update(data.state).digest("hex");
  const pending = await db.sql<{ encrypted_verifier: string; redirect_uri: string }>`delete from oauth_pending_states where state_hash = ${stateHash} and owner_id = ${user.workspaceId} and provider = 'calendly' and expires_at > now() returning encrypted_verifier, redirect_uri`;
  if (!pending[0]) throw new Error("Estado OAuth inválido ou expirado. Inicie a conexão novamente.");
  const rows = await db.sql<Row>`select provider, config, encrypted_secret, connected_at from provider_connections where owner_id = ${user.workspaceId} and provider = 'calendly' limit 1`;
  const row = rows[0]; if (!row?.encrypted_secret) throw new Error("Credenciais Calendly não encontradas.");
  const clientSecret = decryptIntegrationSecret(row.encrypted_secret); const clientId = row.config.clientId;
  const body = new URLSearchParams({ grant_type: "authorization_code", client_id: clientId, code: data.code, redirect_uri: pending[0].redirect_uri, code_verifier: decryptIntegrationSecret(pending[0].encrypted_verifier) });
  const response = await fetch("https://auth.calendly.com/oauth/token", { method: "POST", headers: { Authorization: `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString("base64")}`, "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" }, body, redirect: "error", signal: AbortSignal.timeout(15000) });
  if (!response.ok) { await response.body?.cancel(); throw new Error(`Calendly recusou a autorização (HTTP ${response.status}). Confira a URL de retorno cadastrada no app OAuth.`); }
  const token = await response.json() as { access_token?: string; refresh_token?: string; expires_in?: number; scope?: string };
  if (!token.access_token) throw new Error("A resposta OAuth do Calendly não trouxe access token.");
  await db.sql`update provider_connections set encrypted_token = ${encryptIntegrationSecret(JSON.stringify({ accessToken: token.access_token, refreshToken: token.refresh_token ?? "", expiresAt: Date.now() + (token.expires_in ?? 7200) * 1000, scopes: token.scope ?? "" }))}, connected_at = now(), updated_at = now() where owner_id = ${user.workspaceId} and provider = 'calendly'`;
  await db.sql`insert into audit_logs(actor_id, action, entity_type, metadata) values (${user.id}, 'calendly.oauth_connected', 'integration', '{}'::jsonb)`;
  return { connected: true };
});

export const listCalendlyEvents = createServerFn({ method: "POST" }).validator((v: unknown) => calendarWindowSchema.parse(v)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal(); const db = getServerDatabase();
  const rows = await db.sql<Row>`select provider, config, encrypted_secret, encrypted_token, connected_at from provider_connections where owner_id = ${user.workspaceId} and provider = 'calendly' limit 1`;
  const row = rows[0]; if (!row?.connected_at || !row.encrypted_token) throw new Error("Conecte o Calendly via OAuth para ver os agendamentos.");
  let tokens = JSON.parse(decryptIntegrationSecret(row.encrypted_token)) as { accessToken: string; refreshToken: string; expiresAt: number };
  if (tokens.expiresAt < Date.now() + 30_000) {
    if (!tokens.refreshToken || !row.encrypted_secret) throw new Error("A sessão Calendly expirou. Reconecte a conta.");
    const response = await fetch("https://auth.calendly.com/oauth/token", { method: "POST", headers: { Authorization: `Basic ${Buffer.from(`${row.config.clientId}:${decryptIntegrationSecret(row.encrypted_secret)}`).toString("base64")}`, "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" }, body: new URLSearchParams({ grant_type: "refresh_token", refresh_token: tokens.refreshToken }), redirect: "error", signal: AbortSignal.timeout(15000) });
    if (!response.ok) { await response.body?.cancel(); throw new Error("Não foi possível renovar a sessão Calendly. Reconecte via OAuth."); }
    const next = await response.json() as { access_token?: string; refresh_token?: string; expires_in?: number };
    if (!next.access_token) throw new Error("Resposta de renovação Calendly inválida.");
    tokens = { accessToken: next.access_token, refreshToken: next.refresh_token ?? tokens.refreshToken, expiresAt: Date.now() + (next.expires_in ?? 7200) * 1000 };
    await db.sql`update provider_connections set encrypted_token = ${encryptIntegrationSecret(JSON.stringify(tokens))}, updated_at = now() where owner_id = ${user.workspaceId} and provider = 'calendly'`;
  }
  const meResponse = await fetch("https://api.calendly.com/users/me", { headers: { Authorization: `Bearer ${tokens.accessToken}`, Accept: "application/json" }, redirect: "error", signal: AbortSignal.timeout(12000) });
  if (!meResponse.ok) throw new Error(`Calendly não identificou a conta autorizada (HTTP ${meResponse.status}): ${await providerErrorDetail(meResponse)}${meResponse.status === 403 ? " Reconecte o Calendly com o escopo users:read." : ""}`);
  const me = await meResponse.json() as { resource?: { uri?: string } };
  if (!me.resource?.uri) throw new Error("Calendly não retornou a URI da conta autorizada.");
  const url = new URL("https://api.calendly.com/scheduled_events");
  url.search = new URLSearchParams({ user: me.resource.uri, min_start_time: data.timeMin, max_start_time: data.timeMax, status: "active", sort: "start_time:asc", count: "100" }).toString();
  const response = await fetch(url, { headers: { Authorization: `Bearer ${tokens.accessToken}`, Accept: "application/json" }, redirect: "error", signal: AbortSignal.timeout(15000) });
  if (!response.ok) throw new Error(`Calendly não carregou os eventos (HTTP ${response.status}): ${await providerErrorDetail(response)}${response.status === 403 ? " Reconecte o Calendly com o escopo scheduled_events:read." : ""}`);
  const result = await response.json() as { collection?: { uri?: string; name?: string; start_time?: string; end_time?: string; location?: { join_url?: string; location?: string } }[] };
  return (result.collection ?? []).map((event) => ({ id: event.uri ?? "", summary: event.name ?? "Evento Calendly", start: event.start_time ?? "", end: event.end_time ?? "", eventUrl: null, meetUrl: event.location?.join_url ?? null }));
});

async function providerErrorDetail(response: Response): Promise<string> {
  const raw = await response.text().catch(() => "");
  if (!raw) return "sem detalhes retornados pelo provedor.";
  let detail = raw;
  try {
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    const errors = parsed.errors;
    const firstError = Array.isArray(errors) ? errors[0] : null;
    const item = firstError && typeof firstError === "object" ? firstError as Record<string, unknown> : {};
    detail = String(parsed.message ?? parsed.error_description ?? parsed.error ?? item.message ?? item.title ?? raw);
  } catch { /* Algumas respostas de erro são texto puro. */ }
  return detail.replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").slice(0, 220) || "sem detalhes retornados pelo provedor.";
}

export const createCalendlyInvitee = createServerFn({ method: "POST" }).validator((v: unknown) => bookingSchema.parse(v)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal(); const db = getServerDatabase();
  const rows = await db.sql<Row>`select provider, config, encrypted_secret, connected_at from provider_connections where owner_id = ${user.workspaceId} and provider = 'calendly' limit 1`;
  const row = rows[0]; if (!row?.connected_at || !row.encrypted_token) throw new Error("Conecte o Calendly via OAuth antes de agendar.");
  const eventType = new URL(data.eventTypeUri);
  if (eventType.protocol !== "https:" || eventType.hostname !== "api.calendly.com" || !/^\/event_types\/[A-Za-z0-9_-]+$/.test(eventType.pathname) || eventType.search || eventType.hash) throw new Error("Use a URI canônica de um tipo de evento Calendly (api.calendly.com/event_types/…).");
  let secrets = JSON.parse(decryptIntegrationSecret(row.encrypted_token)) as { accessToken: string; refreshToken: string; expiresAt: number };
  if (secrets.expiresAt < Date.now() + 30_000) {
    if (!secrets.refreshToken) throw new Error("A sessão do Calendly expirou. Reconecte sua conta antes de agendar.");
    const refresh = await fetch("https://auth.calendly.com/oauth/token", { method: "POST", headers: { Authorization: `Basic ${Buffer.from(`${row.config.clientId}:${decryptIntegrationSecret(row.encrypted_secret!)}`).toString("base64")}`, "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" }, body: new URLSearchParams({ grant_type: "refresh_token", refresh_token: secrets.refreshToken }), redirect: "error", signal: AbortSignal.timeout(15000) });
    if (!refresh.ok) { await refresh.body?.cancel(); throw new Error("Não foi possível renovar a sessão Calendly. Reconecte via OAuth."); }
    const next = await refresh.json() as { access_token?: string; refresh_token?: string; expires_in?: number };
    if (!next.access_token) throw new Error("Resposta de renovação do Calendly inválida.");
    secrets = { accessToken: next.access_token, refreshToken: next.refresh_token ?? secrets.refreshToken, expiresAt: Date.now() + (next.expires_in ?? 7200) * 1000 };
    await db.sql`update provider_connections set encrypted_token = ${encryptIntegrationSecret(JSON.stringify(secrets))}, updated_at = now() where owner_id = ${user.workspaceId} and provider = 'calendly'`;
  }
  const requestedTime = new Date(data.startTime);
  if (requestedTime.getTime() <= Date.now()) throw new Error("Escolha uma data futura.");
  if (requestedTime.getTime() > Date.now() + 31 * 24 * 60 * 60 * 1000) throw new Error("Escolha uma data dentro dos próximos 31 dias.");
  const availabilityUrl = new URL("https://api.calendly.com/event_type_available_times");
  availabilityUrl.search = new URLSearchParams({ event_type: data.eventTypeUri, start_time: new Date(requestedTime.getTime() - 60_000).toISOString(), end_time: new Date(requestedTime.getTime() + 60_000).toISOString() }).toString();
  const availability = await fetch(availabilityUrl, { headers: { Authorization: `Bearer ${secrets.accessToken}`, Accept: "application/json" }, redirect: "error", signal: AbortSignal.timeout(15000) });
  if (!availability.ok) { await availability.body?.cancel(); throw new Error(`Calendly não validou a disponibilidade (HTTP ${availability.status}). Confira escopo availability:read e o tipo do evento.`); }
  const times = await availability.json() as { collection?: { status?: string; start_time?: string }[] };
  const hasSlot = times.collection?.some((slot) => slot.status === "available" && slot.start_time && new Date(slot.start_time).getTime() === requestedTime.getTime());
  if (!hasSlot) throw new Error("Esse horário não aparece disponível no Calendly. Escolha um horário livre e tente novamente.");
  const body = { event_type: data.eventTypeUri, start_time: requestedTime.toISOString(), invitee: { name: data.name, email: data.email, timezone: data.timezone } };
  const response = await fetch("https://api.calendly.com/invitees", { method: "POST", headers: { Authorization: `Bearer ${secrets.accessToken}`, "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify(body), redirect: "error", signal: AbortSignal.timeout(15000) });
  if (!response.ok) { await response.body?.cancel(); throw new Error(`Calendly não criou o agendamento (HTTP ${response.status}). Confirme plano, permissões, tipo de evento e horário disponível.`); }
  const result = await response.json() as { resource?: { uri?: string; event?: string; cancel_url?: string; reschedule_url?: string } };
  await db.sql`insert into audit_logs(actor_id, action, entity_type, metadata) values (${user.id}, 'calendly.invitee_created', 'appointment', ${JSON.stringify({ eventUri: result.resource?.event ?? "" })}::jsonb)`;
  return { eventUri: result.resource?.event ?? null, inviteeUri: result.resource?.uri ?? null, cancelUrl: result.resource?.cancel_url ?? null, rescheduleUrl: result.resource?.reschedule_url ?? null };
});

export const searchWeb = createServerFn({ method: "POST" }).validator((v: unknown) => searchSchema.parse(v)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal(); requireWorkspaceAdmin(user); const db = getServerDatabase();
  const rows = await db.sql<Row>`select provider, config, encrypted_secret, connected_at from provider_connections where owner_id = ${user.workspaceId} and provider = 'serpapi' limit 1`;
  const key = process.env.SERPAPI_API_KEY?.trim() || (rows[0]?.encrypted_secret ? decryptIntegrationSecret(rows[0].encrypted_secret) : "");
  if (!key) throw new Error("Configure SERPAPI_API_KEY nas variáveis secretas do servidor ou salve a chave em Integrações.");
  const url = new URL("https://serpapi.com/search"); url.search = new URLSearchParams({ engine: "google", q: data.query, api_key: key, gl: "br", hl: "pt" }).toString();
  const response = await fetch(url, { headers: { Accept: "application/json" }, redirect: "error", signal: AbortSignal.timeout(15000) });
  if (!response.ok) { await response.body?.cancel(); throw new Error(`A pesquisa retornou HTTP ${response.status}.`); }
  const body = await response.json() as { error?: string; organic_results?: { title?: string; link?: string; snippet?: string }[] };
  if (body.error) throw new Error("O provedor de pesquisa recusou a consulta. Confira a credencial e o plano.");
  await db.sql`insert into audit_logs(actor_id, action, entity_type, metadata) values (${user.id}, 'prospecting.web_search', 'search', jsonb_build_object('resultCount', ${(body.organic_results?.length ?? 0)}::integer))`;
  return (body.organic_results ?? []).slice(0, 10).map(({ title, link, snippet }) => ({ title: title ?? "Resultado sem título", url: link ?? "", description: snippet ?? "" }));
});

export const lookupPublicCnpj = createServerFn({ method: "POST" }).validator((v: unknown) => cnpjSchema.parse(v)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal(); const db = getServerDatabase();
  const response = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${encodeURIComponent(data.cnpj)}`, { headers: { Accept: "application/json" }, redirect: "error", signal: AbortSignal.timeout(8000) });
  if (!response.ok) { await response.body?.cancel(); throw new Error(response.status === 404 ? "CNPJ não encontrado na fonte pública." : `Fonte pública de CNPJ indisponível (HTTP ${response.status}).`); }
  const result = publicCompanyFields(await response.json());
  const auditMetadata = JSON.stringify({ source: "brasilapi_minha_receita" });
  await db.sql`insert into audit_logs(actor_id, action, entity_type, metadata) values (${user.id}, 'prospecting.cnpj_lookup', 'company', ${auditMetadata}::jsonb)`;
  return { source: "BrasilAPI / Minha Receita (dados públicos; fonte de terceiros)", retrievedAt: new Date().toISOString(), company: result };
});

export const testWhatsAppCloudConnection = createServerFn({ method: "POST" }).validator((v: unknown) => z.object({}).parse(v)).handler(async () => {
  const user = await requireAuthenticatedPrincipal(); requireWorkspaceAdmin(user); const db = getServerDatabase();
  const rows = await db.sql<Row>`select provider, config, encrypted_secret, connected_at from provider_connections where owner_id = ${user.workspaceId} and provider = 'whatsapp_cloud' limit 1`;
  const row = rows[0]; const phoneId = row?.config.phoneNumberId; const version = row?.config.apiVersion;
  if (!phoneId || !/^v\d+\.\d+$/.test(version ?? "") || !row?.encrypted_secret) throw new Error("Configure Phone Number ID, versão da Graph API e token antes de testar.");
  const url = new URL(`https://graph.facebook.com/${version}/${encodeURIComponent(phoneId)}`); url.searchParams.set("fields", "display_phone_number,verified_name");
  const response = await fetch(url, { headers: { Authorization: `Bearer ${decryptIntegrationSecret(row.encrypted_secret)}`, Accept: "application/json" }, redirect: "error", signal: AbortSignal.timeout(12000) });
  if (!response.ok) { await response.body?.cancel(); throw new Error(`Meta Graph API retornou HTTP ${response.status}. Nenhuma mensagem foi enviada.`); }
  const data = await response.json() as { display_phone_number?: string; verified_name?: string };
  await db.sql`insert into audit_logs(actor_id, action, entity_type, metadata) values (${user.id}, 'whatsapp.connection_tested', 'integration', '{}'::jsonb)`;
  return { displayPhoneNumber: data.display_phone_number ?? "", verifiedName: data.verified_name ?? "" };
});

async function ensureUser(db: ReturnType<typeof getServerDatabase>, user: { id: string; email: string | null }) { await db.sql`insert into app_users(id,email) values (${user.id},${user.email}) on conflict(id) do update set email=excluded.email, updated_at=now()`; }
function iso(v: string | Date) { return v instanceof Date ? v.toISOString() : new Date(v).toISOString(); }
