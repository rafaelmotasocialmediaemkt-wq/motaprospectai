import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { enqueueYCloudText, isE164, listYCloudPhoneNumbers } from "../ycloud/client";
import { getServerDatabase } from "./database.server";
import { requireAuthenticatedPrincipal, requireWorkspaceAdmin } from "./server-auth";
import { getYCloudConfiguration } from "./ycloud-configuration.server";

const empty = z.object({});
const enabledInput = z.object({ enabled: z.boolean() });
const sendInput = z.object({ conversationId: z.uuid(), body: z.string().trim().min(1).max(4000), idempotencyKey: z.uuid() });

export const getYCloudMessagingStatus = createServerFn({ method: "POST" }).validator((data: unknown) => empty.parse(data)).handler(async () => {
  const user = await requireAuthenticatedPrincipal();
  const db = getServerDatabase();
  const rows = await db.sql<{ ycloud_messaging_enabled: boolean; ycloud_last_test_status: string | null }>`select ycloud_messaging_enabled, ycloud_last_test_status from user_operating_settings where owner_id = ${user.workspaceId} limit 1`;
  const configuration = await getYCloudConfiguration(db, user.workspaceId);
  const missingConfig = configuration.missing;
  const apiConfigured = missingConfig.length === 0;
  return { enabled: Boolean(rows[0]?.ycloud_messaging_enabled), configured: apiConfigured, missingConfig, workspaceId: user.isAdmin && user.id === user.workspaceId ? user.workspaceId : null, tested: rows[0]?.ycloud_last_test_status === "connected", testStatus: rows[0]?.ycloud_last_test_status ?? null, senderPhone: apiConfigured ? configuration.phoneNumber : null, isAdmin: user.isAdmin && user.id === user.workspaceId, mode: "assisted" as const };
});

export const testYCloudConnection = createServerFn({ method: "POST" }).validator((data: unknown) => empty.parse(data)).handler(async () => {
  const user = await requireAuthenticatedPrincipal();
  requireWorkspaceAdmin(user);
  const db = getServerDatabase();
  const configuration = await getYCloudConfiguration(db, user.workspaceId);
  const missing = configuration.missing;
  if (missing.length) throw new Error(`Configuração YCloud incompleta no servidor ou no painel Integrações: ${missing.join(", ")}.`);
  const apiKey = configuration.apiKey;
  const senderPhone = configuration.phoneNumber;
  const previous = await db.sql<{ ycloud_last_test_at: string | Date | null }>`select ycloud_last_test_at from user_operating_settings where owner_id = ${user.workspaceId} limit 1`;
  if (previous[0]?.ycloud_last_test_at && Date.now() - new Date(previous[0].ycloud_last_test_at).getTime() < 15_000) throw new Error("Aguarde 15 segundos antes de testar novamente.");
  let status: "connected" | "number_not_ready" | "number_not_found" | "error" = "error";
  let httpStatus: number | null = null;
  try {
    const phoneNumbers = await listYCloudPhoneNumbers(apiKey);
    const sender = phoneNumbers.find((item) => item.phoneNumber === senderPhone);
    status = !sender ? "number_not_found" : sender.status === "CONNECTED" ? "connected" : "number_not_ready";
    httpStatus = 200;
  } catch (cause) {
    httpStatus = cause && typeof cause === "object" && "httpStatus" in cause ? Number((cause as { httpStatus: unknown }).httpStatus) : null;
  }
  await db.sql`insert into user_operating_settings(owner_id, ycloud_last_test_at, ycloud_last_test_status) values (${user.workspaceId}, now(), ${status}) on conflict(owner_id) do update set ycloud_last_test_at = now(), ycloud_last_test_status = excluded.ycloud_last_test_status, updated_at = now()`;
  await db.sql`insert into audit_logs(actor_id, action, entity_type, metadata) values (${user.id}, 'ycloud.connection_tested', 'integration', jsonb_build_object('result', ${status}::text, 'httpStatus', ${httpStatus}::integer))`;
  return { status, httpStatus, checkedAt: new Date().toISOString() };
});

export const setYCloudMessagingEnabled = createServerFn({ method: "POST" }).validator((data: unknown) => enabledInput.parse(data)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal();
  requireWorkspaceAdmin(user);
  if (data.enabled) {
    const configuration = await getYCloudConfiguration(getServerDatabase(), user.workspaceId);
    if (configuration.missing.length) throw new Error(`Configuração YCloud incompleta: ${configuration.missing.join(", ")}.`);
  }
  const db = getServerDatabase();
  if (data.enabled) {
    const rows = await db.sql<{ ycloud_last_test_status: string | null }>`select ycloud_last_test_status from user_operating_settings where owner_id = ${user.workspaceId} limit 1`;
    if (rows[0]?.ycloud_last_test_status !== "connected") throw new Error("Execute primeiro o teste de leitura e confirme o status CONNECTED do telefone YCloud.");
  }
  await db.sql`insert into user_operating_settings(owner_id, ycloud_messaging_enabled) values (${user.workspaceId}, ${data.enabled}) on conflict(owner_id) do update set ycloud_messaging_enabled = excluded.ycloud_messaging_enabled, updated_at = now()`;
  await db.sql`insert into audit_logs(actor_id, action, entity_type, metadata) values (${user.id}, ${data.enabled ? "ycloud.messaging_enabled" : "ycloud.messaging_disabled"}, 'integration', jsonb_build_object('mode', 'assisted'))`;
  return { enabled: data.enabled };
});

/** Human-approved single send. Free-form text is limited to an inbound 24-hour service window. */
export const sendYCloudTextMessage = createServerFn({ method: "POST" }).validator((data: unknown) => sendInput.parse(data)).handler(async ({ data }) => {
  const user = await requireAuthenticatedPrincipal();
  const db = getServerDatabase();
  const configuration = await getYCloudConfiguration(db, user.workspaceId);
  const config = { apiKey: configuration.apiKey, senderPhone: configuration.phoneNumber };
  const missing = configuration.missing;
  if (missing.length) throw new Error(`Configuração YCloud incompleta no servidor ou no painel Integrações: ${missing.join(", ")}.`);

  const settings = await db.sql<{ ycloud_messaging_enabled: boolean; ycloud_last_test_status: string | null }>`select ycloud_messaging_enabled, ycloud_last_test_status from user_operating_settings where owner_id = ${user.workspaceId} limit 1`;
  if (!settings[0]?.ycloud_messaging_enabled) throw new Error("Envio real está desabilitado pelo administrador.");
  if (settings[0].ycloud_last_test_status !== "connected") throw new Error("A validação de conexão YCloud está pendente ou falhou; desative o envio até validar novamente.");

  const conversations = await db.sql<{ lead_id: string; phone: string | null; opted_out_at: string | Date | null; status: string; last_inbound_at: string | Date | null; mode: string }>`
    select c.lead_id, l.phone, l.opted_out_at, c.status, c.last_inbound_at, c.automation_mode as mode
    from conversations c join leads l on l.id = c.lead_id and l.owner_id = c.owner_id
    where c.id = ${data.conversationId} and c.owner_id = ${user.workspaceId} limit 1
  `;
  const conversation = conversations[0];
  if (!conversation) throw new Error("Conversa não encontrada neste workspace.");
  if (conversation.status === "closed" || conversation.mode === "human" && !conversation.last_inbound_at) throw new Error("A conversa está encerrada ou em atendimento humano sem janela ativa.");
  if (conversation.opted_out_at) throw new Error("Contato com opt-out ativo. Envio bloqueado.");
  if (!conversation.last_inbound_at || Date.now() - new Date(conversation.last_inbound_at).getTime() > 24 * 60 * 60 * 1000) {
    throw new Error("Texto livre só pode ser enviado dentro de 24 horas da última mensagem real recebida. Mensagens iniciais exigem template aprovado, ainda não configurado.");
  }
  if (!conversation.phone) throw new Error("Lead sem telefone comercial.");
  const digits = conversation.phone.replace(/\D/g, "");
  const to = digits.startsWith("55") ? `+${digits}` : digits.length === 10 || digits.length === 11 ? `+55${digits}` : `+${digits}`;
  if (!isE164(to)) throw new Error("Telefone do lead não está em formato internacional válido.");

  const pending = await db.sql<{ id: string }>`select id from conversation_messages where owner_id = ${user.workspaceId} and conversation_id = ${data.conversationId} and direction = 'outbound' and delivery_status in ('queued','unknown') limit 1`;
  if (pending[0]) throw new Error("Há um envio pendente ou incerto nesta conversa. Verifique o painel YCloud antes de tentar novamente.");

  const externalId = `mota-${data.idempotencyKey}`;
  const inserted = await db.sql<{ id: string }>`
    insert into conversation_messages(owner_id, conversation_id, direction, author_kind, body, delivery_status, is_simulated, idempotency_key, correlation_id, created_by)
    values (${user.workspaceId}, ${data.conversationId}, 'outbound', 'seller', ${data.body}, 'queued', false, ${data.idempotencyKey}, ${externalId}, ${user.id})
    on conflict(owner_id, idempotency_key) do nothing returning id
  `;
  if (!inserted[0]) throw new Error("Esta solicitação de envio já foi processada. Atualize a conversa para conferir o estado.");
  await db.sql`update conversations set ai_paused = true, automation_mode = 'human', assigned_to = coalesce(assigned_to, ${user.id}), updated_at = now() where id = ${data.conversationId} and owner_id = ${user.workspaceId}`;
  await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${user.id}, 'ycloud.message_send_requested', 'conversation', ${data.conversationId}, jsonb_build_object('messageId', ${inserted[0].id}::text, 'correlationId', ${externalId}))`;

  try {
    const accepted = await enqueueYCloudText(config, { to, body: data.body, externalId });
    const status = accepted.status ?? "accepted";
    await db.sql`update conversation_messages set external_message_id = ${accepted.id}, delivery_status = ${status}, failure_reason = null where id = ${inserted[0].id} and owner_id = ${user.workspaceId}`;
    await db.sql`update conversations set last_message_at = now(), updated_at = now() where id = ${data.conversationId} and owner_id = ${user.workspaceId}`;
    await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${user.id}, 'ycloud.message_accepted', 'conversation', ${data.conversationId}, jsonb_build_object('providerMessageId', ${accepted.id}, 'status', ${status}))`;
    return { accepted: status !== "failed", status, messageId: accepted.id };
  } catch (cause) {
    const httpStatus = cause && typeof cause === "object" && "httpStatus" in cause ? Number((cause as { httpStatus: unknown }).httpStatus) : null;
    const uncertain = httpStatus === null || httpStatus >= 500 || (cause instanceof Error && cause.message.includes("reconciliação"));
    const status = uncertain ? "unknown" : "failed";
    await db.sql`update conversation_messages set delivery_status = ${status}, failure_reason = ${uncertain ? "Resultado incerto; verificação manual necessária." : `HTTP ${httpStatus}`} where id = ${inserted[0].id} and owner_id = ${user.workspaceId}`;
    await db.sql`insert into audit_logs(actor_id, action, entity_type, entity_id, metadata) values (${user.id}, ${uncertain ? "ycloud.message_send_uncertain" : "ycloud.message_send_failed"}, 'conversation', ${data.conversationId}, jsonb_build_object('messageId', ${inserted[0].id}::text, 'httpStatus', ${httpStatus}))`;
    if (uncertain) throw new Error("Resultado incerto. A mensagem não será reenviada automaticamente; confira o painel YCloud antes de qualquer nova tentativa.");
    throw new Error(`YCloud recusou a mensagem (HTTP ${httpStatus}). Nenhuma repetição automática foi feita.`);
  }
});


