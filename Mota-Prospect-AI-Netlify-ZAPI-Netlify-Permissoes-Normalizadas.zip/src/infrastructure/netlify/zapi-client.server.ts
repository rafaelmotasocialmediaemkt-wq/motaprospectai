import { decryptIntegrationSecret } from "./integration-secrets.server";
import { getServerDatabase } from "./database.server";

export type ZapiCredentials = { instanceId: string; instanceToken: string; clientToken: string; webhookKey: string };

export async function getZapiCredentials(workspaceId: string): Promise<ZapiCredentials> {
  const rows = await getServerDatabase().sql<{ config: Record<string, string>; encrypted_secret: string | null }>`select config, encrypted_secret from provider_connections where owner_id = ${workspaceId} and provider = 'whatsapp_zapi' limit 1`;
  let secret: { instanceToken?: string; clientToken?: string; webhookKey?: string } = {};
  if (rows[0]?.encrypted_secret) { try { secret = JSON.parse(decryptIntegrationSecret(rows[0].encrypted_secret)) as typeof secret; } catch { throw new Error("Credenciais Z-API salvas não puderam ser lidas. Salve-as novamente no painel de Integrações."); } }
  const instanceId = rows[0]?.config.instanceId?.trim() || process.env.ZAPI_INSTANCE_ID?.trim() || "";
  const instanceToken = secret.instanceToken?.trim() || process.env.ZAPI_INSTANCE_TOKEN?.trim() || "";
  const clientToken = secret.clientToken?.trim() || process.env.ZAPI_CLIENT_TOKEN?.trim() || "";
  const missing = [!instanceId && "ID da instância", !instanceToken && "token da instância"].filter(Boolean);
  if (missing.length) throw new Error(`Configuração Z-API incompleta: ${missing.join(", ")}.`);
  return { instanceId, instanceToken, clientToken, webhookKey: secret.webhookKey ?? "" };
}

export function zapiApiUrl(credentials: ZapiCredentials, action: string) {
  return `https://api.z-api.io/instances/${encodeURIComponent(credentials.instanceId)}/token/${encodeURIComponent(credentials.instanceToken)}/${action}`;
}

export async function sendZapiText(credentials: ZapiCredentials, phone: string, message: string) {
  const headers = new Headers({ "Content-Type": "application/json", Accept: "application/json" });
  if (credentials.clientToken) headers.set("Client-Token", credentials.clientToken);
  const response = await fetch(zapiApiUrl(credentials, "send-text"), { method: "POST", headers, body: JSON.stringify({ phone: phone.replace(/\D/g, ""), message }), redirect: "error", signal: AbortSignal.timeout(15000) });
  if (!response.ok) { await response.body?.cancel(); const error = new Error(`Z-API recusou a mensagem (HTTP ${response.status}).`); Object.assign(error, { httpStatus: response.status }); throw error; }
  return await response.json() as { zaapId?: string; messageId?: string; id?: string; zapiMessageId?: string };
}
