import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createLeadSchema } from "../../application/leads/lead-service";
import { LEAD_REVIEW_STATUSES, LEAD_STAGES, canMoveLead, type Lead, type LeadReviewStatus, type LeadStage } from "../../domain/leads/lead";
import { requireAuthenticatedPrincipal } from "./server-auth";
import { getServerDatabase } from "./database.server";

const emptyRequest = z.object({});
const createRequest = z.object({ input: createLeadSchema });
const updateRequest = z.object({ id: z.uuid(), input: createLeadSchema });
const moveRequest = z.object({ id: z.uuid(), stage: z.enum(LEAD_STAGES) });
const suppressRequest = z.object({ id: z.uuid() });
const reviewRequest = z.object({ id: z.uuid(), status: z.enum(LEAD_REVIEW_STATUSES), duplicateOf: z.union([z.uuid(), z.literal("")]).optional().transform((value) => value || undefined) });

type LeadRow = {
  id: string; owner_id: string; company_name: string; contact_name: string | null; email: string | null; phone: string | null;
  segment: string | null; city: string | null; state: string | null; source: string; stage: string; qualification_score: number | null;
  notes: string | null; created_at: string | Date; updated_at: string | Date;
  opted_out_at: string | Date | null;
  review_status: string; reviewed_at: string | Date | null; duplicate_of: string | null;
};

export const listNetlifyLeads = createServerFn({ method: "POST" })
  .validator((data: unknown) => emptyRequest.parse(data))
  .handler(async ({ data }) => {
    void data;
    const principal = await requireAuthenticatedPrincipal();
    const db = getServerDatabase();
    await ensureUser(db, principal);
    const rows = await db.sql<LeadRow>`
      select id, owner_id, company_name, contact_name, email, phone, segment, city, state, source, stage,
             qualification_score, notes, opted_out_at, review_status, reviewed_at, duplicate_of, created_at, updated_at
      from leads where owner_id = ${principal.workspaceId}
      order by created_at desc, id desc limit 500
    `;
    return rows.map(toLead);
  });

export const createNetlifyLead = createServerFn({ method: "POST" })
  .validator((data: unknown) => createRequest.parse(data))
  .handler(async ({ data }) => {
    const principal = await requireAuthenticatedPrincipal();
    const db = getServerDatabase();
    await ensureUser(db, principal);
    const input = normalizeInput(data.input);
    try {
      const rows = await db.sql<LeadRow>`
        with created as (
          insert into leads (owner_id, company_name, contact_name, email, phone, segment, city, state, notes, source)
          values (${principal.workspaceId}, ${input.companyName}, ${input.contactName}, ${input.email}, ${input.phone}, ${input.segment}, ${input.city}, ${input.state}, ${input.notes}, 'manual')
          returning *
        ), logged as (
          insert into audit_logs(actor_id, action, entity_type, entity_id)
          select ${principal.id}, 'lead.created', 'lead', id from created returning id
        )
        select * from created
      `;
      if (!rows[0]) throw new Error("Não foi possível salvar o lead.");
      return toLead(rows[0]);
    } catch (cause) { throw safeWriteError(cause); }
  });

export const updateNetlifyLead = createServerFn({ method: "POST" })
  .validator((data: unknown) => updateRequest.parse(data))
  .handler(async ({ data }) => {
    const principal = await requireAuthenticatedPrincipal();
    const db = getServerDatabase();
    await ensureUser(db, principal);
    const input = normalizeInput(data.input);
    try {
      const rows = await db.sql<LeadRow>`
        with updated as (
          update leads set company_name = ${input.companyName}, contact_name = ${input.contactName}, email = ${input.email},
            phone = ${input.phone}, segment = ${input.segment}, city = ${input.city}, state = ${input.state}, notes = ${input.notes}, updated_at = now()
          where id = ${data.id} and owner_id = ${principal.workspaceId}
          returning *
        ), logged as (
          insert into audit_logs(actor_id, action, entity_type, entity_id)
          select ${principal.id}, 'lead.updated', 'lead', id from updated returning id
        )
        select * from updated
      `;
      if (!rows[0]) throw new Error("Lead não encontrado ou sem permissão.");
      return toLead(rows[0]);
    } catch (cause) { throw safeWriteError(cause); }
  });

export const moveNetlifyLead = createServerFn({ method: "POST" })
  .validator((data: unknown) => moveRequest.parse(data))
  .handler(async ({ data }) => {
    const principal = await requireAuthenticatedPrincipal();
    const db = getServerDatabase();
    await ensureUser(db, principal);
    const current = await db.sql<{ stage: string }>`select stage from leads where id = ${data.id} and owner_id = ${principal.workspaceId} limit 1`;
    const from = current[0]?.stage;
    if (!from || !isStage(from)) throw new Error("Lead não encontrado ou sem permissão.");
    if (!canMoveLead(from, data.stage)) throw new Error(`Transição de ${from} para ${data.stage} não permitida.`);
    const rows = await db.sql<LeadRow>`
      with updated as (
        update leads set stage = ${data.stage}, updated_at = now()
        where id = ${data.id} and owner_id = ${principal.workspaceId} and stage = ${from}
        returning *
      ), history as (
        insert into lead_stage_history(lead_id, owner_id, actor_id, from_stage, to_stage)
        select id, owner_id, ${principal.id}, ${from}, ${data.stage} from updated returning id
      ), logged as (
        insert into audit_logs(actor_id, action, entity_type, entity_id, metadata)
        select ${principal.id}, 'lead.stage_changed', 'lead', id, jsonb_build_object('from', ${from}::text, 'to', ${data.stage}::text) from updated returning id
      )
      select * from updated
    `;
    if (!rows[0]) throw new Error("Lead alterado em outra sessão. Atualize a lista e tente novamente.");
    return toLead(rows[0]);
  });

export const suppressNetlifyLead = createServerFn({ method: "POST" })
  .validator((data: unknown) => suppressRequest.parse(data))
  .handler(async ({ data }) => {
    const principal = await requireAuthenticatedPrincipal();
    const db = getServerDatabase();
    await ensureUser(db, principal);
    const rows = await db.sql<LeadRow>`
      with updated as (
        update leads set opted_out_at = coalesce(opted_out_at, now()), updated_at = now()
        where id = ${data.id} and owner_id = ${principal.workspaceId}
        returning *
      ), logged as (
        insert into audit_logs(actor_id, action, entity_type, entity_id)
        select ${principal.id}, 'lead.contact_suppressed', 'lead', id from updated returning id
      )
      select * from updated
    `;
    if (!rows[0]) throw new Error("Lead não encontrado ou sem permissão.");
    return toLead(rows[0]);
  });

export const reviewNetlifyLead = createServerFn({ method: "POST" })
  .validator((data: unknown) => reviewRequest.parse(data))
  .handler(async ({ data }) => {
    const principal = await requireAuthenticatedPrincipal();
    const db = getServerDatabase();
    await ensureUser(db, principal);
    if (data.status === "duplicate" && !data.duplicateOf) throw new Error("Selecione o lead original para marcar uma duplicidade.");
    if (data.duplicateOf === data.id) throw new Error("Um lead não pode ser duplicado de si mesmo.");
    const duplicateOf = data.status === "duplicate" ? data.duplicateOf ?? null : null;
    if (duplicateOf) {
      const original = await db.sql<{ id: string }>`select id from leads where id = ${duplicateOf} and owner_id = ${principal.workspaceId} and id <> ${data.id} limit 1`;
      if (!original[0]) throw new Error("Lead original não encontrado neste workspace.");
    }
    const rows = await db.sql<LeadRow>`
      with updated as (
        update leads set review_status = ${data.status}, reviewed_by = ${principal.id}, reviewed_at = now(),
          duplicate_of = ${duplicateOf}::uuid, updated_at = now()
        where id = ${data.id} and owner_id = ${principal.workspaceId}
        returning *
      ), logged as (
        insert into audit_logs(actor_id, action, entity_type, entity_id, metadata)
        select ${principal.id}, 'lead.review_decided', 'lead', id,
          jsonb_build_object('status', ${data.status}::text, 'duplicateOf', ${duplicateOf}::text)
        from updated returning id
      ) select * from updated
    `;
    if (!rows[0]) throw new Error("Lead não encontrado, duplicado inválido ou sem permissão.");
    return toLead(rows[0]);
  });

export const approveAllPendingNetlifyLeads = createServerFn({ method: "POST" })
  .validator((data: unknown) => emptyRequest.parse(data))
  .handler(async ({ data }) => {
    void data;
    const principal = await requireAuthenticatedPrincipal();
    const db = getServerDatabase();
    await ensureUser(db, principal);
    const rows = await db.sql<LeadRow>`
      with updated as (
        update leads set review_status = 'approved', reviewed_by = ${principal.id}, reviewed_at = now(),
          duplicate_of = null, updated_at = now()
        where owner_id = ${principal.workspaceId} and review_status = 'pending'
        returning *
      ), logged as (
        insert into audit_logs(actor_id, action, entity_type, entity_id, metadata)
        select ${principal.id}, 'lead.review_decided', 'lead', id,
          jsonb_build_object('status', 'approved', 'source', 'bulk_approve')
        from updated returning entity_id
      ) select updated.* from updated
    `;
    return rows.map(toLead);
  });

export const listNetlifyAudit = createServerFn({ method: "POST" })
  .validator((data: unknown) => emptyRequest.parse(data))
  .handler(async ({ data }) => {
    void data;
    const principal = await requireAuthenticatedPrincipal();
    const db = getServerDatabase();
    await ensureUser(db, principal);
    const rows = await db.sql<{ id: string; action: string; entity_id: string | null; created_at: string | Date }>`
      select id, action, entity_id, created_at from audit_logs
      where actor_id = ${principal.workspaceId} or actor_id in (select id from app_users where team_owner_id = ${principal.workspaceId})
      order by created_at desc limit 200
    `;
    return rows.map((row) => ({ id: row.id, action: row.action, entityId: row.entity_id ?? "", summary: "Evento registrado no servidor", createdAt: isoDate(row.created_at) }));
  });

async function ensureUser(db: ReturnType<typeof getServerDatabase>, user: { id: string; email: string | null }): Promise<void> {
  await db.sql`
    insert into app_users(id, email) values (${user.id}, ${user.email})
    on conflict (id) do update set email = excluded.email, updated_at = now()
  `;
  await db.sql`insert into user_profiles(user_id) values (${user.id}) on conflict (user_id) do nothing`;
}
function normalizeInput(input: z.infer<typeof createLeadSchema>) {
  return {
    companyName: input.companyName.trim(), contactName: input.contactName?.trim() || null,
    email: input.email?.trim().toLowerCase() || null, phone: input.phone?.replace(/\D/g, "") || null,
    segment: input.segment?.trim() || null, city: input.city?.trim() || null,
    state: input.state?.trim().toUpperCase() || null, notes: input.notes?.trim() || null,
  };
}
function isStage(stage: string): stage is LeadStage { return (LEAD_STAGES as readonly string[]).includes(stage); }
function isoDate(value: string | Date): string { return value instanceof Date ? value.toISOString() : new Date(value).toISOString(); }
function toLead(row: LeadRow): Lead {
  if (!isStage(row.stage)) throw new Error("Dados persistidos possuem uma etapa inválida.");
  if (!isReviewStatus(row.review_status)) throw new Error("Dados persistidos possuem uma situação de revisão inválida.");
  return { id: row.id, companyName: row.company_name, contactName: row.contact_name, email: row.email, phone: row.phone, segment: row.segment, city: row.city, state: row.state, source: row.source, stage: row.stage, qualificationScore: row.qualification_score, notes: row.notes, optedOutAt: row.opted_out_at ? isoDate(row.opted_out_at) : null, reviewStatus: row.review_status, reviewedAt: row.reviewed_at ? isoDate(row.reviewed_at) : null, duplicateOf: row.duplicate_of, isDemo: false, createdAt: isoDate(row.created_at), updatedAt: isoDate(row.updated_at) };
}
function isReviewStatus(status: string): status is LeadReviewStatus { return (LEAD_REVIEW_STATUSES as readonly string[]).includes(status); }
function safeWriteError(cause: unknown): Error {
  if (cause && typeof cause === "object" && "code" in cause && cause.code === "23505") return new Error("Possível duplicidade: empresa, e-mail ou telefone já cadastrado.");
  return cause instanceof Error && cause.message.startsWith("Lead não encontrado") ? cause : new Error("Não foi possível salvar as alterações. Verifique o banco e tente novamente.");
}
