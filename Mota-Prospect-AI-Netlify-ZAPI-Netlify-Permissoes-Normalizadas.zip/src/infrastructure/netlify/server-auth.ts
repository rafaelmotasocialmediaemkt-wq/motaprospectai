import { createHash, randomBytes, scrypt, timingSafeEqual } from "node:crypto";
import { getCookie } from "@tanstack/react-start/server";
import { getServerDatabase } from "./database.server";

export type AuthenticatedPrincipal = { id: string; email: string | null; workspaceId: string; isAdmin: boolean };
const productionCookie = process.env.NODE_ENV === "production" || process.env.NETLIFY === "true";
export const SESSION_COOKIE = productionCookie ? "__Host-mota_session" : "mota_session";
export const SESSION_MAX_AGE = 60 * 60 * 24 * 7;
const DUMMY_PASSWORD_HASH = `00000000000000000000000000000000:${"00".repeat(64)}`;

export function hashToken(token: string): string { return createHash("sha256").update(token).digest("hex"); }
export function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  return new Promise((resolve, reject) => scrypt(password, salt, 64, { N: 1 << 15, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }, (error, key) => {
    if (error) reject(error); else resolve(`${salt.toString("hex")}:${key.toString("hex")}`);
  }));
}
export async function verifyPassword(stored: string | null, password: string): Promise<boolean> {
  const [saltText, keyText, extra] = (stored ?? DUMMY_PASSWORD_HASH).split(":");
  const validFormat = /^[a-f\d]{32}$/i.test(saltText ?? "") && /^[a-f\d]{128}$/i.test(keyText ?? "") && extra === undefined;
  const encoded = validFormat ? `${saltText}:${keyText}` : DUMMY_PASSWORD_HASH;
  const [salt, expected] = encoded.split(":");
  const actual = await new Promise<Buffer>((resolve, reject) => scrypt(password, Buffer.from(salt, "hex"), 64, { N: 1 << 15, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }, (error, key) => {
    if (error) reject(error); else resolve(key);
  }));
  return Boolean(stored && validFormat && timingSafeEqual(actual, Buffer.from(expected, "hex")));
}

export async function requireAuthenticatedPrincipal(): Promise<AuthenticatedPrincipal> {
  const token = getCookie(SESSION_COOKIE);
  if (!token || !/^[A-Za-z0-9_-]{40,60}$/.test(token)) throw new Error("Sessão ausente ou expirada. Entre novamente.");
  const db = getServerDatabase();
  const sessions = await db.sql<{ id: string; email: string | null; workspace_id: string; is_admin: boolean }>`
    select u.id, u.email, coalesce(u.team_owner_id, u.id) as workspace_id, u.is_admin from auth_sessions s join app_users u on u.id = s.user_id
    where s.token_hash = ${hashToken(token)} and s.expires_at > now() and u.disabled_at is null limit 1
  `;
  if (!sessions[0]) throw new Error("Sessão ausente ou expirada. Entre novamente.");
  return { id: sessions[0].id, email: sessions[0].email, workspaceId: sessions[0].workspace_id, isAdmin: sessions[0].is_admin };
}

export function requireWorkspaceAdmin(principal: AuthenticatedPrincipal): void {
  if (!principal.isAdmin || principal.workspaceId !== principal.id) throw new Error("Apenas a administradora do workspace pode gerenciar a equipe.");
}

export function newSessionToken(): string { return randomBytes(32).toString("base64url"); }
