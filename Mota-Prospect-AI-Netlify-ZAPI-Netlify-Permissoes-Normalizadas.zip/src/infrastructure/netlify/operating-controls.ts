import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getServerDatabase } from "./database.server";
import { requireAuthenticatedPrincipal, requireWorkspaceAdmin } from "./server-auth";

const emptyInput = z.object({});
const settingInput = z.object({
  businessSegment: z.string().trim().max(160),
  targetLocations: z.string().trim().max(500),
  searchTerms: z.string().trim().max(1000),
  maxCandidatesPerShift: z.number().int().min(1).max(100),
  dailyBudgetCents: z.number().int().min(0).max(10_000_000),
  workdayStart: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
  workdayEnd: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
  timezone: z.string().trim().min(1).max(64).refine((value) => { try { new Intl.DateTimeFormat("en", { timeZone: value }); return true; } catch { return false; } }, "Informe um fuso horário IANA válido."),
  requireHumanReview: z.boolean(),
  calendlyBookingUrl: z.union([z.literal(""), z.string().url().max(2048).refine((value) => {
    try { const url = new URL(value); return url.protocol === "https:" && (url.hostname === "calendly.com" || url.hostname.endsWith(".calendly.com")) && !url.username && !url.password; }
    catch { return false; }
  }, "Use um endereço HTTPS oficial do Calendly.")]),
});
const booleanInput = z.object({ enabled: z.boolean() });
type SettingsRow = {
  ai_enabled: boolean; shift_status: "idle" | "active"; shift_started_at: string | Date | null; shift_ended_at: string | Date | null;
  business_segment: string; target_locations: string; search_terms: string; max_candidates_per_shift: number;
  daily_budget_cents: number; workday_start: string; workday_end: string; timezone: string;
  require_human_review: boolean; calendly_booking_url: string; updated_at: string | Date;
};

export const getOperatingSettings = createServerFn({ method: "POST" })
  .validator((data: unknown) => emptyInput.parse(data))
  .handler(async ({ data }) => {
    void data;
    const user = await requireAuthenticatedPrincipal();
    const db = getServerDatabase();
    await ensureSettings(db, user.workspaceId);
    const rows = await db.sql<SettingsRow>`select * from user_operating_settings where owner_id = ${user.workspaceId} limit 1`;
    return toPublic(rows[0], user.workspaceId);
  });

export const saveOperatingSettings = createServerFn({ method: "POST" })
  .validator((data: unknown) => settingInput.parse(data))
  .handler(async ({ data }) => {
    const user = await requireAuthenticatedPrincipal();
    requireWorkspaceAdmin(user);
    const db = getServerDatabase();
    await ensureSettings(db, user.workspaceId);
    const rows = await db.sql<SettingsRow>`
      update user_operating_settings set business_segment = ${data.businessSegment}, target_locations = ${data.targetLocations},
        search_terms = ${data.searchTerms}, max_candidates_per_shift = ${data.maxCandidatesPerShift},
        daily_budget_cents = ${data.dailyBudgetCents}, workday_start = ${data.workdayStart}, workday_end = ${data.workdayEnd},
        timezone = ${data.timezone}, require_human_review = ${data.requireHumanReview}, calendly_booking_url = ${data.calendlyBookingUrl},
        updated_at = now() where owner_id = ${user.workspaceId} returning *
    `;
    await audit(db, user.id, "settings.operating_updated");
    return toPublic(rows[0], user.workspaceId);
  });

export const setAgentEnabled = createServerFn({ method: "POST" })
  .validator((data: unknown) => booleanInput.parse(data))
  .handler(async ({ data }) => {
    const user = await requireAuthenticatedPrincipal();
    requireWorkspaceAdmin(user);
    if (data.enabled && !process.env.GEMINI_API_KEY?.trim()) throw new Error("Configure GEMINI_API_KEY no ambiente server-side antes de ativar o Gemini.");
    const db = getServerDatabase();
    await ensureSettings(db, user.workspaceId);
    const rows = await db.sql<SettingsRow>`update user_operating_settings set ai_enabled = ${data.enabled}, updated_at = now() where owner_id = ${user.workspaceId} returning *`;
    await audit(db, user.id, data.enabled ? "agent.enabled" : "agent.paused");
    return toPublic(rows[0], user.workspaceId);
  });

export const startWorkday = createServerFn({ method: "POST" })
  .validator((data: unknown) => emptyInput.parse(data))
  .handler(async ({ data }) => {
    void data;
    const user = await requireAuthenticatedPrincipal();
    requireWorkspaceAdmin(user);
    const db = getServerDatabase();
    await ensureSettings(db, user.workspaceId);
    const rows = await db.sql<SettingsRow>`update user_operating_settings set shift_status = 'active', shift_started_at = now(), shift_ended_at = null, updated_at = now() where owner_id = ${user.workspaceId} and shift_status = 'idle' returning *`;
    if (!rows[0]) throw new Error("O expediente já está ativo. Encerre-o antes de iniciar uma nova pesquisa.");
    await audit(db, user.id, "workday.started");
    return toPublic(rows[0], user.workspaceId);
  });

export const endWorkday = createServerFn({ method: "POST" })
  .validator((data: unknown) => emptyInput.parse(data))
  .handler(async ({ data }) => {
    void data;
    const user = await requireAuthenticatedPrincipal();
    requireWorkspaceAdmin(user);
    const db = getServerDatabase();
    await ensureSettings(db, user.workspaceId);
    const rows = await db.sql<SettingsRow>`update user_operating_settings set shift_status = 'idle', shift_ended_at = now(), updated_at = now() where owner_id = ${user.workspaceId} returning *`;
    await audit(db, user.id, "workday.ended");
    return toPublic(rows[0], user.workspaceId);
  });

async function ensureSettings(db: ReturnType<typeof getServerDatabase>, ownerId: string): Promise<void> {
  await db.sql`insert into user_operating_settings(owner_id) values (${ownerId}) on conflict (owner_id) do nothing`;
}
async function audit(db: ReturnType<typeof getServerDatabase>, actorId: string, action: string): Promise<void> {
  await db.sql`insert into audit_logs(actor_id, action, entity_type) values (${actorId}, ${action}, 'operation')`;
}
function toPublic(row: SettingsRow | undefined, workspaceId?: string) {
  if (!row) throw new Error("As configurações operacionais não puderam ser carregadas.");
  return {
    workspaceId: workspaceId ?? null,
    aiEnabled: row.ai_enabled, shiftStatus: row.shift_status,
    shiftStartedAt: iso(row.shift_started_at), shiftEndedAt: iso(row.shift_ended_at),
    businessSegment: row.business_segment, targetLocations: row.target_locations, searchTerms: row.search_terms,
    maxCandidatesPerShift: row.max_candidates_per_shift, dailyBudgetCents: row.daily_budget_cents,
    workdayStart: row.workday_start.slice(0, 5), workdayEnd: row.workday_end.slice(0, 5), timezone: row.timezone,
    requireHumanReview: row.require_human_review, calendlyBookingUrl: row.calendly_booking_url,
    updatedAt: iso(row.updated_at),
  };
}
function iso(value: string | Date | null): string | null { return value ? (value instanceof Date ? value : new Date(value)).toISOString() : null; }
