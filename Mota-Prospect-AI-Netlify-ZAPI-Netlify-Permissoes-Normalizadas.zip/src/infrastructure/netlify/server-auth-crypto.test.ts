import { describe, expect, it } from "vitest";
import { hashPassword, hashToken, verifyPassword } from "./server-auth";

describe("Netlify-only authentication primitives", () => {
  it("stores password derivation with a random salt and verifies it", async () => {
    const password = "Correct Horse Battery 77!";
    const first = await hashPassword(password);
    const second = await hashPassword(password);
    expect(first).not.toBe(second);
    await expect(verifyPassword(first, password)).resolves.toBe(true);
    await expect(verifyPassword(first, "wrong password")).resolves.toBe(false);
  });

  it("stores only a fixed-length hash of an opaque session token", () => {
    const digest = hashToken("opaque-session-token");
    expect(digest).toMatch(/^[a-f\d]{64}$/);
    expect(digest).not.toContain("opaque-session-token");
  });
});
