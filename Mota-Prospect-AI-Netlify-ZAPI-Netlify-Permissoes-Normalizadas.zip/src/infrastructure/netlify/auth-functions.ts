import { createServerFn } from "@tanstack/react-start";
import { deleteCookie, getCookie, setCookie } from "@tanstack/react-start/server";
import { createHash, randomUUID } from "node:crypto";
import { z } from "zod";
import { getServerDatabase } from "./database.server";
import { hashPassword, hashToken, newSessionToken, requireAuthenticatedPrincipal, SESSION_COOKIE, SESSION_MAX_AGE, verifyPassword } from "./server-auth";

const credentials = z.object({ email: z.string().trim().email().max(254), password: z.string().min(12).max(128) });
type UserRow = { id: string; email: string };

export const getAuthStatus = createServerFn({ method: "GET" }).handler(async () => {
  const db = getServerDatabase();
  const users = await db.sql<{ exists: boolean }>`select exists(select 1 from app_users) as exists`;
  return { hasUsers: Boolean(users[0]?.exists) };
});

export const getCurrentUser = createServerFn({ method: "GET" }).handler(async () => {
  try { return await requireAuthenticatedPrincipal(); } catch { return null; }
});

export const loginWithPassword = createServerFn({ method: "POST" })
  .validator((data: unknown) => credentials.parse(data))
  .handler(async ({ data }) => {
    const db = getServerDatabase();
    const email = data.email.toLowerCase();
    const identifier = createHash("sha256").update(`login:${email}`).digest("hex");
    const rows = await db.sql<{ id: string; email: string; password_hash: string | null; disabled_at: string | null; is_admin: boolean }>`
      select id, email, password_hash, disabled_at, is_admin from app_users where lower(email) = ${email} limit 1
    `;
    const user = rows[0];
    const lock = await db.sql<{ locked_until: string | Date | null }>`select locked_until from auth_login_attempts where identifier_hash = ${identifier} limit 1`;
    const lockedUntil = lock[0]?.locked_until ? new Date(lock[0].locked_until).getTime() : 0;
    const passwordMatches = await verifyPassword(user?.password_hash ?? null, data.password);
    if (lockedUntil > Date.now() || !user || user.disabled_at || !passwordMatches) {
      await db.sql`
        insert into auth_login_attempts(identifier_hash, failures, locked_until)
        values (${identifier}, 1, null)
        on conflict (identifier_hash) do update set
          failures = case when auth_login_attempts.locked_until > now() then auth_login_attempts.failures else auth_login_attempts.failures + 1 end,
          locked_until = case when auth_login_attempts.failures >= 4 then now() + interval '15 minutes' else auth_login_attempts.locked_until end,
          updated_at = now()
      `;
      throw new Error("Não foi possível entrar. Confira os dados ou aguarde antes de tentar novamente.");
    }
    await db.sql`delete from auth_login_attempts where identifier_hash = ${identifier}`;
    const token = newSessionToken();
    await db.sql`insert into auth_sessions(token_hash, user_id, expires_at) values (${hashToken(token)}, ${user.id}, now() + interval '7 days')`;
    await db.sql`insert into audit_logs(actor_id, action, entity_type) values (${user.id}, 'auth.login', 'session')`;
    setCookie(SESSION_COOKIE, token, cookieOptions());
    return { id: user.id, email: user.email, isAdmin: user.is_admin };
  });

export const registerInitialAdmin = createServerFn({ method: "POST" })
  .validator((data: unknown) => credentials.parse(data))
  .handler(async ({ data }) => {
    const db = getServerDatabase();
    const email = data.email.toLowerCase();
    const available = await db.sql<{ available: boolean }>`select not exists(select 1 from app_users) and not exists(select 1 from auth_bootstrap) as available`;
    if (!available[0]?.available) throw new Error("O cadastro inicial já foi concluído. Entre com a conta existente.");
    const userId = randomUUID();
    const passwordHash = await hashPassword(data.password);
    const rows = await db.sql<UserRow & { isAdmin: boolean }>`
      with claim as (
        insert into auth_bootstrap(singleton_id, admin_user_id)
        select true, ${userId} where not exists (select 1 from app_users)
        on conflict (singleton_id) do nothing returning admin_user_id
      ), created as (
        insert into app_users(id, email, password_hash, is_admin)
        select admin_user_id, ${email}, ${passwordHash}, true from claim returning id, email, is_admin as "isAdmin"
      ), profile as (
        insert into user_profiles(user_id) select id from created returning user_id
      ), logged as (
        insert into audit_logs(actor_id, action, entity_type)
        select id, 'auth.initial_admin_created', 'user' from created returning id
      ) select id, email, "isAdmin" from created
    `;
    if (!rows[0]) throw new Error("O cadastro inicial já foi concluído. Entre com a conta existente.");
    const token = newSessionToken();
    await db.sql`insert into auth_sessions(token_hash, user_id, expires_at) values (${hashToken(token)}, ${rows[0].id}, now() + interval '7 days')`;
    setCookie(SESSION_COOKIE, token, cookieOptions());
    return rows[0];
  });

export const logout = createServerFn({ method: "POST" }).handler(async () => {
  try {
    const principal = await requireAuthenticatedPrincipal();
    const db = getServerDatabase();
    const token = getCookie(SESSION_COOKIE);
    if (token) await db.sql`delete from auth_sessions where token_hash = ${hashToken(token)}`;
    await db.sql`insert into audit_logs(actor_id, action, entity_type) values (${principal.id}, 'auth.logout', 'session')`;
  } catch { /* Clearing an absent/expired session is safe and idempotent. */ }
  deleteCookie(SESSION_COOKIE, { path: "/", httpOnly: true, secure: isSecureCookie(), sameSite: "lax" });
  return { ok: true };
});

function isSecureCookie(): boolean { return process.env.NODE_ENV === "production" || process.env.NETLIFY === "true"; }
function cookieOptions() {
  return { httpOnly: true, secure: isSecureCookie(), sameSite: "lax" as const, path: "/", maxAge: SESSION_MAX_AGE };
}
