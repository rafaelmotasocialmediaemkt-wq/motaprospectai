import { NetlifyDB } from "@netlify/database-dev";
import { randomUUID } from "node:crypto";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("initial administrator bootstrap in Netlify Database", () => {
  it("allows exactly one account to claim an empty database", async () => {
    const db = new NetlifyDB({ logger: () => undefined });
    await db.start();
    try {
      await db.applyMigrations(resolve(process.cwd(), "netlify/database/migrations"));
      const createAdmin = `
        with claim as (
          insert into auth_bootstrap(singleton_id, admin_user_id)
          select true, $1 where not exists (select 1 from app_users)
          on conflict (singleton_id) do nothing returning admin_user_id
        ), created as (
          insert into app_users(id, email, password_hash, is_admin)
          select admin_user_id, $2, $3, true from claim returning id, email
        ), profile as (
          insert into user_profiles(user_id) select id from created returning user_id
        ), logged as (
          insert into audit_logs(actor_id, action, entity_type)
          select id, 'auth.initial_admin_created', 'user' from created returning id
        ) select id, email from created
      `;
      const firstId = randomUUID();
      const first = await db.query<{ id: string; email: string }>(createAdmin, [firstId, "admin@example.test", "salt:derived-hash"]);
      const second = await db.query<{ id: string; email: string }>(createAdmin, [randomUUID(), "other@example.test", "salt:other-hash"]);
      const count = await db.query<{ count: string }>("select count(*)::text as count from app_users");
      expect(first.rows).toEqual([{ id: firstId, email: "admin@example.test" }]);
      expect(second.rows).toEqual([]);
      expect(count.rows[0]?.count).toBe("1");
    } finally { await db.stop(); }
  }, 15000);
});
