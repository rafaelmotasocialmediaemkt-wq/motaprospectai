import { getDatabase, MissingDatabaseConnectionError, type DatabaseConnection } from "@netlify/database";

let connection: DatabaseConnection | undefined;

export function getServerDatabase(): DatabaseConnection {
  try {
    connection ??= getDatabase();
    return connection;
  } catch (cause) {
    if (cause instanceof MissingDatabaseConnectionError) throw new Error("Netlify Database não está configurado neste ambiente.");
    throw new Error("Banco temporariamente indisponível.");
  }
}
