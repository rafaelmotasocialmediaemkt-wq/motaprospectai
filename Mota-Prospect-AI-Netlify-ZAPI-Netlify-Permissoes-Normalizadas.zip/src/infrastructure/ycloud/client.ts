export type YCloudAcceptedText = { id: string; wamid?: string; status?: "accepted" | "failed" | "sent" | "delivered" | "read" };

export type YCloudConfig = { apiKey: string; senderPhone: string };
export type YCloudPhoneNumber = { phoneNumber: string; status: string };

export function isE164(value: string): boolean { return /^\+[1-9]\d{7,14}$/.test(value); }

/** Uses only YCloud's documented queued-message endpoint. A 2xx means accepted, not delivered. */
export async function enqueueYCloudText(
  config: YCloudConfig,
  input: { to: string; body: string; externalId: string },
  fetcher: typeof fetch = fetch,
): Promise<YCloudAcceptedText> {
  if (!config.apiKey.trim()) throw new Error("YCLOUD_API_KEY não configurada.");
  if (!isE164(config.senderPhone) || !isE164(input.to)) throw new Error("Os números de origem e destino devem estar em formato E.164.");
  if (!input.body.trim() || input.body.length > 4096) throw new Error("A mensagem deve conter entre 1 e 4096 caracteres.");
  if (!input.externalId.trim() || input.externalId.length > 200) throw new Error("Identificador de correlação inválido.");

  const response = await fetcher("https://api.ycloud.com/v2/whatsapp/messages", {
    method: "POST",
    headers: { "X-API-Key": config.apiKey, Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({
      from: config.senderPhone,
      to: input.to,
      type: "text",
      text: { body: input.body },
      externalId: input.externalId,
      filterUnsubscribed: true,
      filterBlocked: true,
      useDirectSend: false,
    }),
    redirect: "error",
    cache: "no-store",
    signal: AbortSignal.timeout(15000),
  });
  if (!response.ok) {
    await response.body?.cancel();
    const error = new Error(`YCloud recusou a solicitação (HTTP ${response.status}).`) as Error & { httpStatus: number };
    error.httpStatus = response.status;
    throw error;
  }
  let result: unknown;
  try { result = await response.json(); } catch { throw new Error("YCloud aceitou HTTP 2xx, mas retornou JSON inválido; reconciliação necessária."); }
  if (!result || typeof result !== "object" || typeof (result as { id?: unknown }).id !== "string") {
    throw new Error("YCloud aceitou HTTP 2xx sem identificador de mensagem; reconciliação necessária.");
  }
  const message = result as YCloudAcceptedText;
  if (message.status && !["accepted", "failed", "sent", "delivered", "read"].includes(message.status)) {
    throw new Error("YCloud retornou estado não reconhecido; reconciliação necessária.");
  }
  return message;
}

/** Documented read-only phone-number list endpoint, used only by an explicit admin test action. */
export async function listYCloudPhoneNumbers(apiKey: string, fetcher: typeof fetch = fetch): Promise<YCloudPhoneNumber[]> {
  if (!apiKey.trim()) throw new Error("YCLOUD_API_KEY não configurada.");
  const response = await fetcher("https://api.ycloud.com/v2/whatsapp/phoneNumbers?page=1&limit=100", {
    method: "GET",
    headers: { "X-API-Key": apiKey, Accept: "application/json" },
    redirect: "error",
    cache: "no-store",
    signal: AbortSignal.timeout(12000),
  });
  if (!response.ok) {
    await response.body?.cancel();
    const error = new Error(`YCloud recusou o teste de leitura (HTTP ${response.status}).`) as Error & { httpStatus: number };
    error.httpStatus = response.status;
    throw error;
  }
  const result: unknown = await response.json();
  if (!result || typeof result !== "object" || !Array.isArray((result as { items?: unknown }).items)) throw new Error("Resposta da lista de números YCloud inválida.");
  return (result as { items: unknown[] }).items.flatMap((item): YCloudPhoneNumber[] => {
    if (!item || typeof item !== "object") return [];
    const phone = (item as { phoneNumber?: unknown }).phoneNumber;
    const status = (item as { status?: unknown }).status;
    return typeof phone === "string" && typeof status === "string" ? [{ phoneNumber: phone, status }] : [];
  });
}
