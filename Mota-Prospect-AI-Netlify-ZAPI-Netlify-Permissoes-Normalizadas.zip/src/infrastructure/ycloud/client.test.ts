import { describe, expect, it, vi } from "vitest";
import { enqueueYCloudText, listYCloudPhoneNumbers } from "./client";

describe("YCloud queued text adapter", () => {
  it("constrói o contrato de envio enfileirado com filtros contra opt-out e bloqueio", async () => {
    const fetcher = vi.fn<typeof fetch>().mockResolvedValue(new Response(JSON.stringify({ id: "msg_1", status: "accepted" }), { status: 200 }));
    const result = await enqueueYCloudText({ apiKey: "synthetic-key", senderPhone: "+5511999999999" }, { to: "+5582999999999", body: "Olá", externalId: "test-1" }, fetcher);
    expect(result).toEqual({ id: "msg_1", status: "accepted" });
    expect(fetcher).toHaveBeenCalledOnce();
    const [url, request] = fetcher.mock.calls[0]!;
    expect(url).toBe("https://api.ycloud.com/v2/whatsapp/messages");
    expect(new Headers(request?.headers).get("X-API-Key")).toBe("synthetic-key");
    expect(JSON.parse(String(request?.body))).toMatchObject({
      from: "+5511999999999", to: "+5582999999999", type: "text", text: { body: "Olá" }, externalId: "test-1",
      filterUnsubscribed: true, filterBlocked: true, useDirectSend: false,
    });
  });

  it("valida campos sem chamar a rede e informa status HTTP sem expor body", async () => {
    const fetcher = vi.fn<typeof fetch>();
    await expect(enqueueYCloudText({ apiKey: "", senderPhone: "+5511999999999" }, { to: "+5582999999999", body: "oi", externalId: "1" }, fetcher)).rejects.toThrow("YCLOUD_API_KEY");
    await expect(enqueueYCloudText({ apiKey: "key", senderPhone: "11999999999" }, { to: "+5582999999999", body: "oi", externalId: "1" }, fetcher)).rejects.toThrow("E.164");
    expect(fetcher).not.toHaveBeenCalled();
  });

  it("não trata erro do provedor como sucesso", async () => {
    const fetcher = vi.fn<typeof fetch>().mockResolvedValue(new Response("secret provider details", { status: 400 }));
    await expect(enqueueYCloudText({ apiKey: "synthetic-key", senderPhone: "+5511999999999" }, { to: "+5582999999999", body: "Olá", externalId: "test-1" }, fetcher)).rejects.toMatchObject({ httpStatus: 400 });
  });

  it("valida o número registrado por uma chamada de leitura simulada", async () => {
    const fetcher = vi.fn<typeof fetch>().mockResolvedValue(new Response(JSON.stringify({ items: [{ phoneNumber: "+5511999999999", status: "CONNECTED" }] }), { status: 200 }));
    await expect(listYCloudPhoneNumbers("synthetic-key", fetcher)).resolves.toEqual([{ phoneNumber: "+5511999999999", status: "CONNECTED" }]);
    const [url, request] = fetcher.mock.calls[0]!;
    expect(url).toBe("https://api.ycloud.com/v2/whatsapp/phoneNumbers?page=1&limit=100");
    expect(request?.method).toBe("GET");
  });
});
