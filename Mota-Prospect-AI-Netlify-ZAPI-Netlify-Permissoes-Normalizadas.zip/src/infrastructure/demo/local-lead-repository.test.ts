import { afterEach, describe, expect, it, vi } from "vitest";
import { LocalDemoLeadRepository } from "./local-lead-repository";

const values = new Map<string, string>();
vi.stubGlobal("window", { localStorage: { getItem: (key: string) => values.get(key) ?? null, setItem: (key: string, value: string) => values.set(key, value) } });
afterEach(() => values.clear());

describe("LocalDemoLeadRepository", () => {
  it("rejects duplicate company, email, and phone keys", async () => {
    const repository = new LocalDemoLeadRepository();
    await repository.create({ companyName: "Nova Empresa", email: "team@example.com" });
    await expect(repository.create({ companyName: "  NOVA   EMPRESA ", email: null })).rejects.toThrow("duplicidade");
    await expect(repository.create({ companyName: "Outra Empresa", email: "TEAM@example.com" })).rejects.toThrow("duplicidade");
  });

  it("rejects an invalid terminal stage transition", async () => {
    const repository = new LocalDemoLeadRepository();
    const created = await repository.create({ companyName: "Empresa de Teste" });
    await repository.move(created.id, "won");
    await expect(repository.move(created.id, "contacted")).rejects.toThrow("não permitida");
  });
});
