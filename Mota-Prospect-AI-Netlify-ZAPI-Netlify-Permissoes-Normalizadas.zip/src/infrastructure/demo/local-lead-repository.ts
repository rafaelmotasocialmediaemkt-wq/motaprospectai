import { canMoveLead, type Lead, type LeadStage } from "../../domain/leads/lead";
import type { CreateLeadInput, LeadRepository } from "../../application/leads/lead-service";

const STORAGE_KEY = "mota-prospect-ai.demo-leads.v1";

const examples: Lead[] = [
  {
    id: "demo-001",
    companyName: "Empresa Exemplo Maceió",
    contactName: "Contato Fictício",
    email: "contato@example.invalid",
    phone: null,
    segment: "Serviços",
    city: "Maceió",
    state: "AL",
    source: "DEMO",
    stage: "new",
    qualificationScore: null,
    notes: "Registro fictício para demonstrar a interface.",
    optedOutAt: null,
    reviewStatus: "pending",
    reviewedAt: null,
    duplicateOf: null,
    isDemo: true,
    createdAt: "2026-01-01T12:00:00.000Z",
    updatedAt: "2026-01-01T12:00:00.000Z",
  },
];

export class LocalDemoLeadRepository implements LeadRepository {
  async list(): Promise<Lead[]> {
    if (typeof window === "undefined") return examples;
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (!saved) return examples;
    try {
      const parsed: unknown = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed.filter(isLead).map((lead) => ({
        ...lead,
        optedOutAt: lead.optedOutAt ?? null,
        reviewStatus: lead.reviewStatus ?? "pending",
        reviewedAt: lead.reviewedAt ?? null,
        duplicateOf: lead.duplicateOf ?? null,
      })) : examples;
    } catch {
      return examples;
    }
  }

  async create(input: CreateLeadInput): Promise<Lead> {
    const rows = await this.list();
    assertUnique(rows, input);
    const now = new Date().toISOString();
    const lead: Lead = {
      id: crypto.randomUUID(),
      companyName: input.companyName,
      contactName: input.contactName ?? null,
      email: input.email || null,
      phone: input.phone || null,
      segment: input.segment ?? null,
      city: input.city ?? null,
      state: input.state ?? null,
      source: "LOCAL DEMO",
      stage: "new",
      qualificationScore: null,
      notes: input.notes ?? null,
      optedOutAt: null,
      reviewStatus: "pending",
      reviewedAt: null,
      duplicateOf: null,
      isDemo: true,
      createdAt: now,
      updatedAt: now,
    };
    if (typeof window !== "undefined") window.localStorage.setItem(STORAGE_KEY, JSON.stringify([lead, ...rows]));
    return lead;
  }

  async update(id: string, input: CreateLeadInput): Promise<Lead> {
    const rows = await this.list();
    const current = rows.find((lead) => lead.id === id);
    if (!current) throw new Error("Lead não encontrado.");
    assertUnique(rows.filter((lead) => lead.id !== id), input);
    const updated = { ...current, ...input, updatedAt: new Date().toISOString() };
    this.save(rows.map((lead) => lead.id === id ? updated : lead));
    return updated;
  }

  async move(id: string, stage: LeadStage): Promise<Lead> {
    const rows = await this.list();
    const current = rows.find((lead) => lead.id === id);
    if (!current) throw new Error("Lead não encontrado.");
    if (!canMoveLead(current.stage, stage)) throw new Error(`Transição de ${current.stage} para ${stage} não permitida.`);
    const updated = { ...current, stage, updatedAt: new Date().toISOString() };
    this.save(rows.map((lead) => lead.id === id ? updated : lead));
    return updated;
  }

  async suppressContact(id: string): Promise<Lead> {
    const rows = await this.list();
    const current = rows.find((lead) => lead.id === id);
    if (!current) throw new Error("Lead não encontrado.");
    const updated = { ...current, optedOutAt: current.optedOutAt ?? new Date().toISOString(), updatedAt: new Date().toISOString() };
    this.save(rows.map((lead) => lead.id === id ? updated : lead));
    return updated;
  }

  async review(id: string, status: Lead["reviewStatus"], duplicateOf?: string): Promise<Lead> {
    const rows = await this.list();
    const current = rows.find((lead) => lead.id === id);
    if (!current) throw new Error("Lead não encontrado.");
    if (status === "duplicate" && (!duplicateOf || duplicateOf === id || !rows.some((lead) => lead.id === duplicateOf))) throw new Error("Selecione outro lead existente para marcar a duplicidade.");
    const updated = { ...current, reviewStatus: status, reviewedAt: new Date().toISOString(), duplicateOf: status === "duplicate" ? duplicateOf! : null, updatedAt: new Date().toISOString() };
    this.save(rows.map((lead) => lead.id === id ? updated : lead));
    return updated;
  }

  async approvePending(): Promise<Lead[]> {
    const rows = await this.list();
    const now = new Date().toISOString();
    const updated = rows.map((lead) => lead.reviewStatus === "pending"
      ? { ...lead, reviewStatus: "approved" as const, reviewedAt: now, duplicateOf: null, updatedAt: now }
      : lead);
    this.save(updated);
    return updated.filter((lead) => lead.reviewStatus === "approved" && rows.some((old) => old.id === lead.id && old.reviewStatus === "pending"));
  }

  private save(rows: Lead[]): void {
    if (typeof window !== "undefined") window.localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
  }
}

function isLead(value: unknown): value is Lead {
  if (!value || typeof value !== "object") return false;
  const row = value as Partial<Lead>;
  return typeof row.id === "string" && typeof row.companyName === "string" && typeof row.stage === "string" && row.isDemo === true;
}

function assertUnique(rows: Lead[], input: CreateLeadInput): void {
  const email = input.email?.trim().toLocaleLowerCase("pt-BR");
  const phone = input.phone?.replace(/\D/g, "");
  const company = input.companyName.trim().normalize("NFKC").replace(/\s+/g, " ").toLocaleLowerCase("pt-BR");
  const duplicate = rows.find((row) => (email && row.email?.toLocaleLowerCase("pt-BR") === email) || (phone && row.phone?.replace(/\D/g, "") === phone) || row.companyName.trim().normalize("NFKC").replace(/\s+/g, " ").toLocaleLowerCase("pt-BR") === company);
  if (duplicate) throw new Error(`Possível duplicidade: já existe o lead “${duplicate.companyName}”.`);
}
