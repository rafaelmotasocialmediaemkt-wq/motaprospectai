export type AuditRecord = { id: string; action: string; entityId: string; summary: string; createdAt: string };
const STORAGE_KEY = "mota-prospect-ai.demo-audit.v1";

export function writeDemoAudit(action: string, entityId: string, summary: string): void {
  if (typeof window === "undefined") return;
  try {
    const current = JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? "[]") as AuditRecord[];
    current.unshift({ id: crypto.randomUUID(), action, entityId, summary, createdAt: new Date().toISOString() });
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(current.slice(0, 200)));
  } catch {
    // Demo audit storage is best-effort and is never represented as server audit.
  }
}

export function readDemoAudit(): AuditRecord[] {
  if (typeof window === "undefined") return [];
  try { return JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? "[]") as AuditRecord[]; }
  catch { return []; }
}
