import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { createTeamMember, listTeamMembers, setTeamMemberDisabled } from "../infrastructure/netlify/team-functions";
import { isDemoMode } from "../infrastructure/netlify/mode";

export const Route = createFileRoute("/team")({ component: Team });
type Member = { id: string; email: string; disabled: boolean; createdAt: string };
function Team() {
  const [members, setMembers] = useState<Member[]>([]); const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [error, setError] = useState(""); const [notice, setNotice] = useState(""); const [busy, setBusy] = useState(false);
  async function load() { setMembers(await listTeamMembers({ data: {} }) as Member[]); }
  useEffect(() => { void load().catch((e) => setError(e instanceof Error ? e.message : "Falha ao carregar equipe.")); }, []);
  async function create(event: FormEvent) { event.preventDefault(); setBusy(true); setError(""); setNotice(""); try { await createTeamMember({ data: { email, password } }); setEmail(""); setPassword(""); setNotice("Acesso criado. Compartilhe a senha inicial com a pessoa por um canal seguro e peça que ela a altere fora do app até haver recuperação de senha."); await load(); } catch (e) { setError(e instanceof Error ? e.message : "Não foi possível criar o acesso."); } finally { setBusy(false); } }
  async function toggle(member: Member) { setBusy(true); setError(""); try { await setTeamMemberDisabled({ data: { id: member.id, disabled: !member.disabled } }); await load(); } catch (e) { setError(e instanceof Error ? e.message : "Não foi possível alterar o acesso."); } finally { setBusy(false); } }
  return <div className="page"><header className="topbar"><div><div className="eyebrow">ADMINISTRAÇÃO</div><h1>Equipe comercial</h1><p>Crie logins para a equipe. Os usuários de vendas podem acessar os leads e agendamentos do workspace, sem administrar integrações ou equipe.</p></div></header>
    {isDemoMode && <div className="notice">A equipe exige autenticação e Netlify Database ativos; não é simulada no modo demonstração.</div>}
    {error && <p className="form-error" role="alert">{error}</p>}{notice && <div className="notice" role="status">{notice}</div>}
    <form className="settings-card team-form" onSubmit={(e) => void create(e)}><h2>Novo acesso comercial</h2><label>E-mail<input type="email" required maxLength={254} value={email} onChange={(e) => setEmail(e.target.value)} /></label><label>Senha inicial (mínimo 12 caracteres)<input type="password" required minLength={12} maxLength={128} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} /></label><button className="button primary" disabled={busy || isDemoMode}>{busy ? "Salvando…" : "Criar acesso"}</button></form>
    <section className="team-members"><h2>Acessos da equipe</h2>{members.length === 0 ? <div className="empty-panel"><p>Nenhum acesso de equipe criado.</p></div> : members.map((member) => <article className="settings-card" key={member.id}><div className="settings-control-copy"><strong>{member.email}</strong><p>Criado em {new Date(member.createdAt).toLocaleDateString("pt-BR")}</p><span className={`badge ${member.disabled ? "badge-neutral" : "badge-success"}`}>{member.disabled ? "BLOQUEADO" : "ATIVO"}</span></div><button className="button secondary" disabled={busy} onClick={() => void toggle(member)}>{member.disabled ? "Reativar" : "Bloquear login"}</button></article>)}</section>
  </div>;
}
