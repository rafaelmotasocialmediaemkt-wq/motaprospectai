import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, CalendarClock, ContactRound, ShieldAlert, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";
import type { Lead } from "../domain/leads/lead";
import { leadService } from "../infrastructure/leads/lead-service";
import { isDemoMode } from "../infrastructure/netlify/mode";

export const Route = createFileRoute("/")({ component: Dashboard });
function Dashboard() {
  const [leads, setLeads] = useState<Lead[]>([]); const [error, setError] = useState(""); const [loading, setLoading] = useState(true);
  useEffect(() => { void leadService.list().then(setLeads).catch((cause: unknown) => setError(cause instanceof Error ? cause.message : "Falha ao carregar indicadores.")).finally(() => setLoading(false)); }, []);
  const active = leads.filter((lead) => !["won", "lost", "archived"].includes(lead.stage)).length;
  const qualified = leads.filter((lead) => lead.stage === "qualified" || lead.stage === "contact_authorized").length;
  return <div className="page"><header className="topbar"><div><div className="eyebrow">VISÃO GERAL</div><h1>Resumo operacional</h1><p>Indicadores calculados com os leads disponíveis no workspace.</p></div><span className={`badge ${isDemoMode ? "badge-warn" : "badge-neutral"}`}><span className="dot" /> {isDemoMode ? "MODO DE DEMONSTRAÇÃO" : "NETLIFY DB"}</span></header>
    <section className="notice"><ShieldAlert size={18} /><div><strong>{!isDemoMode ? "Controles externos desligados" : "Ambiente de demonstração isolado"}</strong><p>{!isDemoMode ? "Os dados são carregados com sessão autenticada. IA, prospecção e envio de mensagens permanecem desligados." : "Os totais vêm de registros locais; IA, prospecção e mensagens externas estão pausadas."}</p></div></section>
    {error && <div className="form-error notice-error" role="alert">{error}</div>}
    <section className="stats"><Stat title="Leads" value={loading ? "—" : String(leads.length)} sub={!isDemoMode ? "Registros da conta autenticada" : `${leads.filter((lead) => lead.isDemo).length} registro(s) marcados como DEMO`} icon={<ContactRound />} /><Stat title="No funil ativo" value={loading ? "—" : String(active)} sub="Não inclui ganhos, perdas ou arquivados" icon={<Sparkles />} /><Stat title="Qualificados" value={loading ? "—" : String(qualified)} sub="Etapas qualificado e contato autorizado" icon={<CalendarClock />} /></section>
    <div className="section-heading"><div><h2>Próximos passos</h2><p>Operação local e configuração aparecem separadas para evitar ações externas acidentais.</p></div></div>
    <section className="action-grid"><Link to="/leads" className="action-card"><span className="card-icon blue"><ContactRound size={20} /></span><h3>Organizar leads</h3><p>Pesquise, filtre, importe ou atualize etapas do funil.</p><span className="card-link">Abrir leads <ArrowUpRight size={15} /></span></Link><Link to="/integrations" className="action-card"><span className="card-icon violet"><Sparkles size={20} /></span><h3>Ver integrações</h3><p>Confira contratos confirmados e configurações pendentes.</p><span className="card-link">Ver integrações <ArrowUpRight size={15} /></span></Link></section>
    {isDemoMode && <div className="footnote">O registro inicial é fictício. Os dados não são compartilhados nem adequados para uso multiusuário.</div>}
  </div>;
}
function Stat({ title, value, sub, icon }: { title: string; value: string; sub: string; icon: React.ReactNode }) { return <article className="stat-card"><div className="stat-top"><span>{title}</span><span className="stat-icon">{icon}</span></div><strong>{value}</strong><small>{sub}</small></article>; }
