import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ShieldCheck } from "lucide-react";
import { readDemoAudit, type AuditRecord } from "../infrastructure/audit/local-audit";
import { isDemoMode } from "../infrastructure/netlify/mode";
import { listNetlifyAudit } from "../infrastructure/netlify/lead-functions";

export const Route = createFileRoute("/audit")({ component: AuditPage });
function AuditPage() {
  const [rows, setRows] = useState<AuditRecord[]>([]); const [error, setError] = useState(""); const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (isDemoMode) { setRows(readDemoAudit()); setLoading(false); return; }
    void listNetlifyAudit({ data: {} }).then(setRows).catch((cause: unknown) => setError(cause instanceof Error ? cause.message : "Não foi possível carregar a auditoria.")).finally(() => setLoading(false));
  }, []);
  return <div className="page"><header className="topbar"><div><div className="eyebrow">CONTROLE</div><h1>{!isDemoMode ? "Auditoria do servidor" : "Auditoria local"}</h1><p>{!isDemoMode ? "Eventos persistidos no banco Netlify." : "Eventos de demonstração armazenados neste navegador."}</p></div></header>{error && <div className="form-error notice-error" role="alert">{error}</div>}{loading ? <section className="empty-panel"><h2>Carregando auditoria…</h2></section> : rows.length ? <div className="audit-list">{rows.map((row) => <article key={row.id}><ShieldCheck size={17} /><div><strong>{row.action}</strong><p>{row.summary}</p><small>{new Date(row.createdAt).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })}</small></div></article>)}</div> : <section className="empty-panel"><ShieldCheck size={28} /><h2>Nenhum evento registrado</h2><p>{isDemoMode ? "As ações de demonstração são guardadas neste navegador, não no servidor." : "O banco ainda não tem eventos para esta conta."}</p></section>}</div>;
}
