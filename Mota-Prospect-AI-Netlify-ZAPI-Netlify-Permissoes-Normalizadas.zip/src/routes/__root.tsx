import { createRootRoute, HeadContent, Link, Outlet, Scripts } from "@tanstack/react-router";
import { Activity, BellRing, CalendarDays, ContactRound, LayoutDashboard, LoaderCircle, LogOut, MessageCircle, PlugZap, Settings2, ShieldCheck, UsersRound } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { getAuthStatus, getCurrentUser, loginWithPassword, logout, registerInitialAdmin } from "../infrastructure/netlify/auth-functions";
import { isDemoMode } from "../infrastructure/netlify/mode";
import "../styles.css";
import "../styles-auth.css";

const navigation = [["Início", "/", LayoutDashboard], ["Leads", "/leads", ContactRound], ["WhatsApp · YCloud", "/inbox", MessageCircle], ["Agendamentos", "/appointments", CalendarDays], ["Atendimento", "/handoffs", BellRing], ["Integrações", "/integrations", PlugZap], ["Auditoria", "/audit", ShieldCheck], ["Configurações", "/settings", Settings2], ["Equipe", "/team", UsersRound]] as const;
type AuthUser = { id: string; email: string | null; isAdmin: boolean };
type AuthStatus = { hasUsers: boolean };

export const Route = createRootRoute({
  head: () => ({ meta: [{ title: "Mota Prospect AI · Codex" }, { name: "description", content: "Workspace local para reconstrução do Mota Prospect AI." }] }),
  component: Root,
});

function Root() {
  const [sessionReady, setSessionReady] = useState(isDemoMode);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [authStatus, setAuthStatus] = useState<AuthStatus | null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authMode, setAuthMode] = useState<"login" | "register">("register");
  const [authError, setAuthError] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [authUnavailable, setAuthUnavailable] = useState(false);

  useEffect(() => {
    if (isDemoMode) return;
    void Promise.all([getAuthStatus({ data: undefined }), getCurrentUser({ data: undefined })])
      .then(([status, current]) => { setAuthStatus(status); setUser(current); setAuthMode(status.hasUsers ? "login" : "register"); })
      .catch(() => setAuthUnavailable(true))
      .finally(() => setSessionReady(true));
  }, []);

  async function submitAuth(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setAuthBusy(true); setAuthError("");
    try {
      const credentials = { email: email.trim(), password };
      const current = authMode === "login"
        ? await loginWithPassword({ data: credentials })
        : await registerInitialAdmin({ data: credentials });
      setUser(current); setPassword(""); setAuthStatus({ hasUsers: true }); setAuthMode("login");
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "";
      if (message.includes("Netlify Database") || message.includes("temporariamente indisponível")) {
        setAuthError("Não foi possível conectar ao Netlify Database. Verifique se o banco está habilitado para este site e se as migrações terminaram no deploy.");
      } else if (message.startsWith("Não foi possível entrar.") || message.startsWith("O cadastro inicial já foi concluído.")) {
        setAuthError(message);
      } else {
        setAuthError("O serviço de autenticação não respondeu corretamente. Verifique o Netlify Database e as migrações do deploy e tente novamente.");
      }
    } finally { setAuthBusy(false); }
  }

  async function signOut() {
    await logout({ data: undefined }); setUser(null);
  }

  const blocked = !isDemoMode && (!sessionReady || !user);
  return <html lang="pt-BR"><head><HeadContent /></head><body>
    {blocked ? <main className="auth-screen"><section className="auth-card">
      <div className="brand-mark">M</div>
      <h1>{!sessionReady ? "Verificando acesso" : authUnavailable ? "Banco indisponível" : authMode === "login" ? "Acesso ao workspace" : "Crie sua conta"}</h1>
      {!sessionReady ? <p><LoaderCircle className="spin" size={18} /> Verificando sessão…</p> : authUnavailable ? <><p>Não foi possível acessar o Netlify Database. Confirme que o banco foi habilitado para este site e que as migrações foram aplicadas.</p><p>Autenticação e dados desta aplicação usam somente o banco Netlify.</p></> : <>
        <p>{authMode === "login" ? "Entre com a conta deste workspace." : "O primeiro cadastro cria a conta administradora. Depois disso, novos cadastros ficam fechados."}</p>
        {authStatus && <div className="auth-tabs" role="tablist" aria-label="Acesso à conta">
          <button type="button" role="tab" aria-selected={authMode === "login"} className={authMode === "login" ? "auth-tab active" : "auth-tab"} onClick={() => { setAuthMode("login"); setAuthError(""); }}>Entrar</button>
          <button type="button" role="tab" aria-selected={authMode === "register"} aria-disabled={authStatus.hasUsers} disabled={authStatus.hasUsers} className={authMode === "register" ? "auth-tab active" : "auth-tab"} onClick={() => { setAuthMode("register"); setAuthError(""); }}>Cadastro</button>
        </div>}
        {authStatus?.hasUsers ? null : <p className="auth-hint">O cadastro é de uso único: a primeira conta recebe acesso de administradora.</p>}
        <form onSubmit={(event) => void submitAuth(event)} className="auth-form">
          <label>E-mail<input type="email" required maxLength={254} autoComplete="username" value={email} onChange={(event) => setEmail(event.target.value)} /></label>
          <label>Senha<input type="password" required minLength={12} maxLength={128} autoComplete={authMode === "login" ? "current-password" : "new-password"} value={password} onChange={(event) => setPassword(event.target.value)} /></label>
          {authError && <p className="form-error" role="alert">{authError}</p>}
          <button className="button primary" disabled={authBusy || (authMode === "register" && Boolean(authStatus?.hasUsers))}>{authBusy ? "Aguarde…" : authMode === "login" ? "Entrar" : "Criar conta administradora"}</button>
        </form>
      </>}
      {isDemoMode && <p>O modo de demonstração só funciona no servidor de desenvolvimento local e não grava no Netlify Database.</p>}
    </section></main> : <div className="shell"><aside className="sidebar"><div className="brand"><div className="brand-mark">M</div><div><strong>Mota Prospect AI</strong><small>Workspace Codex</small></div></div><div className="workspace-pill"><span className="pulse" />{isDemoMode ? "AMBIENTE LOCAL · DEMO" : "NETLIFY DB · AUTENTICADO"}</div><nav>{navigation.filter(([label]) => isDemoMode || user?.isAdmin || !["Equipe", "Configurações", "Integrações", "Auditoria"].includes(label)).map(([label, to, Icon]) => <Link key={to} to={to} className="nav-link" activeProps={{ className: "nav-link active" }}><Icon size={17} />{label}</Link>)}</nav><div className="sidebar-bottom"><Activity size={16} /><span>Ações externas sob confirmação</span></div>{user && <button className="sidebar-user" onClick={() => void signOut()}><span>{user.email}</span><LogOut size={15} aria-label="Sair" /></button>}</aside><main className="main"><Outlet /></main></div>}
    <Scripts />
  </body></html>;
}
