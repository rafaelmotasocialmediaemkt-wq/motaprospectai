import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Bot, CheckCheck, Hand, MessageCircle, Pause, Play, RefreshCw, Search, Send, Sparkles, StickyNote, UserRound } from "lucide-react";
import type { Lead } from "../domain/leads/lead";
import { leadService } from "../infrastructure/leads/lead-service";
import { isDemoMode } from "../infrastructure/netlify/mode";
import { addInboxNote, listConversationMessages, listInbox, openInboxConversation, simulateInboxMessage, updateInboxConversation } from "../infrastructure/netlify/messaging-functions";
import { sendZapiTextMessage } from "../infrastructure/netlify/zapi-functions";
import { listProviderSettings } from "../infrastructure/netlify/provider-functions";
import { getGeminiReplyStatus, suggestGeminiReply } from "../infrastructure/netlify/gemini-functions";
import "../styles-inbox.css";

export const Route = createFileRoute("/inbox")({ component: Inbox });
type Conversation = { id: string; leadId: string; companyName: string; phone: string | null; email: string | null; stage: string; optedOut: boolean; status: string; assignedTo: string | null; aiPaused: boolean; lastMessageAt: string; lastBody: string | null; lastDirection: string | null; unreadCount: number };
type Message = { id: string; direction: string; author: string; body: string; status: string; simulated: boolean; createdAt: string; createdBy: string | null };
type ZapiStatus = { enabled: boolean; configured: boolean; instanceId: string };
type GeminiStatus = { configured: boolean; model: string };
type ReplySuggestion = { reply: string; intent: string; summary: string; nextStep: string; requiresHuman: boolean };
function Inbox() {
  const [conversations, setConversations] = useState<Conversation[]>([]); const [leads, setLeads] = useState<Lead[]>([]); const [selected, setSelected] = useState(""); const [messages, setMessages] = useState<Message[]>([]);
  const [body, setBody] = useState(""); const [note, setNote] = useState(""); const [search, setSearch] = useState(""); const [simulateInbound, setSimulateInbound] = useState(false); const [sendReal, setSendReal] = useState(false); const [zapi, setZapi] = useState<ZapiStatus | null>(null); const [gemini, setGemini] = useState<GeminiStatus | null>(null); const [suggestion, setSuggestion] = useState<ReplySuggestion | null>(null);
  const [loading, setLoading] = useState(true); const [busy, setBusy] = useState(false); const [error, setError] = useState(""); const [notice, setNotice] = useState("");
  const current = conversations.find((row) => row.id === selected) ?? null;
  const filtered = useMemo(() => conversations.filter((row) => row.companyName.toLocaleLowerCase("pt-BR").includes(search.toLocaleLowerCase("pt-BR"))), [conversations, search]);
  async function refresh(silent = false) {
    if (!silent) { setLoading(true); setError(""); }
    try { const [inbox, allLeads, providers, geminiStatus] = await Promise.all([listInbox({ data: {} }) as Promise<Conversation[]>, leadService.list(), listProviderSettings({ data: {} }), getGeminiReplyStatus({ data: {} }) as Promise<GeminiStatus>]); const whatsApp = providers.find((row) => row.provider === "whatsapp_zapi"); setZapi({ enabled: Boolean(whatsApp?.connected), configured: Boolean(whatsApp?.hasSecret), instanceId: whatsApp?.config.instanceId ?? "" }); setConversations(inbox); setLeads(allLeads); setGemini(geminiStatus); if (!selected && inbox[0]) setSelected(inbox[0].id); }
    catch (cause) { if (!silent) setError(cause instanceof Error ? cause.message : "Não foi possível carregar a inbox. Entre no workspace autenticado com Netlify Database."); }
    finally { if (!silent) setLoading(false); }
  }
  async function loadMessages(id: string, silent = false) { try { setMessages(await listConversationMessages({ data: { conversationId: id } }) as Message[]); } catch (cause) { if (!silent) setError(cause instanceof Error ? cause.message : "Falha ao carregar mensagens."); } }
  useEffect(() => { void refresh(); }, []);
  useEffect(() => { setSuggestion(null); if (selected) void loadMessages(selected); else setMessages([]); }, [selected]);
  useEffect(() => {
    const timer = window.setInterval(() => { void refresh(true); if (selected) void loadMessages(selected, true); }, 15_000);
    return () => window.clearInterval(timer);
  }, [selected]);
  async function requestSuggestion() {
    if (!current) return; setBusy(true); setError(""); setNotice(""); setSuggestion(null);
    try { setSuggestion(await suggestGeminiReply({ data: { conversationId: current.id } }) as ReplySuggestion); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível gerar a sugestão Gemini."); }
    finally { setBusy(false); }
  }
  async function createConversation(leadId: string) {
    setBusy(true); setError(""); setNotice("");
    try { const result = await openInboxConversation({ data: { leadId } }); await refresh(); setSelected(result.id); setNotice("Conversa local aberta em modo simulado. Nenhuma mensagem foi enviada."); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível abrir a conversa."); }
    finally { setBusy(false); }
  }
  async function submitMessage(event: React.FormEvent) {
    event.preventDefault(); if (!current || !body.trim()) return;
    if (!isDemoMode && !sendReal) { setError("Em produção, envie mensagens reais somente pela integração Z-API conectada."); return; }
    if (sendReal && !window.confirm("Enviar esta mensagem real pelo WhatsApp via Z-API? A API pode aceitar o envio; isso não confirma entrega. A ação será registrada na auditoria.")) return;
    setBusy(true); setError(""); setNotice("");
    try {
      if (sendReal) {
        const result = await sendZapiTextMessage({ data: { conversationId: current.id, body: body.trim(), idempotencyKey: crypto.randomUUID() } });
        if (!result.accepted) { await Promise.all([loadMessages(current.id), refresh()]); throw new Error("Z-API informou falha para esta mensagem. Confira o WhatsApp antes de tentar novamente."); }
        setBody(""); setSendReal(false); setNotice(`Z-API aceitou a mensagem (${result.status}); confirme a entrega no WhatsApp.`);
      } else {
        const result = await simulateInboxMessage({ data: { conversationId: current.id, body: body.trim(), direction: simulateInbound ? "inbound" : "outbound", ...(simulateInbound ? { idempotencyKey: crypto.randomUUID() } : {}) } });
        if (!result.accepted) throw new Error(result.reason);
        setBody(""); setNotice(simulateInbound ? "Mensagem de entrada simulada registrada. Se continha um pedido explícito de opt-out, o contato foi bloqueado." : "Resposta simulada registrada. Nenhuma mensagem saiu para o WhatsApp.");
      }
      await Promise.all([loadMessages(current.id), refresh()]);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível registrar a mensagem simulada."); }
    finally { setBusy(false); }
  }
  async function setStatus(status: "take" | "pause" | "resume" | "waiting" | "closed" | "open") {
    if (!current) return; setBusy(true); setError("");
    try { await updateInboxConversation({ data: { conversationId: current.id, status } }); await refresh(); setNotice(status === "take" ? "Você assumiu a conversa; a assistência automática fica pausada." : "Estado da conversa atualizado."); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível atualizar a conversa."); }
    finally { setBusy(false); }
  }
  async function addNote(event: React.FormEvent) {
    event.preventDefault(); if (!current || !note.trim()) return; setBusy(true); setError("");
    try { await addInboxNote({ data: { conversationId: current.id, body: note.trim() } }); setNote(""); setNotice("Nota interna salva. Ela não foi enviada ao contato."); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível salvar a nota."); }
    finally { setBusy(false); }
  }
  return <div className="page"><header className="topbar"><div><div className="eyebrow">WHATSAPP · Z-API</div><h1>Inbox de conversas</h1><p>Mensagens do webhook Z-API e respostas enviadas pelo servidor.</p></div><button className="button secondary" onClick={() => { void refresh(); if (selected) void loadMessages(selected); }} disabled={loading}><RefreshCw size={14}/>Atualizar</button></header>
    <div className="notice"><MessageCircle size={18}/><div><strong>{zapi?.enabled ? "Z-API CONECTADA · ENVIO MANUAL" : zapi?.configured ? "Z-API CONFIGURADA · TESTE PENDENTE" : "Z-API AGUARDANDO CONFIGURAÇÃO"}</strong><p>{zapi?.enabled ? `Instância ${zapi.instanceId} conectada. Gemini gera sugestões revisáveis; nenhuma resposta é automática.` : "Configure e teste a instância em Integrações. Cadastre a URL de webhook exibida para receber as conversas."} <a href="/integrations">Abrir integrações</a></p></div></div>
    {isDemoMode && <div className="notice compact"><p>Você está em DEMO local. Para usar a inbox persistida, entre com uma conta e configure o Netlify Database.</p></div>}
    {error && <p className="form-error notice-error" role="alert">{error}</p>}{notice && <div className="notice compact" role="status"><p>{notice}</p></div>}
    <section className="inbox-layout whatsapp-shell">
      <aside className="settings-card inbox-list"><div className="inbox-list-head"><h2><MessageCircle size={19}/> Conversas</h2><span className="live-indicator">● Atualiza automaticamente</span></div><label className="inbox-search"><Search size={16}/><input aria-label="Buscar conversa" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar conversa"/></label><div className="inbox-items">{loading ? <p className="empty">Carregando…</p> : filtered.length === 0 ? <p className="empty">Nenhuma conversa. Use o seletor de leads abaixo para abrir uma.</p> : filtered.map((row) => <button key={row.id} className={`inbox-item ${row.id === selected ? "active" : ""}`} onClick={() => setSelected(row.id)}><span className="inbox-avatar">{row.companyName.slice(0,1).toLocaleUpperCase("pt-BR")}</span><span className="inbox-item-copy"><strong>{row.companyName}</strong><small>{row.lastBody ?? "Conversa iniciada · sem mensagens"}</small></span><span className="inbox-item-meta"><small>{new Date(row.lastMessageAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone: "America/Maceio" })}</small>{row.unreadCount > 0 && <span className="badge badge-warn">{row.unreadCount}</span>}</span></button>)}</div></aside>
      <section className="settings-card inbox-thread">{!current ? <div className="empty-panel"><MessageCircle size={26}/><h2>Selecione uma conversa</h2><p>Conversas simuladas são isoladas do WhatsApp real.</p></div> : <>
        <header className="inbox-thread-head"><span className="inbox-avatar thread-avatar">{current.companyName.slice(0,1).toLocaleUpperCase("pt-BR")}</span><div className="thread-contact"><h2>{current.companyName}</h2><p>{current.phone ?? current.email ?? "Sem contato comercial registrado"}{current.optedOut ? " · BLOQUEADO PARA CONTATO" : ""}</p></div><div className="inbox-actions"><button className="button secondary" disabled={busy} onClick={() => void setStatus("take")}><Hand size={14}/>Assumir</button>{current.aiPaused ? <button className="button secondary" disabled={busy} onClick={() => void setStatus("resume")}><Play size={14}/>Permitir assistência</button> : <button className="button secondary" disabled={busy} onClick={() => void setStatus("pause")}><Pause size={14}/>Pausar assistência</button>}<button className="button secondary" disabled={busy} onClick={() => void setStatus(current.status === "closed" ? "open" : "closed")}>{current.status === "closed" ? "Reabrir" : "Encerrar"}</button><button className="chat-icon-button" type="button" title="Atualizar mensagens" aria-label="Atualizar mensagens" onClick={() => void loadMessages(current.id)}><RefreshCw size={17}/></button></div></header>
        <div className="inbox-context"><UserRound size={16}/><span>Etapa: {current.stage}</span><span>Responsável: {current.assignedTo ? "atribuído" : "não atribuído"}</span><span>Assistência: {current.aiPaused ? "pausada" : `permitida · Gemini ${gemini?.model ?? ""}`}</span></div>
        <div className="notice compact gemini-assist"><Bot size={17}/><div><strong>Sugestão de resposta com Gemini</strong><p>{gemini?.configured ? `Modelo ${gemini.model}. A conversa será enviada ao Gemini para gerar uma sugestão; nada é enviado ao WhatsApp automaticamente.` : "Configure GEMINI_API_KEY no ambiente do servidor para ativar sugestões."}</p><button className="button secondary" type="button" disabled={busy || !gemini?.configured || current.aiPaused || current.optedOut || current.status === "closed"} onClick={() => void requestSuggestion()}><Sparkles size={14}/>{busy ? "Gerando…" : "Gerar sugestão"}</button></div></div>
        {suggestion && <div className="settings-card gemini-suggestion" role="status"><div className="eyebrow">SUGESTÃO GEMINI · REVISE ANTES DE USAR</div><p><strong>Resumo:</strong> {suggestion.summary}</p><p><strong>Próximo passo:</strong> {suggestion.nextStep}</p>{suggestion.requiresHuman ? <p>Esta conversa precisa de atendimento humano. Não use uma resposta sugerida para envio.</p> : <><blockquote>{suggestion.reply}</blockquote><button className="button secondary" type="button" disabled={busy || current.status === "closed" || current.optedOut} onClick={() => { setBody(suggestion.reply); setSendReal(false); setSimulateInbound(false); }}>Usar no campo de resposta</button></>}</div>}
        <div className="message-timeline">{messages.length === 0 ? <div className="empty"><p>Sem mensagens registradas.</p><p>{isDemoMode ? "Use o simulador local para testar os fluxos." : "As mensagens aparecerão aqui quando chegarem pelo webhook da Z-API."}</p></div> : messages.map((message) => <article key={message.id} className={`message-bubble ${message.direction === "inbound" ? "inbound" : message.direction === "internal" ? "internal" : "outbound"}`}><div className="message-meta">{message.author === "seller" ? "Você" : message.author === "contact" ? current.companyName : "Nota interna"}</div><p>{message.body}</p><small>{new Date(message.createdAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone: "America/Sao_Paulo" })} {message.direction === "outbound" && <CheckCheck size={13}/>} {message.simulated ? " · SIMULADA" : message.status !== "received" ? ` · ${message.status}` : ""}</small></article>)}</div>
        <form className="inbox-note-form" onSubmit={(e) => void addNote(e)}><StickyNote size={15}/><input value={note} maxLength={2000} onChange={(e) => setNote(e.target.value)} placeholder="Adicionar nota interna (privada)"/><button className="button secondary" disabled={busy || !note.trim()}>Salvar nota</button></form>
        {(isDemoMode || zapi?.enabled) && <form className="inbox-compose" onSubmit={(e) => void submitMessage(e)}>{isDemoMode ? <label className="simulator-toggle"><input type="checkbox" checked={simulateInbound} onChange={(e) => { setSimulateInbound(e.target.checked); setSendReal(false); }}/>{simulateInbound ? "Simular mensagem recebida" : "Simular resposta enviada"}</label> : <label className="simulator-toggle"><input type="checkbox" checked={sendReal} onChange={(e) => setSendReal(e.target.checked)} disabled={busy || current.optedOut}/>{sendReal ? "Enviar resposta real via Z-API" : "Marque para habilitar envio real"}</label>}<textarea value={body} onChange={(e) => setBody(e.target.value)} maxLength={4000} rows={3} placeholder={simulateInbound ? "Texto de entrada de teste." : current.optedOut ? "Contato bloqueado: envio desabilitado." : sendReal ? "Resposta real · janela de 24h após mensagem recebida" : "Escreva uma resposta para revisão"} disabled={busy || current.status === "closed" || (!simulateInbound && current.optedOut)}/><button className="button primary" aria-label={busy ? "Registrando mensagem" : simulateInbound ? "Registrar entrada simulada" : sendReal ? "Enviar mensagem via Z-API" : "Registrar saída simulada"} title={busy ? "Registrando mensagem" : simulateInbound ? "Registrar entrada simulada" : sendReal ? "Enviar mensagem via Z-API" : "Registrar saída simulada"} disabled={busy || !body.trim() || current.status === "closed" || (!simulateInbound && current.optedOut) || (!isDemoMode && !sendReal) || (sendReal && !zapi?.enabled)}><Send size={14}/>{busy ? "Registrando…" : simulateInbound ? "Registrar entrada simulada" : sendReal ? "Enviar via Z-API" : "Registrar saída simulada"}</button></form>}
      </>}</section>
    </section>
    <section className="settings-card inbox-lead-picker"><div><h2>Abrir conversa para lead</h2><p>A conversa fica ligada ao lead local do workspace. Somente contatos já existentes podem ser vinculados.</p></div><select value="" onChange={(e) => { if (e.target.value) void createConversation(e.target.value); }} disabled={busy}><option value="">Selecionar lead…</option>{leads.map((lead) => <option value={lead.id} key={lead.id}>{lead.companyName} {lead.optedOutAt ? "· contato bloqueado" : ""}</option>)}</select></section>
  </div>;
}
