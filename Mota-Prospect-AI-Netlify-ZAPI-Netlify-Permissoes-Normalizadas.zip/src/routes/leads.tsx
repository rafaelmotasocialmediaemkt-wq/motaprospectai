import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type ChangeEvent } from "react";
import { Download, Plus, Search } from "lucide-react";
import type { Lead, LeadStage } from "../domain/leads/lead";
import { normalizeCompany } from "../domain/leads/lead";
import { LEAD_STAGES } from "../domain/leads/lead";
import { createLeadSchema } from "../application/leads/lead-service";
import { leadService as service } from "../infrastructure/leads/lead-service";
import { isDemoMode } from "../infrastructure/netlify/mode";

export const Route = createFileRoute("/leads")({ component: LeadsPage });
const stageName: Record<LeadStage, string> = { new: "Novo", qualifying: "Qualificando", qualified: "Qualificado", contact_authorized: "Contato autorizado", contacted: "Contatado", responded: "Respondeu", meeting_scheduled: "Reunião marcada", proposal: "Proposta", won: "Ganho", lost: "Perdido", archived: "Arquivado" };

function LeadsPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [query, setQuery] = useState("");
  const [stageFilter, setStageFilter] = useState<LeadStage | "all">("all");
  const [reviewFilter, setReviewFilter] = useState<Lead["reviewStatus"] | "all">("pending");
  const [page, setPage] = useState(0);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Lead | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [importInfo, setImportInfo] = useState("");
  const [importPreview, setImportPreview] = useState<{ fileName: string; rows: Record<string, string | null>[]; skipped: number } | null>(null);
  async function refresh() {
    setLoading(true); setError("");
    try { setLeads(await service.list()); } catch (cause) { setError(cause instanceof Error ? cause.message : "Falha ao carregar leads."); }
    finally { setLoading(false); }
  }
  useEffect(() => { void refresh(); }, []);
  const filtered = useMemo(() => leads.filter((lead) => {
    const matches = `${lead.companyName} ${lead.contactName ?? ""} ${lead.email ?? ""} ${lead.segment ?? ""} ${lead.city ?? ""}`.toLocaleLowerCase("pt-BR").includes(query.toLocaleLowerCase("pt-BR"));
    return matches && (stageFilter === "all" || lead.stage === stageFilter) && (reviewFilter === "all" || lead.reviewStatus === reviewFilter);
  }), [leads, query, stageFilter, reviewFilter]);
  const pageSize = 25;
  const rows = filtered.slice(page * pageSize, (page + 1) * pageSize);
  async function changeStage(lead: Lead, stage: LeadStage) {
    setBusyId(lead.id); setError("");
    try { const updated = await service.move(lead.id, stage); setLeads((all) => all.map((row) => row.id === updated.id ? updated : row)); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível alterar a etapa."); }
    finally { setBusyId(null); }
  }
  async function suppressContact(lead: Lead) {
    if (lead.optedOutAt || !window.confirm(`Bloquear abordagens futuras para ${lead.companyName}?`)) return;
    setBusyId(lead.id); setError("");
    try { const updated = await service.suppressContact(lead.id); setLeads((all) => all.map((row) => row.id === updated.id ? updated : row)); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível bloquear o contato."); }
    finally { setBusyId(null); }
  }
  async function reviewLead(lead: Lead, status: Lead["reviewStatus"]) {
    const labels = { approved: "aprovar para o próximo passo comercial", rejected: "rejeitar", pending: "retornar à fila de revisão", duplicate: "marcar como duplicado" };
    if (!window.confirm(`Confirmar ${labels[status]} para ${lead.companyName}?`)) return;
    setBusyId(lead.id); setError("");
    try { const updated = await service.review(lead.id, status); setLeads((all) => all.map((row) => row.id === updated.id ? updated : row)); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível registrar a revisão."); }
    finally { setBusyId(null); }
  }
  async function approveAllPending() {
    const pending = leads.filter((lead) => lead.reviewStatus === "pending");
    if (!pending.length || !window.confirm(`Aprovar todos os ${pending.length} leads pendentes deste workspace para o próximo passo comercial?`)) return;
    setBulkBusy(true); setError("");
    try {
      const approved = await service.approvePending();
      const byId = new Map(approved.map((lead) => [lead.id, lead]));
      setLeads((all) => all.map((lead) => byId.get(lead.id) ?? lead));
      setImportInfo(`${approved.length} lead(s) aprovado(s).`);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível aprovar os leads."); }
    finally { setBulkBusy(false); }
  }
  function exportCsv() {
    if (!leads.length) return;
    const columns: (keyof Lead)[] = ["companyName", "contactName", "email", "phone", "segment", "city", "state", "source", "stage", "createdAt"];
    const csv = [columns.join(";"), ...filtered.map((lead) => columns.map((key) => csvCell(String(lead[key] ?? ""))).join(";"))].join("\r\n");
    const url = URL.createObjectURL(new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a"); link.href = url; link.download = "mota-leads.csv"; link.click(); URL.revokeObjectURL(url);
  }
  async function importCsv(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]; event.target.value = ""; setImportInfo("");
    if (!file) return;
    if (file.size > 1_000_000) { setError("Arquivo CSV excede o limite de 1 MB."); return; }
    try {
      const parsed = parseCsv(await file.text());
      if (parsed.length < 2 || parsed.length > 501) throw new Error("Use um cabeçalho e até 500 linhas de dados.");
      const header = parsed[0].map((value) => value.trim().toLocaleLowerCase("pt-BR"));
      const companyColumn = header.indexOf("companyname") >= 0 ? header.indexOf("companyname") : header.indexOf("empresa");
      if (companyColumn < 0) throw new Error("Inclua a coluna companyName ou empresa no cabeçalho.");
      const index = (name: string) => header.indexOf(name);
      const fields = (row: string[]) => ({ companyName: row[companyColumn] ?? "", contactName: at(row, index("contactname"), index("contato")), email: at(row, index("email")), phone: at(row, index("phone"), index("telefone")), segment: at(row, index("segment"), index("segmento")), city: at(row, index("city"), index("cidade")), state: at(row, index("state"), index("estado")) });
      const candidates: Record<string, string | null>[] = []; let skipped = 0;
      const seen = new Set(leads.flatMap((lead) => duplicateKeys(lead.companyName, lead.email, lead.phone)));
      for (const row of parsed.slice(1)) {
        if (!row.some((value) => value.trim())) { skipped++; continue; }
        const candidate = fields(row); const validation = createLeadSchema.safeParse(candidate);
        const keys = duplicateKeys(candidate.companyName, candidate.email, candidate.phone);
        if (!validation.success || !keys.length || keys.some((key) => seen.has(key))) { skipped++; continue; }
        keys.forEach((key) => seen.add(key)); candidates.push(candidate);
      }
      setImportPreview({ fileName: file.name, rows: candidates, skipped });
    } catch (cause) { setError(cause instanceof Error ? cause.message : "CSV inválido."); }
  }
  async function confirmImport() {
    if (!importPreview) return;
    setBusyId("csv"); let created = 0; let skipped = importPreview.skipped;
    for (const row of importPreview.rows) { try { await service.create(row); created++; } catch { skipped++; } }
    setBusyId(null); setImportPreview(null); setImportInfo(`Importação concluída: ${created} criado(s), ${skipped} ignorado(s) por validação ou duplicidade.`); await refresh();
  }
  return <div className="page">
    <header className="topbar"><div><div className="eyebrow">PROSPECÇÃO</div><h1>Leads</h1><p>{!isDemoMode ? "Dados isolados pela sessão autenticada no servidor." : "Registros locais de demonstração; nenhum dado é sincronizado externamente."}</p></div><div className="toolbar-actions"><label className="button secondary file-button">Importar CSV<input type="file" accept=".csv,text/csv" onChange={(event) => void importCsv(event)} /></label><button className="button secondary" onClick={exportCsv} disabled={!filtered.length}><Download size={15} /> Exportar CSV</button><button className="button primary" onClick={() => { setEditing(null); setOpen(true); }}><Plus size={17} /> Novo lead</button></div></header>
    {isDemoMode && <div className="notice compact"><span className="badge badge-warn">DEMO</span><p>Armazenamento deste navegador. Registros são fictícios/locais e não representam o banco compartilhado.</p></div>}
    {error && <div className="form-error notice-error" role="alert">{error}</div>}{importInfo && <div className="notice compact success-notice" role="status">{importInfo}</div>}
    <div className="table-tools"><label className="search"><Search size={16} /><input aria-label="Buscar leads" placeholder="Buscar empresa, contato ou local" value={query} onChange={(event) => { setQuery(event.target.value); setPage(0); }} /></label><select aria-label="Filtrar por revisão" value={reviewFilter} onChange={(event) => { setReviewFilter(event.target.value as Lead["reviewStatus"] | "all"); setPage(0); }}><option value="pending">Aguardando revisão</option><option value="approved">Aprovados</option><option value="rejected">Rejeitados</option><option value="duplicate">Duplicados</option><option value="all">Todas as revisões</option></select><select aria-label="Filtrar por etapa" value={stageFilter} onChange={(event) => { setStageFilter(event.target.value as LeadStage | "all"); setPage(0); }}><option value="all">Todas as etapas</option>{LEAD_STAGES.map((stage) => <option key={stage} value={stage}>{stageName[stage]}</option>)}</select><span>{filtered.length} registro(s)</span><button className="button secondary" disabled={bulkBusy || !leads.some((lead) => lead.reviewStatus === "pending")} onClick={() => void approveAllPending()}>{bulkBusy ? "Aprovando…" : `Aprovar todos (${leads.filter((lead) => lead.reviewStatus === "pending").length})`}</button></div>
    <div className="table-wrap"><table><thead><tr><th>Empresa / Evidência</th><th>Contato</th><th>Segmento</th><th>Local</th><th>Revisão</th><th>Etapa comercial</th><th>Ações</th></tr></thead><tbody>{rows.map((lead) => <tr key={lead.id}><td><strong>{lead.companyName}</strong><small>{lead.source}{lead.source === "public_search" ? " · " + (lead.notes?.split("\n").find((line) => line.startsWith("URL pública:"))?.replace("URL pública: ", "") ?? "fonte não identificada") : ""}</small>{lead.optedOutAt && <small className="badge badge-warn">Contato bloqueado</small>}</td><td>{lead.contactName ?? "—"}<small>{lead.phone ?? lead.email ?? ""}</small></td><td>{lead.segment ?? "—"}</td><td>{[lead.city, lead.state].filter(Boolean).join(" / ") || "—"}</td><td><span className={`badge ${lead.reviewStatus === "approved" ? "badge-success" : lead.reviewStatus === "pending" ? "badge-warn" : "badge-neutral"}`}>{({ pending: "Pendente", approved: "Aprovado", rejected: "Rejeitado", duplicate: "Duplicado" })[lead.reviewStatus]}</span></td><td><select aria-label={`Etapa de ${lead.companyName}`} value={lead.stage} disabled={busyId === lead.id} onChange={(event) => void changeStage(lead, event.target.value as LeadStage)}>{LEAD_STAGES.map((stage) => <option key={stage} value={stage}>{stageName[stage]}</option>)}</select></td><td><button className="text-button" onClick={() => { setEditing(lead); setOpen(true); }}>Editar</button>{lead.reviewStatus === "pending" && <><button className="text-button" disabled={busyId === lead.id} onClick={() => void reviewLead(lead, "approved")}>Aprovar</button><button className="text-button" disabled={busyId === lead.id} onClick={() => void reviewLead(lead, "rejected")}>Rejeitar</button></>}{!lead.optedOutAt && <button className="text-button" disabled={busyId === lead.id} onClick={() => void suppressContact(lead)}>Bloquear contato</button>}</td></tr>)}</tbody></table>{loading ? <div className="empty">Carregando leads…</div> : rows.length === 0 && <div className="empty">{error ? "Não foi possível carregar os registros." : "Nenhum lead encontrado."}</div>}</div>
    {filtered.length > pageSize && <div className="pagination"><button className="button secondary" disabled={page === 0} onClick={() => setPage((value) => value - 1)}>Anterior</button><span>Página {page + 1} de {Math.ceil(filtered.length / pageSize)}</span><button className="button secondary" disabled={(page + 1) * pageSize >= filtered.length} onClick={() => setPage((value) => value + 1)}>Próxima</button></div>}
    {open && <LeadDialog lead={editing} onClose={() => setOpen(false)} onSaved={(lead) => { setLeads((all) => editing ? all.map((row) => row.id === lead.id ? lead : row) : [lead, ...all]); setOpen(false); }} />}
    {importPreview && <div className="modal-backdrop" role="presentation"><section className="modal" role="dialog" aria-modal="true" aria-labelledby="csv-preview-title"><div className="modal-head"><div><h2 id="csv-preview-title">Prévia da importação</h2><p>{importPreview.fileName} · {importPreview.rows.length} linha(s) válida(s) · {importPreview.skipped} ignorada(s)</p></div><button className="icon-button" onClick={() => setImportPreview(null)} aria-label="Cancelar importação">×</button></div><div className="table-wrap"><table><thead><tr><th>Empresa</th><th>Contato</th><th>E-mail</th></tr></thead><tbody>{importPreview.rows.slice(0, 5).map((row, index) => <tr key={`${row.companyName}-${index}`}><td>{row.companyName}</td><td>{row.contactName || "—"}</td><td>{row.email || "—"}</td></tr>)}</tbody></table></div>{importPreview.rows.length > 5 && <p className="preview-note">Prévia das primeiras 5 linhas. A importação contém {importPreview.rows.length} registros.</p>}{importPreview.rows.length === 0 && <p className="preview-note">Nenhuma linha válida para importar.</p>}<div className="form-actions"><button className="button secondary" onClick={() => setImportPreview(null)}>Cancelar</button><button className="button primary" disabled={!importPreview.rows.length || busyId === "csv"} onClick={() => void confirmImport()}>{busyId === "csv" ? "Importando…" : "Confirmar importação"}</button></div></section></div>}
  </div>;
}

function LeadDialog({ lead, onClose, onSaved }: { lead: Lead | null; onClose: () => void; onSaved: (lead: Lead) => void }) {
  const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    try { const input = Object.fromEntries(new FormData(event.currentTarget)); const saved = lead ? await service.update(lead.id, input) : await service.create(input); onSaved(saved); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível salvar."); }
    finally { setBusy(false); }
  }
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="lead-dialog-title"><div className="modal-head"><div><h2 id="lead-dialog-title">{lead ? "Editar lead" : "Adicionar lead"}</h2><p>{lead?.isDemo || isDemoMode ? "Registro local de demonstração." : "Dados do workspace autenticado."}</p></div><button className="icon-button" onClick={onClose} aria-label="Fechar">×</button></div><form onSubmit={(event) => void submit(event)} className="form-grid"><label>Empresa *<input name="companyName" required minLength={2} maxLength={160} defaultValue={lead?.companyName} /></label><label>Contato<input name="contactName" maxLength={160} defaultValue={lead?.contactName ?? ""} /></label><label>E-mail<input name="email" type="email" defaultValue={lead?.email ?? ""} /></label><label>Telefone<input name="phone" inputMode="tel" maxLength={40} defaultValue={lead?.phone ?? ""} /></label><label>Segmento<input name="segment" maxLength={100} defaultValue={lead?.segment ?? ""} /></label><label>Cidade<input name="city" maxLength={100} defaultValue={lead?.city ?? ""} /></label><label>Estado<input name="state" maxLength={2} defaultValue={lead?.state ?? ""} /></label><label className="full">Observações<textarea name="notes" rows={3} maxLength={3000} defaultValue={lead?.notes ?? ""} /></label>{error && <p className="form-error full" role="alert">{error}</p>}<div className="form-actions full"><button type="button" className="button secondary" onClick={onClose}>Cancelar</button><button className="button primary" type="submit" disabled={busy}>{busy ? "Salvando…" : lead ? "Salvar alterações" : "Salvar lead"}</button></div></form></section></div>;
}

function csvCell(value: string): string { return `"${value.replaceAll('"', '""')}"`; }
function duplicateKeys(companyName: string, email?: string | null, phone?: string | null): string[] {
  return [`company:${normalizeCompany(companyName)}`, ...(email?.trim() ? [`email:${email.trim().toLocaleLowerCase("pt-BR")}`] : []), ...(phone?.replace(/\D/g, "") ? [`phone:${phone.replace(/\D/g, "")}`] : [])];
}
function at(row: string[], ...indices: number[]): string | null { const index = indices.find((value) => value >= 0); return index === undefined ? null : row[index]?.trim() || null; }
function parseCsv(text: string): string[][] {
  const rows: string[][] = []; let row: string[] = []; let cell = ""; let quoted = false;
  const source = text.replace(/^\uFEFF/, "");
  const headerEnd = source.search(/[\r\n]/); const headerLine = headerEnd < 0 ? source : source.slice(0, headerEnd);
  let delimiter = ";"; let commas = 0; let semicolons = 0; let inHeaderQuote = false;
  for (let i = 0; i < headerLine.length; i++) { if (headerLine[i] === '"') { if (inHeaderQuote && headerLine[i + 1] === '"') i++; else inHeaderQuote = !inHeaderQuote; } else if (!inHeaderQuote && headerLine[i] === ",") commas++; else if (!inHeaderQuote && headerLine[i] === ";") semicolons++; }
  if (commas > semicolons) delimiter = ",";
  for (let i = 0; i < source.length; i++) {
    const char = source[i];
    if (quoted) { if (char === '"' && source[i + 1] === '"') { cell += '"'; i++; } else if (char === '"') quoted = false; else cell += char; }
    else if (char === '"') quoted = true;
    else if (char === delimiter) { row.push(cell); cell = ""; }
    else if (char === "\n" || char === "\r") { if (char === "\r" && source[i + 1] === "\n") i++; row.push(cell); rows.push(row); row = []; cell = ""; }
    else cell += char;
  }
  if (quoted) throw new Error("CSV possui aspas sem fechamento.");
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows;
}
