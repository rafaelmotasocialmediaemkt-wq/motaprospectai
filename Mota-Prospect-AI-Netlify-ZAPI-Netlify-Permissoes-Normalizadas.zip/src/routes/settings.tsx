import { createFileRoute, Link } from "@tanstack/react-router";
import { AlertTriangle, BriefcaseBusiness, Check, Copy, LoaderCircle, Pause, Play, Save, Sparkles } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { isDemoMode } from "../infrastructure/netlify/mode";
import { endWorkday, getOperatingSettings, saveOperatingSettings, setAgentEnabled, startWorkday } from "../infrastructure/netlify/operating-controls";
import { runPublicProspectingShift } from "../infrastructure/netlify/prospecting-workflow";
import { getGeminiReplyStatus } from "../infrastructure/netlify/gemini-functions";

export const Route = createFileRoute("/settings")({ component: Settings });

type OperatingSettings = {
  workspaceId: string | null;
  aiEnabled: boolean; shiftStatus: "idle" | "active"; shiftStartedAt: string | null; shiftEndedAt: string | null;
  businessSegment: string; targetLocations: string; searchTerms: string; maxCandidatesPerShift: number;
  dailyBudgetCents: number; workdayStart: string; workdayEnd: string; timezone: string;
  requireHumanReview: boolean; calendlyBookingUrl: string; updatedAt: string | null;
};

const initial: OperatingSettings = {
  workspaceId: null,
  aiEnabled: false, shiftStatus: "idle", shiftStartedAt: null, shiftEndedAt: null,
  businessSegment: "", targetLocations: "", searchTerms: "", maxCandidatesPerShift: 20,
  dailyBudgetCents: 0, workdayStart: "09:00", workdayEnd: "18:00", timezone: "America/Sao_Paulo",
  requireHumanReview: true, calendlyBookingUrl: "", updatedAt: null,
};

function Settings() {
  const [settings, setSettings] = useState(initial);
  const [loading, setLoading] = useState(!isDemoMode);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [gemini, setGemini] = useState<{ configured: boolean; model: string } | null>(null);
  const [workspaceCopied, setWorkspaceCopied] = useState(false);

  useEffect(() => {
    if (isDemoMode) return;
    void Promise.all([getOperatingSettings({ data: {} }), getGeminiReplyStatus({ data: {} })]).then(([operating, status]) => { setSettings(operating); setGemini(status); }).catch((cause: unknown) => setError(cause instanceof Error ? cause.message : "Falha ao carregar configurações.")).finally(() => setLoading(false));
  }, []);

  function change<K extends keyof OperatingSettings>(key: K, value: OperatingSettings[K]) {
    setSettings((previous) => ({ ...previous, [key]: value }));
  }

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setError(""); setNotice("");
    try {
      const saved = await saveOperatingSettings({ data: {
        businessSegment: settings.businessSegment, targetLocations: settings.targetLocations, searchTerms: settings.searchTerms,
        maxCandidatesPerShift: settings.maxCandidatesPerShift, dailyBudgetCents: settings.dailyBudgetCents,
        workdayStart: settings.workdayStart, workdayEnd: settings.workdayEnd, timezone: settings.timezone,
        requireHumanReview: settings.requireHumanReview, calendlyBookingUrl: settings.calendlyBookingUrl,
      } });
      setSettings(saved); setNotice("Preferências salvas no Netlify Database.");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível salvar as configurações."); }
    finally { setBusy(false); }
  }

  async function updateControl(action: "ai-on" | "ai-off" | "shift-start" | "shift-end") {
    if (action === "shift-start" && !window.confirm("Iniciar o expediente e fazer uma pesquisa pública agora? Enquanto estiver ativo, o agendador fará novas pesquisas a cada 15 minutos, nos dias úteis e dentro do horário configurado. O limite é de 6 pesquisas públicas e 30 resultados candidatos por dia, e o provedor pode cobrar. Leads ficam para revisão; nenhuma mensagem será enviada.")) return;
    setBusy(true); setError(""); setNotice("");
    try {
      const next = action === "ai-on" ? await setAgentEnabled({ data: { enabled: true } })
        : action === "ai-off" ? await setAgentEnabled({ data: { enabled: false } })
          : action === "shift-start" ? await startWorkday({ data: {} })
            : await endWorkday({ data: {} });
      setSettings(next);
      if (action === "shift-start") {
        try {
          const result = await runPublicProspectingShift({ data: {} });
          setNotice(`Pesquisa inicial concluída: ${result.candidatesSeen} resultado(s) público(s), ${result.leadsCreated} lead(s) novo(s). O agendador continuará a cada 15 minutos durante o horário de expediente, até o limite diário. Leads aguardam revisão no painel; nenhuma mensagem é enviada.`);
        } catch (cause) {
          await endWorkday({ data: {} }).then(setSettings).catch(() => undefined);
          throw new Error(`A pesquisa não concluiu e o expediente foi encerrado. ${cause instanceof Error ? cause.message : "Verifique as integrações e preferências."}`);
        }
      }
      if (action !== "shift-start") setNotice(action === "ai-on" ? `Assistência Gemini ativada (${gemini?.model ?? "Gemini"}). A IA gera sugestões revisadas por humanos no Inbox; não faz prospecção ou envio automático.`
        : action === "ai-off" ? "IA pausada no controle operacional do servidor."
          : "Expediente encerrado no controle operacional do servidor.");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível atualizar o controle operacional."); }
    finally { setBusy(false); }
  }

  return <div className="page">
    <header className="topbar"><div><div className="eyebrow">ADMINISTRAÇÃO</div><h1>Operação e configurações</h1><p>Preferências e controles são editáveis e persistidos por conta no Netlify Database.</p></div></header>
    {isDemoMode && <div className="notice"><AlertTriangle size={18} /><div><strong>Modo demonstração</strong><p>Controles de servidor e configurações compartilhadas exigem autenticação e Netlify Database; o modo DEMO não salva estes ajustes.</p></div></div>}
    {error && <div className="form-error notice-error" role="alert">{error}{error.includes("SerpApi respondeu HTTP 401") && <> <Link to="/integrations">Abrir Integrações e atualizar a chave SerpApi</Link>.</>}</div>}
    {notice && <div className="notice" role="status"><Sparkles size={18} /><div><strong>Estado atualizado</strong><p>{notice}</p></div></div>}
    {loading ? <section className="settings-card"><LoaderCircle className="spin" /><span>Carregando preferências…</span></section> : <>
      {!isDemoMode && <section className="settings-card workspace-id-card"><div className="settings-icon"><BriefcaseBusiness /></div><div className="settings-control-copy"><h2>ID do workspace</h2><p>Use este UUID como <code>YCLOUD_WORKSPACE_ID</code> nas variáveis server-side do Netlify.</p><code className="workspace-id-value">{settings.workspaceId ?? "Não disponível nesta sessão"}</code></div><button className="button secondary" type="button" disabled={!settings.workspaceId} onClick={() => { if (!settings.workspaceId) return; void navigator.clipboard.writeText(settings.workspaceId).then(() => { setWorkspaceCopied(true); window.setTimeout(() => setWorkspaceCopied(false), 2000); }).catch(() => setError("Não foi possível copiar. Selecione e copie o UUID manualmente.")); }}>{workspaceCopied ? <Check size={15} /> : <Copy size={15} />}{workspaceCopied ? "Copiado" : "Copiar UUID"}</button></section>}
      <section className="settings-card settings-controls">
        <div className="settings-icon"><Sparkles /></div><div className="settings-control-copy"><h2>Motor de IA · Gemini</h2><p>{gemini?.configured ? `API configurada no servidor · ${gemini.model}. Use a assistência para criar sugestões revisáveis no Inbox YCloud.` : "GEMINI_API_KEY ainda não está configurada no ambiente deste servidor."} A ativação libera apenas sugestões de resposta; não prospecta nem envia mensagens automaticamente.</p><span className={`badge ${settings.aiEnabled && gemini?.configured ? "badge-success" : "badge-neutral"}`}>{settings.aiEnabled && gemini?.configured ? `ATIVA · ${gemini.model}` : gemini?.configured ? "CONFIGURADO · PAUSADO" : "CHAVE PENDENTE"}</span></div>
        <div className="settings-actions"><button className="button primary" type="button" onClick={() => void updateControl("ai-on")} disabled={isDemoMode || busy || settings.aiEnabled || !gemini?.configured}><Play size={15} />Ativar Gemini</button><button className="button secondary" type="button" onClick={() => void updateControl("ai-off")} disabled={isDemoMode || busy || !settings.aiEnabled}><Pause size={15} />Pausar Gemini</button></div>
      </section>
      <section className="settings-card settings-controls">
        <div className="settings-icon"><BriefcaseBusiness /></div><div className="settings-control-copy"><h2>Expediente</h2><p>{settings.shiftStatus === "active" ? `Ativo desde ${settings.shiftStartedAt ? new Date(settings.shiftStartedAt).toLocaleString("pt-BR", { timeZone: settings.timezone }) : "agora"}. Pesquisa automática a cada 15 minutos, de segunda a sexta, dentro do horário configurado.` : "Ao iniciar, o app faz uma pesquisa SerpApi; enquanto o expediente estiver ativo, novas buscas são executadas pelo agendador."}</p><span className={`badge ${settings.shiftStatus === "active" ? "badge-success" : "badge-neutral"}`}>{settings.shiftStatus === "active" ? "ATIVO · CICLOS AUTOMÁTICOS" : "ENCERRADO"}</span></div>
        <div className="settings-actions"><button className="button primary" type="button" onClick={() => void updateControl("shift-start")} disabled={isDemoMode || busy || settings.shiftStatus === "active"}><Play size={15} />Iniciar expediente</button><button className="button secondary" type="button" onClick={() => void updateControl("shift-end")} disabled={isDemoMode || busy || settings.shiftStatus !== "active"}><Pause size={15} />Encerrar expediente</button></div>
      </section>
      <div className="notice settings-limitation"><AlertTriangle size={18} /><div><strong>Como a prospecção é executada</strong><p>Com o expediente ativo, o agendador publicado pesquisa a cada 15 minutos nos dias úteis e horários configurados. Há limite atômico de 6 consultas SerpApi e 30 resultados candidatos por dia, até 20 por busca; até 4 CNPJs podem ser consultados por busca. Novos leads são cadastrados no painel para revisão humana. Nenhuma mensagem ou gravação na MachtKin é automática.</p></div></div>
      <form className="settings-form settings-card" onSubmit={(event) => void save(event)}>
        <div className="settings-section-title"><div className="settings-icon"><BriefcaseBusiness /></div><div><h2>Preferências de prospecção</h2><p>Filtros e limites usados na busca SerpApi do início de expediente.</p></div></div>
        <div className="settings-form-grid">
          <label>Segmento de empresas<input maxLength={160} value={settings.businessSegment} onChange={(event) => change("businessSegment", event.target.value)} placeholder="Ex.: serviços B2B" disabled={isDemoMode || busy} /></label>
          <label>Regiões alvo<input maxLength={500} value={settings.targetLocations} onChange={(event) => change("targetLocations", event.target.value)} placeholder="Ex.: São Paulo, SP" disabled={isDemoMode || busy} /></label>
          <label className="settings-full">Termos de pesquisa<textarea maxLength={1000} rows={3} value={settings.searchTerms} onChange={(event) => change("searchTerms", event.target.value)} placeholder="Termos separados por linha ou vírgula" disabled={isDemoMode || busy} /></label>
          <label>Máximo de candidatos por busca<input type="number" required min={1} max={100} value={settings.maxCandidatesPerShift} onChange={(event) => change("maxCandidatesPerShift", Number(event.target.value))} disabled={isDemoMode || busy} /></label>
          <label>Orçamento diário de referência (R$)<input type="number" required min={0} max={100000} step="0.01" value={(settings.dailyBudgetCents / 100).toFixed(2)} onChange={(event) => change("dailyBudgetCents", Math.round(Number(event.target.value) * 100))} disabled={isDemoMode || busy} /><small>Valor maior que zero libera a busca. O gasto SerpApi não é medido aqui; o app limita a 6 consultas públicas por dia.</small></label>
          <label>Início do expediente<input type="time" required value={settings.workdayStart} onChange={(event) => change("workdayStart", event.target.value)} disabled={isDemoMode || busy} /></label>
          <label>Fim do expediente<input type="time" required value={settings.workdayEnd} onChange={(event) => change("workdayEnd", event.target.value)} disabled={isDemoMode || busy} /></label>
          <label>Fuso horário<input required maxLength={64} value={settings.timezone} onChange={(event) => change("timezone", event.target.value)} disabled={isDemoMode || busy} /></label>
        </div>
        <label className="settings-checkbox"><input type="checkbox" checked={settings.requireHumanReview} onChange={(event) => change("requireHumanReview", event.target.checked)} disabled={isDemoMode || busy} />Exigir revisão humana antes de qualquer contato ou gravação de resultado</label>
        <div className="settings-actions"><button className="button primary" type="submit" disabled={isDemoMode || busy}><Save size={15} />{busy ? "Salvando…" : "Salvar preferências"}</button>{settings.updatedAt && <small>Última atualização: {new Date(settings.updatedAt).toLocaleString("pt-BR", { timeZone: settings.timezone })}</small>}</div>
      </form>
    </>}
  </div>;
}
