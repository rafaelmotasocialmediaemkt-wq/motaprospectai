import { createFileRoute } from "@tanstack/react-router";
import { BellRing, HandHelping } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { leadService } from "../infrastructure/leads/lead-service";
import { listHumanHandoffs, requestHumanHandoff, updateHumanHandoff } from "../infrastructure/netlify/handoff-functions";
import type { Lead } from "../domain/leads/lead";

export const Route = createFileRoute("/handoffs")({ component: Handoffs });
type RequestRow = { id: string; leadId: string; companyName: string; status: string; note: string; assignedTo: string | null; canResolve: boolean; createdAt: string };
function Handoffs() {
  const [leads, setLeads] = useState<Lead[]>([]); const [rows, setRows] = useState<RequestRow[]>([]); const [leadId, setLeadId] = useState(""); const [note, setNote] = useState("");
  const [error, setError] = useState(""); const [notice, setNotice] = useState(""); const [permission, setPermission] = useState("default"); const seen = useRef<Set<string> | null>(null);
  const load = useCallback(async (notify = false) => {
    const next = await listHumanHandoffs({ data: {} }) as RequestRow[];
    if (notify && seen.current && typeof Notification !== "undefined" && Notification.permission === "granted") {
      for (const item of next) if (item.status === "pending" && !seen.current.has(item.id)) new Notification("Lead solicitou atendimento humano", { body: item.companyName, tag: item.id });
    }
    seen.current = new Set(next.map((item) => item.id)); setRows(next);
  }, []);
  useEffect(() => {
    setPermission(typeof Notification === "undefined" ? "unsupported" : Notification.permission);
    void Promise.all([leadService.list().then(setLeads), load()]).catch((e) => setError(e instanceof Error ? e.message : "Falha ao carregar solicitações."));
    const timer = window.setInterval(() => { void load(true).catch(() => undefined); }, 30_000);
    return () => window.clearInterval(timer);
  }, [load]);
  async function enableNotifications() { if (typeof Notification === "undefined") { setPermission("unsupported"); return; } const result = await Notification.requestPermission(); setPermission(result); }
  async function create(event: React.FormEvent) { event.preventDefault(); if (!leadId) return; setError(""); setNotice(""); try { await requestHumanHandoff({ data: { leadId, note } }); setLeadId(""); setNote(""); setNotice("Solicitação registrada e disponível para a equipe."); await load(); } catch (e) { setError(e instanceof Error ? e.message : "Não foi possível registrar a solicitação."); } }
  async function act(id: string, action: "assign" | "resolve" | "dismiss") { setError(""); try { await updateHumanHandoff({ data: { id, action } }); await load(); } catch (e) { setError(e instanceof Error ? e.message : "Não foi possível atualizar a solicitação."); } }
  return <div className="page"><header className="topbar"><div><div className="eyebrow">ATENDIMENTO</div><h1>Solicitações de atendimento humano</h1><p>Fila compartilhada entre os logins comerciais. A tela atualiza a cada 30 segundos enquanto estiver aberta.</p></div><button className="button secondary" onClick={() => void enableNotifications()} disabled={permission === "granted" || permission === "unsupported"}><BellRing size={15} />{permission === "granted" ? "Notificações ativas" : permission === "unsupported" ? "Notificações indisponíveis" : "Ativar notificações"}</button></header>
    {permission !== "granted" && <div className="notice"><BellRing size={18} /><div><strong>Notificação do navegador</strong><p>Quando permitidas, notificações aparecem enquanto esta página estiver aberta. Push em segundo plano ou com o navegador fechado requer infraestrutura Web Push e chaves VAPID, ainda não configuradas.</p></div></div>}
    {error && <p className="form-error" role="alert">{error}</p>}{notice && <div className="notice" role="status">{notice}</div>}
    <form className="settings-card handoff-form" onSubmit={(e) => void create(e)}><HandHelping /><label>Lead<select required value={leadId} onChange={(e) => setLeadId(e.target.value)}><option value="">Selecione um lead</option>{leads.filter((l) => !["won", "lost", "archived"].includes(l.stage)).map((l) => <option value={l.id} key={l.id}>{l.companyName}</option>)}</select></label><label>Contexto do atendimento (opcional)<input maxLength={1000} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Ex.: pediu para conversar com uma pessoa" /></label><button className="button primary" disabled={!leadId}>Solicitar atendimento</button></form>
    <section className="team-members"><h2>Fila aberta ({rows.length})</h2>{rows.length === 0 ? <div className="empty-panel"><p>Nenhuma solicitação pendente.</p></div> : rows.map((r) => <article className="settings-card" key={r.id}><div className="settings-control-copy"><strong>{r.companyName}</strong><p>{r.note || "Sem observações"} · {new Date(r.createdAt).toLocaleString("pt-BR")}</p><span className={`badge ${r.status === "assigned" ? "badge-warn" : "badge-neutral"}`}>{r.status === "assigned" ? "EM ATENDIMENTO" : "PENDENTE"}</span></div>{r.status === "pending" && <button className="button primary" onClick={() => void act(r.id, "assign")}>Assumir</button>}{r.status === "assigned" && r.canResolve && <button className="button secondary" onClick={() => void act(r.id, "resolve")}>Concluir</button>}{r.status === "assigned" && !r.canResolve && <small>Atribuída a outra pessoa da equipe</small>}</article>)}</section>
  </div>;
}
