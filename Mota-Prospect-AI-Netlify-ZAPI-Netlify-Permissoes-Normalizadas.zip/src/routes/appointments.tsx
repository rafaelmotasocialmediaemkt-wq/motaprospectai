import { createFileRoute, Link } from "@tanstack/react-router";
import { CalendarDays, ChevronLeft, ChevronRight, ExternalLink, RefreshCw } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { listCalendlyEvents, listProviderSettings } from "../infrastructure/netlify/provider-functions";
import { getOperatingSettings } from "../infrastructure/netlify/operating-controls";
import { isDemoMode } from "../infrastructure/netlify/mode";

export const Route = createFileRoute("/appointments")({ component: Appointments });
type CalendarEvent = { id: string; summary: string; start: string; end: string; eventUrl: string | null; meetUrl: string | null };
const weekdays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

function Appointments() {
  const [month, setMonth] = useState(() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1); });
  const [connected, setConnected] = useState(false); const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [bookingUrl, setBookingUrl] = useState("");
  const [error, setError] = useState(""); const [loading, setLoading] = useState(true);
  const cells = useMemo(() => {
    const first = new Date(month.getFullYear(), month.getMonth(), 1); const start = new Date(first.getFullYear(), first.getMonth(), 1 - first.getDay());
    return Array.from({ length: 42 }, (_, index) => new Date(start.getFullYear(), start.getMonth(), start.getDate() + index));
  }, [month]);
  const monthName = month.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });

  async function load() {
    setLoading(true); setError("");
    try {
      if (isDemoMode) { setConnected(false); setEvents([]); return; }
      const [providers, operating] = await Promise.all([listProviderSettings({ data: {} }), getOperatingSettings({ data: {} })]);
      setBookingUrl(operating.calendlyBookingUrl);
      const active = Boolean(providers.find((row) => row.provider === "calendly")?.connected); setConnected(active);
      if (!active) { setEvents([]); return; }
      const from = new Date(month.getFullYear(), month.getMonth(), 1); const to = new Date(month.getFullYear(), month.getMonth() + 1, 1);
      setEvents(await listCalendlyEvents({ data: { timeMin: from.toISOString(), timeMax: to.toISOString() } }) as CalendarEvent[]);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Não foi possível carregar o Calendly."); }
    finally { setLoading(false); }
  }
  useEffect(() => {
    void load();
    const refreshVisible = () => { if (document.visibilityState === "visible") void load(); };
    const timer = window.setInterval(refreshVisible, 60_000);
    window.addEventListener("focus", refreshVisible);
    document.addEventListener("visibilitychange", refreshVisible);
    return () => { window.clearInterval(timer); window.removeEventListener("focus", refreshVisible); document.removeEventListener("visibilitychange", refreshVisible); };
  }, [month]);

  function eventsForDay(day: Date) {
    const key = localDayKey(day);
    return events.filter((event) => event.start && (event.start.length === 10 ? event.start : localDayKey(new Date(event.start))) === key);
  }
  return <div className="page"><header className="topbar"><div><div className="eyebrow">AGENDA</div><h1>Agendamentos</h1><p>Calendário de eventos agendados pelo Calendly.</p></div><button className="button secondary" onClick={() => void load()} disabled={loading}><RefreshCw size={14}/>{loading ? "Atualizando…" : "Atualizar calendário"}</button></header>
    {bookingUrl && <div className="notice"><CalendarDays size={18}/><div><strong>Agendar pelo Calendly</strong><p>Compartilhe seu link de disponibilidade com o lead.</p><a className="button primary" href={bookingUrl} target="_blank" rel="noreferrer">Abrir Calendly <ExternalLink size={14}/></a></div></div>}
    {error && <div className="form-error notice-error" role="alert">{error}</div>}
    {!connected && <section className="settings-card appointment-card"><div className="settings-icon"><CalendarDays /></div><div><h2>Conecte o Calendly</h2><p>{isDemoMode ? "Saia do modo demonstração para conectar a conta Calendly." : "A conexão só fica ativa depois de salvar as credenciais OAuth Web e autorizar a conta Calendly na página Integrações."}</p><div className="appointment-actions"><Link className="button primary" to="/integrations">Configurar Calendly</Link></div></div><span className="badge badge-neutral">PENDENTE</span></section>}
    <section className="settings-card google-calendar-card">
      <div className="calendar-toolbar"><div><h2>{monthName}</h2><span className={`badge ${connected ? "badge-success" : "badge-neutral"}`}>{connected ? "CALENDLY CONECTADO" : "NÃO CONECTADO"}</span></div><div className="calendar-month-nav"><button className="button secondary" aria-label="Mês anterior" onClick={() => setMonth((d) => new Date(d.getFullYear(), d.getMonth() - 1, 1))}><ChevronLeft size={16}/></button><button className="button secondary" onClick={() => setMonth(() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1); })}>Hoje</button><button className="button secondary" aria-label="Próximo mês" onClick={() => setMonth((d) => new Date(d.getFullYear(), d.getMonth() + 1, 1))}><ChevronRight size={16}/></button></div></div>
      <div className="google-calendar-grid">{weekdays.map((day) => <div className="calendar-weekday" key={day}>{day}</div>)}{cells.map((day) => { const daily = eventsForDay(day); return <div className={`calendar-day ${day.getMonth() !== month.getMonth() ? "calendar-day-muted" : ""} ${localDayKey(day) === localDayKey(new Date()) ? "calendar-day-today" : ""}`} key={localDayKey(day)}><span className="calendar-day-number">{day.getDate()}</span>{daily.slice(0, 3).map((event) => <a className="calendar-event" key={event.id} href={event.meetUrl ?? event.eventUrl ?? undefined} target="_blank" rel="noreferrer" title={event.summary}>{event.start.length > 10 ? `${new Date(event.start).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })} ` : ""}{event.summary}</a>)}{daily.length > 3 && <small>+{daily.length - 3} eventos</small>}</div>; })}</div>
      {loading && <p className="calendar-footnote">Carregando eventos do Calendly…</p>}{!loading && connected && events.length === 0 && <p className="calendar-footnote">Sem eventos neste mês. Os próximos agendamentos aparecerão aqui.</p>}
    </section>
    {connected && <div className="notice"><CalendarDays size={18}/><div><strong>Eventos reais do Calendly</strong><p>Esta visualização lista eventos do calendário principal no mês selecionado. Se estiver vazia, confirme se a conta autorizada é a mesma que contém seus compromissos.</p><Link className="button secondary" to="/integrations">Ver integrações Calendly <ExternalLink size={14}/></Link></div></div>}
    {isDemoMode && <div className="notice"><CalendarDays size={18}/><div><strong>Calendly OAuth não conectado nesta demonstração</strong><p>Use uma implantação conectada ao Netlify Database para persistir a autorização e carregar eventos reais.</p></div></div>}
  </div>;
}

function localDayKey(date: Date): string { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`; }
