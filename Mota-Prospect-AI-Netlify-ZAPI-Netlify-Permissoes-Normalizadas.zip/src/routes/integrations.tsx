import { createFileRoute } from "@tanstack/react-router";
import "../styles-integrations.css";
import "../styles-provider-integrations.css";
import { useCallback, useEffect, useState, type FormEvent } from "react";
import { Check, CircleHelp, Database, LoaderCircle, LockKeyhole, PlugZap, Save, Trash2, Wifi } from "lucide-react";
import { isDemoMode } from "../infrastructure/netlify/mode";
import {
  deleteIntegrationSettings,
  listIntegrationSettings,
  saveIntegrationSettings,
  testIntegrationConnection,
} from "../infrastructure/netlify/integration-functions";
import { ProviderIntegrationsPanel } from "./-provider-integrations-panel";

export const Route = createFileRoute("/integrations")({ component: Integrations });

type Provider = "prospectab" | "machtkin";
type Integration = {
  provider: Provider;
  endpointUrl: string;
  authHeader: string;
  authPrefix: string;
  hasApiKey: boolean;
  lastTestAt: string | null;
  lastTestStatus: string | null;
  lastHttpStatus: number | null;
};
type FormState = Pick<Integration, "endpointUrl" | "authHeader" | "authPrefix"> & { apiKey: string };

const providers: { id: Provider; title: string; description: string }[] = [
  { id: "prospectab", title: "Prospectab", description: "Conexão somente de leitura para testar o endpoint de leads informado." },
  { id: "machtkin", title: "MachtKin CRM", description: "Conexão somente de leitura para testar o endpoint de leads informado." },
];
const defaults: Record<Provider, FormState> = {
  prospectab: { endpointUrl: "https://prospectab.lovable.app/api/public/v1/leads?limit=50", authHeader: "Authorization", authPrefix: "Bearer", apiKey: "" },
  machtkin: { endpointUrl: "https://machtkin.lovable.app/api/public/v1/leads", authHeader: "Authorization", authPrefix: "Bearer", apiKey: "" },
};

function Integrations() {
  const [configs, setConfigs] = useState<Record<Provider, Integration | null>>({ prospectab: null, machtkin: null });
  const [forms, setForms] = useState<Record<Provider, FormState>>(defaults);
  const [busy, setBusy] = useState<Record<string, boolean>>({});
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      if (isDemoMode) return;
      const rows = await listIntegrationSettings({ data: {} });
      const next: Record<Provider, Integration | null> = { prospectab: null, machtkin: null };
      const nextForms = { ...defaults };
      for (const row of rows) {
        const provider = row.provider as Provider;
        next[provider] = row as Integration;
        nextForms[provider] = { endpointUrl: row.endpointUrl, authHeader: row.authHeader, authPrefix: row.authPrefix, apiKey: "" };
      }
      setConfigs(next);
      setForms(nextForms);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível carregar as configurações.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  function setField(provider: Provider, field: keyof FormState, value: string) {
    setForms((previous) => ({ ...previous, [provider]: { ...previous[provider], [field]: value } }));
  }

  async function save(event: FormEvent<HTMLFormElement>, provider: Provider) {
    event.preventDefault();
    setError("");
    setNotice("");
    setBusy((previous) => ({ ...previous, [provider]: true }));
    try {
      await saveIntegrationSettings({ data: { provider, ...forms[provider] } });
      setForms((previous) => ({ ...previous, [provider]: { ...previous[provider], apiKey: "" } }));
      setNotice(`${providers.find((item) => item.id === provider)?.title} salvo. A chave fica cifrada no banco e não é exibida novamente.`);
      await load();
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "";
      setError(message.includes("MOTA_INTEGRATION_ENCRYPTION_KEY")
        ? "A chave de criptografia do servidor não está configurada. Gere uma chave com: node -e \"console.log(require('node:crypto').randomBytes(32).toString('hex'))\". Cadastre o resultado como variável secreta MOTA_INTEGRATION_ENCRYPTION_KEY no Netlify (escopo Functions) e publique um novo deploy. Não salve API keys sem essa proteção."
        : message || "Não foi possível salvar a integração.");
    } finally {
      setBusy((previous) => ({ ...previous, [provider]: false }));
    }
  }

  async function test(provider: Provider) {
    setError("");
    setNotice("");
    setBusy((previous) => ({ ...previous, [`test-${provider}`]: true }));
    try {
      const result = await testIntegrationConnection({ data: { provider } });
      const message = result.status === "connected"
        ? `Endpoint respondeu HTTP ${result.httpStatus}. Nenhum lead foi importado.`
        : result.httpStatus
          ? `O endpoint respondeu HTTP ${result.httpStatus}. Confira o header e a credencial; nenhum dado foi importado.`
          : "Não foi possível conectar. Confira a URL e a disponibilidade do serviço.";
      setNotice(message);
      await load();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível testar a conexão.");
    } finally {
      setBusy((previous) => ({ ...previous, [`test-${provider}`]: false }));
    }
  }

  async function remove(provider: Provider) {
    if (!window.confirm("Remover a URL e a API key cifrada desta integração?")) return;
    setError("");
    setNotice("");
    setBusy((previous) => ({ ...previous, [`remove-${provider}`]: true }));
    try {
      await deleteIntegrationSettings({ data: { provider } });
      setNotice(`${providers.find((item) => item.id === provider)?.title} removido.`);
      await load();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível remover a integração.");
    } finally {
      setBusy((previous) => ({ ...previous, [`remove-${provider}`]: false }));
    }
  }

  return <div className="page">
    <header className="topbar"><div><div className="eyebrow">SERVIÇOS</div><h1>Integrações</h1><p>Configure endpoints e credenciais sem expor chaves ao navegador após salvar.</p></div></header>
    {isDemoMode && <div className="notice" role="status"><LockKeyhole size={18} /><div><strong>Modo de demonstração</strong><p>As configurações são privadas por usuário e ficam no Netlify Database. O modo DEMO não salva credenciais.</p></div></div>}
    {error && <div className="form-error notice-error" role="alert">{error}</div>}
    {notice && <div className="notice" role="status"><Check size={18} /><div><strong>Operação concluída</strong><p>{notice}</p></div></div>}
    {loading ? <section className="empty-panel"><LoaderCircle className="spin" size={22} /><h2>Carregando integrações…</h2></section> : <div className="integration-config-grid">
      {providers.map(({ id, title, description }) => {
        const config = configs[id];
        const isBusy = Boolean(busy[id] || busy[`test-${id}`] || busy[`remove-${id}`]);
        return <section className="integration-config-card" key={id}>
          <div className="integration-config-head"><div className="integration-icon blue"><PlugZap size={19} /></div><div><h2>{title}</h2><p>{description}</p></div><span className={`badge ${config?.lastTestStatus === "connected" ? "badge-success" : "badge-neutral"}`}>{config?.lastTestStatus === "connected" ? "CONECTADO" : config?.hasApiKey ? "CONFIGURADO" : "PENDENTE"}</span></div>
          <form className="integration-form" onSubmit={(event) => void save(event, id)}>
            <label>URL do endpoint<input type="url" required maxLength={2048} value={forms[id].endpointUrl} onChange={(event) => setField(id, "endpointUrl", event.target.value)} disabled={isDemoMode || isBusy} /></label>
            <div className="integration-form-row"><label>Header da API key<input required maxLength={80} value={forms[id].authHeader} onChange={(event) => setField(id, "authHeader", event.target.value)} disabled={isDemoMode || isBusy} /></label><label>Prefixo<input maxLength={40} placeholder="ex.: Bearer ou vazio" value={forms[id].authPrefix} onChange={(event) => setField(id, "authPrefix", event.target.value)} disabled={isDemoMode || isBusy} /></label></div>
            <label>API key<input type="password" autoComplete="new-password" maxLength={4096} value={forms[id].apiKey} onChange={(event) => setField(id, "apiKey", event.target.value)} placeholder={config?.hasApiKey ? "Salva · deixe vazio para manter" : "Cole a nova chave aqui"} disabled={isDemoMode || isBusy} /></label>
            <p className="integration-security-note"><LockKeyhole size={13} /> A chave é cifrada no servidor e nunca retornada após salvar. Confirme o header esperado na documentação do provedor.</p>
            <div className="integration-actions"><button className="button primary" type="submit" disabled={isDemoMode || isBusy}><Save size={14} />Salvar</button><button className="button secondary" type="button" onClick={() => void test(id)} disabled={isDemoMode || !config?.hasApiKey || isBusy}><Wifi size={14} />{busy[`test-${id}`] ? "Testando…" : "Testar conexão"}</button>{config?.hasApiKey && <button className="button danger" type="button" onClick={() => void remove(id)} disabled={isDemoMode || isBusy} aria-label={`Remover ${title}`}><Trash2 size={14} />Remover</button>}</div>
            {config?.lastTestAt && <p className="integration-last-test">Último teste: {new Date(config.lastTestAt).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })} · {config.lastHttpStatus ? `HTTP ${config.lastHttpStatus}` : "sem resposta HTTP"}</p>}
          </form>
        </section>;
      })}
    </div>}
    <section className="integration-config-card integration-info-card"><div className="integration-config-head"><div className="integration-icon muted"><Database size={19} /></div><div><h2>Banco de dados do projeto</h2><p>Leads e configurações deste workspace usam Netlify Database por funções server-side.</p></div><span className="badge badge-neutral">SERVER-SIDE</span></div><p className="integration-security-note">A aplicação não conecta diretamente do navegador ao Postgres. A sessão é validada no servidor, que limita consultas ao usuário autenticado.</p></section>
    <section className="integration-config-card integration-info-card"><div className="integration-config-head"><div className="integration-icon muted"><CircleHelp size={19} /></div><div><h2>WhatsApp via Peach</h2><p>O Peach é um conector do ChatGPT e não uma API que este aplicativo possa incorporar.</p></div><span className="badge badge-neutral">SEM ENVIO</span></div><p className="integration-security-note">Para conectar WhatsApp neste app, configure abaixo o caminho oficial da Meta Cloud API.</p></section>
    <ProviderIntegrationsPanel />
  </div>;
}
