export const externalActions = Object.freeze({
  ai: false,
  prospecting: false,
  messaging: false,
  crmSync: false,
  externalAppointments: false,
  externalJobs: false,
});

export type ExternalAction = keyof typeof externalActions;
export function assertExternalActionEnabled(action: ExternalAction): void {
  if (!externalActions[action]) throw new Error(`Ação externa bloqueada pelo controle operacional: ${action}.`);
}
