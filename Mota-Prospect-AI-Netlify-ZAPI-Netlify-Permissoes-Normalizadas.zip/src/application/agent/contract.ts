import { z } from "zod";

export const leadAssessmentSchema = z.object({
  score: z.number().int().min(0).max(100),
  reasons: z.array(z.string().trim().min(1).max(240)).max(8),
  nextAction: z.enum(["review", "request_consent", "qualify", "human_follow_up", "no_action"]),
  summary: z.string().trim().min(1).max(1200),
  draftMessage: z.string().trim().max(2000).nullable(),
});
export type LeadAssessment = z.infer<typeof leadAssessmentSchema>;

export interface AiProvider {
  assessLead(input: { companyName: string; segment: string | null; notes: string | null }): Promise<unknown>;
}

export class AgentService {
  constructor(private readonly provider: AiProvider | null) {}

  async assess(input: { companyName: string; segment: string | null; notes: string | null }): Promise<LeadAssessment> {
    if (!this.provider) throw new Error("Provedor de IA não configurado. Nenhuma análise foi gerada.");
    let result: unknown;
    try { result = await this.provider.assessLead(input); }
    catch { throw new Error("O provedor de IA falhou. Nenhuma análise foi salva."); }
    const parsed = leadAssessmentSchema.safeParse(result);
    if (!parsed.success) throw new Error("O provedor retornou dados em formato inválido. Nenhuma análise foi salva.");
    return parsed.data;
  }
}
