import { describe, expect, it } from "vitest";
import { decideAgentAction } from "./safety";

const allowed = { paused: false, outboundSandbox: true, duplicate: false, optedOut: false, humanOwnsConversation: false, contactAuthorized: true };

describe("agent safety gate", () => {
  it("always respects opt-out", () => expect(decideAgentAction({ ...allowed, optedOut: true })).toBe("respect_opt_out"));
  it("blocks while paused", () => expect(decideAgentAction({ ...allowed, paused: true })).toBe("blocked"));
  it("only prepares a draft in sandbox", () => expect(decideAgentAction(allowed)).toBe("draft_only"));
});
