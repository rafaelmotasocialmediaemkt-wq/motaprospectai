import { describe, expect, it, vi } from "vitest";
import { AgentService } from "./contract";
import { assertExternalActionEnabled } from "./kill-switches";

describe("agent provider contract", () => {
  it("fails closed when no AI provider is configured", async () => {
    await expect(new AgentService(null).assess({ companyName: "Example", segment: null, notes: null })).rejects.toThrow("não configurado");
  });
  it("validates provider output before returning it", async () => {
    const provider = { assessLead: vi.fn(async () => ({ score: 130, reasons: [], nextAction: "review", summary: "x", draftMessage: null })) };
    await expect(new AgentService(provider).assess({ companyName: "Example", segment: null, notes: null })).rejects.toThrow("formato inválido");
  });
  it("keeps every external action killed by default", () => {
    expect(() => assertExternalActionEnabled("messaging")).toThrow("bloqueada");
  });
});
