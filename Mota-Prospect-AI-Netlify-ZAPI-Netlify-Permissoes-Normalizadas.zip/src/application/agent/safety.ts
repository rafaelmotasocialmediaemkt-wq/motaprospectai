export type AgentContext = {
  paused: boolean;
  outboundSandbox: boolean;
  duplicate: boolean;
  optedOut: boolean;
  humanOwnsConversation: boolean;
  contactAuthorized: boolean;
};

export type AgentAction = "ignore_duplicate" | "respect_opt_out" | "blocked" | "human_handoff" | "draft_only";

export function decideAgentAction(context: AgentContext): AgentAction {
  if (context.duplicate) return "ignore_duplicate";
  if (context.optedOut) return "respect_opt_out";
  if (context.paused || !context.contactAuthorized) return "blocked";
  if (context.humanOwnsConversation) return "human_handoff";
  // This project starts with outbound communication disabled. A later send action
  // must be implemented behind an explicitly configured provider and server gate.
  if (context.outboundSandbox) return "draft_only";
  return "draft_only";
}
