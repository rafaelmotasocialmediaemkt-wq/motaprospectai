import { describe, expect, it } from "vitest";
import { publicSearchProviderError } from "./search-provider-error";

describe("publicSearchProviderError", () => {
  it("identifies an invalid SerpApi key without exposing provider payloads", () => {
    expect(publicSearchProviderError(401)).toContain("chave SerpApi salva em Integrações");
    expect(publicSearchProviderError(401)).toContain("não servem para esta busca");
  });

  it("distinguishes account permission and quota errors", () => {
    expect(publicSearchProviderError(403)).toContain("HTTP 403");
    expect(publicSearchProviderError(429)).toContain("HTTP 429");
  });

  it("uses a safe generic message for unknown provider failures", () => {
    expect(publicSearchProviderError(503)).toBe("O provedor de pesquisa respondeu HTTP 503. Verifique o status do serviço SerpApi e tente novamente mais tarde.");
  });
});
