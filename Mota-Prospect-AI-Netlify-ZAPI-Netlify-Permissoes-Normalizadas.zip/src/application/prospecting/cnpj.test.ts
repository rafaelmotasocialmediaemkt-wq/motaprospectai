import { describe, expect, it } from "vitest";
import { isValidCnpj, normalizeCnpj, publicCompanyFields } from "./cnpj";

describe("public CNPJ lookup input", () => {
  it("normalizes and validates numeric CNPJs", () => {
    expect(normalizeCnpj("11.222.333/0001-81")).toBe("11222333000181");
    expect(isValidCnpj("11.222.333/0001-81")).toBe(true);
    expect(isValidCnpj("11.222.333/0001-80")).toBe(false);
  });

  it("validates the Receita Federal alphanumeric CNPJ example", () => {
    expect(isValidCnpj("12.ABC.345/01DE-35")).toBe(true);
  });

  it("returns only approved public company fields, excluding partner personal data", () => {
    expect(publicCompanyFields({ cnpj: "11222333000181", razao_social: "Empresa", qsa: [{ cpf_socio: "123" }], internal: "hidden" })).toEqual({
      cnpj: "11222333000181",
      razao_social: "Empresa",
    });
  });
});
