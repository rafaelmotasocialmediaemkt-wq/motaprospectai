const formatCharacters = /[^A-Z0-9]/g;

export function normalizeCnpj(value: string): string {
  return value.toUpperCase().replace(formatCharacters, "");
}

function calculateDigit(value: string): number {
  const weights = value.length === 12
    ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  const sum = [...value].reduce((total, character, index) => total + (character.charCodeAt(0) - 48) * weights[index]!, 0);
  const remainder = sum % 11;
  return remainder < 2 ? 0 : 11 - remainder;
}

export function isValidCnpj(value: string): boolean {
  const cnpj = normalizeCnpj(value);
  if (!/^[A-Z0-9]{12}\d{2}$/.test(cnpj) || /^([A-Z0-9])\1{13}$/.test(cnpj)) return false;
  const first = calculateDigit(cnpj.slice(0, 12));
  const second = calculateDigit(`${cnpj.slice(0, 12)}${first}`);
  return cnpj.endsWith(`${first}${second}`);
}

export type PublicCompanyFields = Record<string, string | number | boolean | null>;

export function publicCompanyFields(data: unknown): PublicCompanyFields {
  if (!data || typeof data !== "object" || Array.isArray(data)) throw new Error("A fonte pública devolveu uma resposta inválida.");
  const source = data as Record<string, unknown>;
  const allowed = [
    "cnpj", "razao_social", "nome_fantasia", "descricao_situacao_cadastral", "situacao_cadastral",
    "data_situacao_cadastral", "data_inicio_atividade", "cnae_fiscal", "cnae_fiscal_descricao",
    "logradouro", "numero", "complemento", "bairro", "municipio", "uf", "cep",
    "ddd_telefone_1", "ddd_telefone_2", "email", "porte", "descricao_porte",
    "capital_social",
  ] as const;
  return Object.fromEntries(allowed.filter((key) => {
    const value = source[key];
    return value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean";
  }).map((key) => [key, source[key]])) as PublicCompanyFields;
}
