import { isValidCnpj, normalizeCnpj } from "./cnpj";

export function cleanPublicText(value: string | undefined, max: number): string {
  return [...(value ?? "")].filter((character) => { const code = character.codePointAt(0) ?? 0; return code >= 32 && code !== 127; }).join("").replace(/\s+/g, " ").trim().slice(0, max);
}

export function safePublicUrl(value: string | undefined): string | null {
  try {
    const url = new URL(value ?? "");
    return url.protocol === "https:" && !url.username && !url.password ? url.toString().slice(0, 2048) : null;
  } catch { return null; }
}

export function extractValidCnpj(value: string): string | null {
  const candidates = value.match(/\b(?:\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2}|[A-Z0-9]{2}\.?[A-Z0-9]{3}\.?[A-Z0-9]{3}\/?[A-Z0-9]{4}-?\d{2})\b/gi) ?? [];
  for (const candidate of candidates) {
    const normalized = normalizeCnpj(candidate);
    if (isValidCnpj(normalized)) return normalized;
  }
  return null;
}
