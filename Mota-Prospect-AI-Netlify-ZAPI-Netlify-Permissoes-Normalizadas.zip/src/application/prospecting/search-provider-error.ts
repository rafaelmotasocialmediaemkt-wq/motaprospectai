/** Translate SerpApi HTTP failures without surfacing provider bodies or credentials. */
export function publicSearchProviderError(status: number): string {
  switch (status) {
    case 400:
      return "A SerpApi rejeitou os parâmetros da busca (HTTP 400). Revise segmento, região e termos de pesquisa.";
    case 401:
      return "SerpApi respondeu HTTP 401: a chave SerpApi salva em Integrações está ausente ou inválida. Atualize a chave da SerpApi; a chave Gemini/Google Cloud e a chave YCloud não servem para esta busca.";
    case 403:
      return "SerpApi respondeu HTTP 403: esta conta ou chave não tem permissão para pesquisar. Confira o estado da conta e da chave no painel SerpApi.";
    case 429:
      return "SerpApi respondeu HTTP 429: limite de requisições ou buscas disponíveis atingido. Confira o plano e aguarde antes de tentar novamente.";
    default:
      return `O provedor de pesquisa respondeu HTTP ${status}. Verifique o status do serviço SerpApi e tente novamente mais tarde.`;
  }
}
