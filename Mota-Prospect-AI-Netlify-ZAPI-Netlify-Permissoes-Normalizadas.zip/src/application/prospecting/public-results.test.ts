import { describe, expect, it } from "vitest";
import { cleanPublicText, extractValidCnpj, safePublicUrl } from "./public-results";

describe("sanitization of public search results", () => {
  it("extracts only a valid numeric or alphanumeric CNPJ", () => {
    expect(extractValidCnpj("Empresa · CNPJ 11.222.333/0001-81")).toBe("11222333000181");
    expect(extractValidCnpj("CNPJ 11.222.333/0001-80")).toBeNull();
    expect(extractValidCnpj("CNPJ 12.ABC.345/01DE-35")).toBe("12ABC34501DE35");
  });

  it("allows only credential-free HTTPS source URLs", () => {
    expect(safePublicUrl("https://example.com/empresa")).toBe("https://example.com/empresa");
    expect(safePublicUrl("http://example.com/empresa")).toBeNull();
    expect(safePublicUrl("https://user:password@example.com/")).toBeNull();
  });

  it("removes control characters and limits untrusted text", () => {
    expect(cleanPublicText("A\u0000  B\nC", 4)).toBe("A BC");
  });
});
