import { z } from "zod";
import type { Lead } from "../../domain/leads/lead";
import { normalizePhone } from "../../domain/leads/lead";

export const createLeadSchema = z.object({
  companyName: z.string().trim().min(2).max(160),
  contactName: z.string().trim().max(160).nullable().optional(),
  email: z.email().nullable().optional().or(z.literal("")),
  phone: z.string().trim().max(40).nullable().optional(),
  segment: z.string().trim().max(100).nullable().optional(),
  city: z.string().trim().max(100).nullable().optional(),
  state: z.string().trim().max(2).nullable().optional(),
  notes: z.string().trim().max(3000).nullable().optional(),
});

export type CreateLeadInput = z.infer<typeof createLeadSchema>;

export interface LeadRepository {
  list(): Promise<Lead[]>;
  create(input: CreateLeadInput): Promise<Lead>;
  update?(id: string, input: CreateLeadInput): Promise<Lead>;
  move?(id: string, stage: Lead["stage"]): Promise<Lead>;
  suppressContact?(id: string): Promise<Lead>;
  review?(id: string, status: Lead["reviewStatus"], duplicateOf?: string): Promise<Lead>;
  approvePending?(): Promise<Lead[]>;
}

export type AuditWriter = (action: string, entityId: string, summary: string) => void | Promise<void>;

export class LeadService {
  constructor(private readonly repository: LeadRepository, private readonly audit: AuditWriter) {}

  async list(): Promise<Lead[]> {
    return this.repository.list();
  }

  async create(raw: unknown): Promise<Lead> {
    const input = createLeadSchema.parse(raw);
    const lead = await this.repository.create({
      ...input,
      companyName: input.companyName.trim(),
      contactName: input.contactName?.trim() || null,
      email: input.email?.trim().toLocaleLowerCase("pt-BR") || null,
      phone: input.phone ? normalizePhone(input.phone) : null,
      segment: input.segment || null,
      city: input.city || null,
      state: input.state?.toUpperCase() || null,
      notes: input.notes || null,
    });
    await this.audit("lead.created", lead.id, `Lead ${lead.isDemo ? "de demonstração" : "real"} criado`);
    return lead;
  }

  async update(id: string, raw: unknown): Promise<Lead> {
    const input = createLeadSchema.parse(raw);
    if (!this.repository.update) throw new Error("Edição não está disponível neste repositório.");
    const lead = await this.repository.update(id, {
      ...input,
      companyName: input.companyName.trim(),
      contactName: input.contactName?.trim() || null,
      email: input.email?.trim().toLocaleLowerCase("pt-BR") || null,
      phone: input.phone ? normalizePhone(input.phone) : null,
      segment: input.segment || null,
      city: input.city || null,
      state: input.state?.toUpperCase() || null,
      notes: input.notes || null,
    });
    await this.audit("lead.updated", lead.id, "Dados do lead alterados");
    return lead;
  }

  async move(id: string, stage: Lead["stage"]): Promise<Lead> {
    if (!this.repository.move) throw new Error("Alteração de etapa não está disponível neste repositório.");
    const lead = await this.repository.move(id, stage);
    await this.audit("lead.stage_changed", lead.id, `Etapa alterada para ${stage}`);
    return lead;
  }

  async archive(id: string): Promise<Lead> {
    if (!this.repository.move) throw new Error("Arquivamento não está disponível neste repositório.");
    const lead = await this.repository.move(id, "archived");
    await this.audit("lead.archived", lead.id, "Lead arquivado");
    return lead;
  }

  async suppressContact(id: string): Promise<Lead> {
    if (!this.repository.suppressContact) throw new Error("Bloqueio de contato não está disponível neste repositório.");
    const lead = await this.repository.suppressContact(id);
    await this.audit("lead.contact_suppressed", lead.id, "Contato futuro bloqueado");
    return lead;
  }

  async review(id: string, status: Lead["reviewStatus"], duplicateOf?: string): Promise<Lead> {
    if (!this.repository.review) throw new Error("Revisão não está disponível neste repositório.");
    const lead = await this.repository.review(id, status, duplicateOf);
    await this.audit("lead.review_decided", lead.id, `Revisão registrada: ${status}`);
    return lead;
  }

  async approvePending(): Promise<Lead[]> {
    if (!this.repository.approvePending) throw new Error("Aprovação em lote não está disponível neste repositório.");
    return this.repository.approvePending();
  }
}
