import { describe, expect, it, vi } from "vitest";
import { LeadService, type CreateLeadInput, type LeadRepository } from "./lead-service";
import type { Lead } from "../../domain/leads/lead";

function repository(): LeadRepository {
  return {
    list: vi.fn(async () => []),
    create: vi.fn(async (input: CreateLeadInput) => ({
      id: "lead-1", companyName: input.companyName, contactName: input.contactName ?? null,
      email: input.email || null, phone: input.phone || null, segment: input.segment ?? null,
      city: input.city ?? null, state: input.state ?? null, source: "LOCAL DEMO", stage: "new",
      qualificationScore: null, notes: input.notes ?? null, optedOutAt: null, reviewStatus: "pending", reviewedAt: null, duplicateOf: null, isDemo: true,
      createdAt: "2026-01-01T00:00:00.000Z", updatedAt: "2026-01-01T00:00:00.000Z",
    } satisfies Lead)),
  };
}

describe("LeadService", () => {
  it("records an opt-out through the repository and audit writer", async () => {
    const repo = repository();
    const lead = { id: "lead-1", companyName: "Mota Lab", contactName: null, email: null, phone: null, segment: null, city: null, state: null, source: "LOCAL DEMO", stage: "new", qualificationScore: null, notes: null, optedOutAt: "2026-01-02T00:00:00.000Z", reviewStatus: "pending", reviewedAt: null, duplicateOf: null, isDemo: true, createdAt: "2026-01-01T00:00:00.000Z", updatedAt: "2026-01-02T00:00:00.000Z" } satisfies Lead;
    repo.suppressContact = vi.fn(async () => lead);
    const audit = vi.fn();
    const service = new LeadService(repo, audit);
    await expect(service.suppressContact("lead-1")).resolves.toEqual(lead);
    expect(repo.suppressContact).toHaveBeenCalledWith("lead-1");
    expect(audit).toHaveBeenCalledWith("lead.contact_suppressed", "lead-1", "Contato futuro bloqueado");
  });

  it("validates and normalizes a local lead before persistence", async () => {
    const repo = repository();
    const audit = vi.fn();
    const service = new LeadService(repo, audit);
    const lead = await service.create({ companyName: " Mota Lab ", email: "SALES@example.com", phone: "+55 (82) 9999-0000", state: "al" });
    expect(lead.companyName).toBe("Mota Lab");
    expect(repo.create).toHaveBeenCalledWith(expect.objectContaining({ email: "sales@example.com", phone: "558299990000", state: "AL" }));
    expect(audit).toHaveBeenCalledWith("lead.created", "lead-1", expect.any(String));
  });

  it("rejects an invalid company name before writing", async () => {
    const repo = repository();
    const service = new LeadService(repo, vi.fn());
    await expect(service.create({ companyName: " " })).rejects.toThrow();
    expect(repo.create).not.toHaveBeenCalled();
  });

  it("persists a human review decision and audits it", async () => {
    const repo = repository();
    const lead = { id: "lead-1", companyName: "Mota Lab", contactName: null, email: null, phone: null, segment: null, city: null, state: null, source: "LOCAL DEMO", stage: "new", qualificationScore: null, notes: null, optedOutAt: null, reviewStatus: "approved", reviewedAt: "2026-01-02T00:00:00.000Z", duplicateOf: null, isDemo: true, createdAt: "2026-01-01T00:00:00.000Z", updatedAt: "2026-01-02T00:00:00.000Z" } satisfies Lead;
    repo.review = vi.fn(async () => lead);
    const audit = vi.fn();
    const service = new LeadService(repo, audit);
    await expect(service.review("lead-1", "approved")).resolves.toEqual(lead);
    expect(repo.review).toHaveBeenCalledWith("lead-1", "approved", undefined);
    expect(audit).toHaveBeenCalledWith("lead.review_decided", "lead-1", "Revisão registrada: approved");
  });
});
