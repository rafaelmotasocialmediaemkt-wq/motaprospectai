import { createHash, createHmac, timingSafeEqual } from "node:crypto";

export type YCloudEvent = {
  id: string;
  type: string;
  apiVersion?: string;
  createTime?: string;
  whatsappInboundMessage?: {
    id: string;
    wamid?: string;
    from: string;
    to?: string;
    type: string;
    sendTime?: string;
    customerProfile?: { name?: string };
    text?: { body?: string };
    button?: { text?: string; payload?: string };
    interactive?: { type?: string; button_reply?: { title?: string; id?: string }; list_reply?: { title?: string; id?: string } };
  };
  whatsappMessage?: { id: string; wamid?: string; externalId?: string; status: string; errorCode?: string; errorMessage?: string };
};

export function verifyYCloudSignature(rawBody: string, header: string | null, secret: string, nowSeconds = Math.floor(Date.now() / 1000)): boolean {
  if (!header || !secret) return false;
  const fields = new Map(header.split(",").map((part) => {
    const splitAt = part.indexOf("=");
    return splitAt < 0 ? ["", ""] : [part.slice(0, splitAt).trim(), part.slice(splitAt + 1).trim()];
  }));
  const timestamp = fields.get("t");
  const signature = fields.get("s");
  if (!timestamp || !/^\d{10}$/.test(timestamp) || !signature || !/^[a-f\d]{64}$/i.test(signature)) return false;
  // Permit the provider's documented retry horizon (about five hours) plus margin; event-ID persistence handles replay.
  const ageSeconds = nowSeconds - Number(timestamp);
  if (ageSeconds > 6 * 60 * 60 || ageSeconds < -300) return false;
  const expected = createHmac("sha256", secret).update(`${timestamp}.${rawBody}`, "utf8").digest();
  const received = Buffer.from(signature, "hex");
  return received.length === expected.length && timingSafeEqual(received, expected);
}

export function parseYCloudEvent(value: unknown): YCloudEvent {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Evento YCloud inválido.");
  const event = value as Record<string, unknown>;
  if (typeof event.id !== "string" || event.id.length < 1 || event.id.length > 200 || typeof event.type !== "string" || event.type.length > 160) throw new Error("Identificador ou tipo do evento inválido.");
  if (event.type === "whatsapp.inbound_message.received") {
    const message = event.whatsappInboundMessage as Record<string, unknown> | undefined;
    if (!message || typeof message.id !== "string" || typeof message.from !== "string" || typeof message.type !== "string") throw new Error("Dados essenciais da mensagem de entrada inválidos.");
  }
  if (event.type === "whatsapp.message.updated") {
    const message = event.whatsappMessage as Record<string, unknown> | undefined;
    if (!message || typeof message.id !== "string" || typeof message.status !== "string") throw new Error("Dados essenciais do status da mensagem inválidos.");
  }
  return value as YCloudEvent;
}

export function hashYCloudPayload(rawBody: string): string { return createHash("sha256").update(rawBody, "utf8").digest("hex"); }

export function inboundText(event: YCloudEvent): string {
  const message = event.whatsappInboundMessage;
  if (!message) return "";
  if (message.type === "text" && typeof message.text?.body === "string") return message.text.body.slice(0, 4000);
  if (message.type === "button" && typeof message.button?.text === "string") return message.button.text.slice(0, 4000);
  if (message.type === "interactive") return (message.interactive?.button_reply?.title ?? message.interactive?.list_reply?.title ?? "").slice(0, 4000);
  return `[Mensagem do tipo ${message.type}]`;
}

export function normalizedPhoneDigits(value: string): string {
  const digits = value.replace(/\D/g, "");
  if (digits.length === 10 || digits.length === 11) return `55${digits}`;
  return digits;
}

export function mapYCloudStatus(value: string): "accepted" | "sent" | "delivered" | "read" | "failed" | null {
  return ["accepted", "sent", "delivered", "read", "failed"].includes(value) ? value as "accepted" | "sent" | "delivered" | "read" | "failed" : null;
}
