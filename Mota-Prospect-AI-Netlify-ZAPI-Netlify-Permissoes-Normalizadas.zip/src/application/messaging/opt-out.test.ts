import { describe, expect, it } from "vitest";
import { isClearOptOut } from "./opt-out";

describe("clear opt-out detection", () => {
  it("recognizes unambiguous Portuguese requests", () => {
    expect(isClearOptOut("Não quero receber mensagens." )).toBe(true);
    expect(isClearOptOut("Remova meu contato, por favor")).toBe(true);
    expect(isClearOptOut("Não me mande mais mensagens")).toBe(true);
  });
  it("does not treat ordinary conversation as opt-out", () => {
    expect(isClearOptOut("Não tenho interesse nessa oferta agora, pode explicar melhor?" )).toBe(false);
    expect(isClearOptOut("Pode me chamar amanhã")).toBe(false);
  });
});
