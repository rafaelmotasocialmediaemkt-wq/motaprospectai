export function isClearOptOut(message: string): boolean {
  const normalized = message.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR").replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
  return /\b(nao quero receber (mais )?(mensagens|contato)|pare de me chamar|remova meu contato|removam meu contato|nao me mande mais mensagens|nao tenho interesse em receber contato|cancele meu contato|descadastre me)\b/.test(normalized);
}
