import { describe, expect, it, vi } from "vitest";
import { ReplyAssistanceService } from "./reply-assistance";

describe("human-supervised reply assistance contract", () => {
  it("does not fabricate a suggestion without a provider", async () => {
    await expect(new ReplyAssistanceService(null).suggest({ companyName: "Loja teste", leadFacts: [], recentMessages: [], optedOut: false, humanOwnsConversation: false })).rejects.toThrow("nenhuma resposta foi gerada");
  });

  it("blocks opt-out and human-owned threads before calling a provider", async () => {
    const suggestReply = vi.fn().mockResolvedValue({});
    const service = new ReplyAssistanceService({ suggestReply });
    await expect(service.suggest({ companyName: "Empresa sintética", leadFacts: [], recentMessages: [], optedOut: true, humanOwnsConversation: false })).rejects.toThrow("bloqueada");
    await expect(service.suggest({ companyName: "Empresa sintética", leadFacts: [], recentMessages: [], optedOut: false, humanOwnsConversation: true })).rejects.toThrow("bloqueada");
    expect(suggestReply).not.toHaveBeenCalled();
  });
});
