import { z } from "zod";

export const replySuggestionSchema = z.object({
  reply: z.string().trim().min(1).max(2000),
  intent: z.enum(["question", "objection", "meeting_interest", "opt_out", "human_request", "other"]),
  summary: z.string().trim().min(1).max(800),
  nextStep: z.string().trim().min(1).max(400),
  requiresHuman: z.boolean(),
});
export type ReplySuggestion = z.infer<typeof replySuggestionSchema>;

export type ReplyContext = {
  companyName: string;
  leadFacts: string[];
  recentMessages: Array<{ direction: "inbound" | "outbound"; body: string }>;
  optedOut: boolean;
  humanOwnsConversation: boolean;
};

/** Adapter boundary only. A provider must treat conversation text as untrusted data, not policy. */
export interface ConversationAiProvider {
  suggestReply(context: ReplyContext): Promise<unknown>;
}

export class ReplyAssistanceService {
  constructor(private readonly provider: ConversationAiProvider | null) {}

  async suggest(context: ReplyContext): Promise<ReplySuggestion> {
    if (!this.provider) throw new Error("Provedor de sugestões para conversas não configurado; nenhuma resposta foi gerada.");
    if (context.optedOut || context.humanOwnsConversation) throw new Error("A sugestão automática está bloqueada para esta conversa.");
    const result = await this.provider.suggestReply({ ...context, leadFacts: context.leadFacts.slice(0, 20), recentMessages: context.recentMessages.slice(-20).map((message) => ({ ...message, body: message.body.slice(0, 4000) })) });
    const parsed = replySuggestionSchema.safeParse(result);
    if (!parsed.success) throw new Error("O provedor de IA retornou resposta inválida; nada foi salvo ou enviado.");
    return parsed.data;
  }
}
