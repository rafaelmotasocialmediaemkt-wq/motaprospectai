import { createHmac } from "node:crypto";
import { describe, expect, it } from "vitest";
import { hashYCloudPayload, inboundText, mapYCloudStatus, normalizedPhoneDigits, parseYCloudEvent, verifyYCloudSignature } from "./ycloud-webhook";

describe("YCloud webhook contract", () => {
  const secret = "synthetic-webhook-secret";
  const now = 1_800_000_000;
  const body = JSON.stringify({ id: "evt_synthetic_1", type: "whatsapp.inbound_message.received", whatsappInboundMessage: { id: "msg_synthetic_1", from: "+5582999999999", type: "text", text: { body: "pare de me chamar" } } });
  const signature = `t=${now},s=${createHmac("sha256", secret).update(`${now}.${body}`).digest("hex")}`;

  it("verifica HMAC em corpo bruto e rejeita assinatura inválida ou além da janela de repetição", () => {
    expect(verifyYCloudSignature(body, signature, secret, now)).toBe(true);
    expect(verifyYCloudSignature(`${body} `, signature, secret, now)).toBe(false);
    expect(verifyYCloudSignature(body, signature, secret, now + 301)).toBe(true);
    expect(verifyYCloudSignature(body, signature, secret, now + 6 * 60 * 60 + 1)).toBe(false);
    expect(verifyYCloudSignature(body, signature, secret, now - 301)).toBe(false);
    expect(verifyYCloudSignature(body, "t=bad,s=bad", secret, now)).toBe(false);
  });

  it("valida evento sintético e mapeia só estados documentados", () => {
    const event = parseYCloudEvent(JSON.parse(body));
    expect(event.id).toBe("evt_synthetic_1");
    expect(inboundText(event)).toBe("pare de me chamar");
    expect(hashYCloudPayload(body)).toMatch(/^[a-f\d]{64}$/);
    expect(mapYCloudStatus("delivered")).toBe("delivered");
    expect(mapYCloudStatus("queued_unknown")).toBeNull();
    expect(normalizedPhoneDigits("+55 (82) 99999-9999")).toBe("5582999999999");
    expect(() => parseYCloudEvent({ id: "missing-type" })).toThrow();
  });
});
